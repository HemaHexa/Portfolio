MOCK MARKET DATA - 4 MONTHS

Period:
2026-05-25 to 2026-09-28
Business-day rows per security: 91

Asset Classes:
- Equity ETF: EQETF1, EQETF2, EQETF3
- Debt ETF: DEBTETF1, DEBTETF2, DEBTETF3
- Gold ETF: GOLDETF1, GOLDETF2, GOLDETF3
- Cash: no market-price file required; use portfolio.available_balance.

Files:
- One CSV per security
- One combined CSV per asset class
- mock_security_master.csv
- benchmark/NIFTY50_MOCK_4_months.csv

IMPORTANT:
All prices are synthetic MOCK data created only for portfolio application testing.
Do not describe them as real NSE or live market prices.

Suggested application use:
1. Transaction date in the past -> use Close Price for that date.
2. If selected date is a weekend/holiday -> use previous available row.
3. Latest/current mock value -> use the newest Close Price in the CSV.
4. Average buy price -> derive from BUY transactions.
5. Current value -> quantity * latest mock Close Price.
6. Recalculate allocation -> alerts -> rebalancing recommendation.
