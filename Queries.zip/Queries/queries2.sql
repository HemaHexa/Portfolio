SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid = 'portfolio'::regclass;

SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conname = 'portfolio_rebalancing_frequency_check';

SELECT theme_id, theme_name, status FROM investment_theme ORDER BY theme_id;

SELECT benchmark_id, benchmark_name, benchmark_code, status FROM benchmark_master ORDER BY benchmark_id;

SELECT * FROM portfolio ORDER BY portfolio_id;

SELECT
    p.portfolio_id,
    p.portfolio_name,
    p.available_balance,
    sm.security_id,
    sm.symbol,
    sm.security_name,
    lmp.price,
    lmp.price_date
FROM portfolio p
CROSS JOIN latest_market_price lmp
JOIN security_master sm
    ON sm.security_id = lmp.security_id
WHERE p.status <> 'Closed'
ORDER BY p.portfolio_id, sm.symbol
LIMIT 10;
 
 
-- 1. Verify holding
SELECT
    ph.holding_id,
    ph.portfolio_id,
    ph.security_id,
    sm.symbol,
    ph.quantity,
    ph.average_buy_price
FROM portfolio_holding ph
JOIN security_master sm
    ON sm.security_id = ph.security_id
WHERE ph.portfolio_id = 1;
 
 
-- 2. Verify BUY transaction
SELECT
    transaction_id,
    portfolio_id,
    security_id,
    transaction_type,
    quantity,
    price,
    transaction_amount,
    transaction_date
FROM portfolio_transaction
WHERE portfolio_id = 1
ORDER BY transaction_id;
 
 
-- 3. Verify portfolio balance
SELECT
    portfolio_id,
    portfolio_name,
    initial_investment,
    available_balance,
    status
FROM portfolio
WHERE portfolio_id = 1;

SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid = 'portfolio_alert'::regclass;

CREATE OR REPLACE VIEW vw_portfolio_holdings_value AS
SELECT
    ph.holding_id,
    ph.portfolio_id,
    p.portfolio_name,
 
    ph.security_id,
    sm.symbol,
    sm.security_name,
 
    ac.asset_class_id,
    ac.asset_class_name,
    ac.sub_asset_class,
 
    ph.quantity,
    ph.average_buy_price,
 
    lmp.price AS latest_price,
    lmp.price_date,
 
    (ph.quantity * ph.average_buy_price)
        AS invested_value,
 
    (ph.quantity * lmp.price)
        AS current_value,
 
    (
        (ph.quantity * lmp.price)
        -
        (ph.quantity * ph.average_buy_price)
    ) AS profit_loss
 
FROM portfolio_holding ph
 
JOIN portfolio p
    ON ph.portfolio_id = p.portfolio_id
 
JOIN security_master sm
    ON ph.security_id = sm.security_id
 
LEFT JOIN asset_class ac
    ON sm.asset_class_id = ac.asset_class_id
 
LEFT JOIN latest_market_price lmp
    ON ph.security_id = lmp.security_id;
 
SELECT * FROM vw_portfolio_holdings_value WHERE portfolio_id = 1;

CREATE OR REPLACE VIEW vw_portfolio_summary AS
SELECT
    p.portfolio_id,
    p.portfolio_name,
    p.portfolio_type,
    p.currency,
    p.exchange,
    p.status,
 
    p.theme_id,
    it.theme_name,
 
    p.benchmark_id,
    bm.benchmark_name,
 
    p.initial_investment,
    p.available_balance,
 
    COALESCE(
        SUM(v.current_value),
        0
    ) AS holdings_current_value,
 
    COALESCE(
        SUM(v.invested_value),
        0
    ) AS holdings_invested_value,
 
    (
        p.available_balance
        +
        COALESCE(SUM(v.current_value), 0)
    ) AS total_portfolio_value,
 
    (
        p.available_balance
        +
        COALESCE(SUM(v.current_value), 0)
        -
        p.initial_investment
    ) AS profit_loss,
 
    CASE
        WHEN p.initial_investment > 0
        THEN
            (
                (
                    p.available_balance
                    +
                    COALESCE(SUM(v.current_value), 0)
                    -
                    p.initial_investment
                )
                / p.initial_investment
            ) * 100
        ELSE 0
    END AS return_percentage
 
FROM portfolio p
 
LEFT JOIN investment_theme it
    ON p.theme_id = it.theme_id
 
LEFT JOIN benchmark_master bm
    ON p.benchmark_id = bm.benchmark_id
 
LEFT JOIN vw_portfolio_holdings_value v
    ON p.portfolio_id = v.portfolio_id
 
GROUP BY
    p.portfolio_id,
    p.portfolio_name,
    p.portfolio_type,
    p.currency,
    p.exchange,
    p.status,
    p.theme_id,
    it.theme_name,
    p.benchmark_id,
    bm.benchmark_name,
    p.initial_investment,
    p.available_balance;
	
	
	
CREATE OR REPLACE VIEW vw_portfolio_asset_allocation AS
 
-- Invested asset classes
SELECT
    p.portfolio_id,
    ac.asset_class_id,
    ac.asset_class_name,
 
    SUM(v.current_value) AS current_value,
 
    CASE
        WHEN ps.total_portfolio_value > 0
        THEN
            (
                SUM(v.current_value)
                / ps.total_portfolio_value
            ) * 100
        ELSE 0
    END AS current_percentage
 
FROM portfolio p
 
JOIN vw_portfolio_holdings_value v
    ON p.portfolio_id = v.portfolio_id
 
JOIN asset_class ac
    ON v.asset_class_id = ac.asset_class_id
 
JOIN vw_portfolio_summary ps
    ON p.portfolio_id = ps.portfolio_id
 
GROUP BY
    p.portfolio_id,
    ac.asset_class_id,
    ac.asset_class_name,
    ps.total_portfolio_value
 
 
UNION ALL
 
 
-- Available balance is treated as Cash
SELECT
    p.portfolio_id,
    ac.asset_class_id,
    ac.asset_class_name,
 
    p.available_balance AS current_value,
 
    CASE
        WHEN ps.total_portfolio_value > 0
        THEN
            (
                p.available_balance
                / ps.total_portfolio_value
            ) * 100
        ELSE 0
    END AS current_percentage
 
FROM portfolio p
 
JOIN vw_portfolio_summary ps
    ON p.portfolio_id = ps.portfolio_id
 
JOIN asset_class ac
    ON LOWER(ac.asset_class_name) = 'cash';
	
	
	
CREATE OR REPLACE VIEW vw_rebalancing_assessment AS
SELECT
    p.portfolio_id,
    p.portfolio_name,
 
    it.theme_id,
    it.theme_name,
 
    ac.asset_class_id,
    ac.asset_class_name,
 
    ta.target_percentage,
    ta.minimum_percentage,
    ta.maximum_percentage,
 
    COALESCE(
        paa.current_value,
        0
    ) AS current_value,
 
    COALESCE(
        paa.current_percentage,
        0
    ) AS current_percentage,
 
    (
        COALESCE(
            paa.current_percentage,
            0
        )
        -
        ta.target_percentage
    ) AS deviation_percentage,
 
    CASE
        WHEN
            COALESCE(
                paa.current_percentage,
                0
            ) > ta.target_percentage
        THEN 'REDUCE'
 
        WHEN
            COALESCE(
                paa.current_percentage,
                0
            ) < ta.target_percentage
        THEN 'INCREASE'
 
        ELSE 'NO ACTION'
    END AS recommended_action
 
FROM portfolio p
 
JOIN investment_theme it
    ON p.theme_id = it.theme_id
 
JOIN theme_allocation ta
    ON p.theme_id = ta.theme_id
 
JOIN asset_class ac
    ON ta.asset_class_id = ac.asset_class_id
 
LEFT JOIN vw_portfolio_asset_allocation paa
    ON p.portfolio_id = paa.portfolio_id
    AND ta.asset_class_id = paa.asset_class_id;
	
	
	
CREATE OR REPLACE VIEW vw_portfolio_performance AS
SELECT
    ps.portfolio_id,
    ps.portfolio_name,
 
    ps.benchmark_id,
    ps.benchmark_name,
 
    ps.initial_investment,
 
    ps.holdings_invested_value,
    ps.holdings_current_value,
    ps.available_balance,
 
    ps.total_portfolio_value,
 
    ps.profit_loss,
 
    ps.return_percentage AS portfolio_return_percentage
 
FROM vw_portfolio_summary ps;
 
 
SELECT *
FROM vw_portfolio_holdings_value
WHERE portfolio_id = 1;
 
SELECT *
FROM vw_portfolio_summary
WHERE portfolio_id = 1;
 
SELECT *
FROM vw_portfolio_asset_allocation
WHERE portfolio_id = 1;
 
SELECT *
FROM vw_rebalancing_assessment
WHERE portfolio_id = 1;
 
SELECT *
FROM vw_portfolio_performance
WHERE portfolio_id = 1;
 