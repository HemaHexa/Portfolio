SELECT COUNT(*) FROM security_master;

SELECT
    s.security_id,
    s.exchange,
    s.symbol,
    s.security_name,
    s.isin,
    s.series,
    s.security_type,
    a.asset_class_name,
    s.listing_date,
    s.paid_up_value,
    s.market_lot,
    s.face_value
FROM security_master s
LEFT JOIN asset_class a
    ON s.asset_class_id = a.asset_class_id
WHERE s.symbol = 'TCS';

SELECT COUNT(*) FROM market_price_history;

SELECT s.symbol, COUNT(*) AS price_rows FROM market_price_history p JOIN security_master s ON p.security_id = s.security_id GROUP BY s.symbol ORDER BY s.symbol;
 
SELECT s.symbol, l.price, l.price_date, l.source FROM latest_market_price l JOIN security_master s ON l.security_id = s.security_id ORDER BY s.symbol;

SELECT
    s.symbol,
    MAX(p.trade_date) AS history_latest_date,
    l.price_date AS latest_price_date
FROM security_master s
JOIN market_price_history p
    ON s.security_id = p.security_id
JOIN latest_market_price l
    ON s.security_id = l.security_id
GROUP BY
    s.symbol,
    l.price_date
ORDER BY s.symbol;

SELECT security_id, symbol, security_name, series, security_type, asset_class_id FROM security_master WHERE symbol = 'GOLD10G99';

SELECT s.security_id, s.symbol, s.series, s.security_type, a.asset_class_name, a.sub_asset_class FROM security_master s LEFT JOIN asset_class a ON s.asset_class_id = a.asset_class_id WHERE s.symbol = 'GOLD10G99';

ALTER TABLE security_master DROP CONSTRAINT security_master_status_check;

ALTER TABLE security_master ADD CONSTRAINT secutity_master_status_check CHECK( status IN ('ACTIVE', 'INACTIVE', 'DELISTED'));

SELECT status, COUNT(*) FROM security_master GROUP BY status ORDER BY status;

UPDATE security_Master SET status = UPPER(status);


SELECT
    s.symbol,
    s.series,
    s.security_type,
    a.asset_class_name,
    a.sub_asset_class,
    COUNT(p.price_id) AS history_rows,
    l.price AS latest_price,
    l.price_date
FROM security_master s
JOIN asset_class a
    ON s.asset_class_id = a.asset_class_id
LEFT JOIN market_price_history p
    ON s.security_id = p.security_id
LEFT JOIN latest_market_price l
    ON s.security_id = l.security_id
WHERE s.symbol = 'GOLD10G99'
GROUP BY
    s.symbol,
    s.series,
    s.security_type,
    a.asset_class_name,
    a.sub_asset_class,
    l.price,
    l.price_date;
 
SELECT asset_class_id, asset_class_name, sub_asset_class, risk_level, investment_horizon FROM asset_class ORDER BY asset_class_id;

ALTER TABLE investment_theme DROP CONSTRAINT investment_theme_status_check;

ALTER TABLE investment_theme ADD CONSTRAINT investment_theme_status_check CHECK(status IN ('ACTIVE','INACTIVE'));

ALTER TABLE benchmark_master DROP CONSTRAINT benchmark_master_status_check;

ALTER TABLE benchmark_master ADD CONSTRAINT benchmark_master_status_check CHECK(status IN ('ACTIVE','INACTIVE'));

SELECT * FROM benchmark_master;

SELECT
    benchmark_id,
    COUNT(*) AS total_prices,
    MIN(price_date) AS first_date,
    MAX(price_date) AS last_date
FROM benchmark_price_history
GROUP BY benchmark_id;

SELECT
    benchmark_id,
    price_date,
    close_value,
    source
FROM benchmark_price_history
ORDER BY price_date DESC
LIMIT 10;
 
 
-- 1. Asset Classes
SELECT COUNT(*) AS asset_class_count
FROM asset_class;
 
 
-- 2. Security Master count
SELECT COUNT(*) AS security_count
FROM security_master;
 
 
-- 3. Securities grouped by source/type
SELECT
    source,
    security_type,
    COUNT(*) AS total
FROM security_master
GROUP BY source, security_type
ORDER BY source, security_type;
 
 
-- 4. Duplicate securities
SELECT
    exchange,
    symbol,
    COUNT(*) AS duplicate_count
FROM security_master
GROUP BY exchange, symbol
HAVING COUNT(*) > 1;
 
 
-- 5. Missing important Security Master fields
SELECT
    COUNT(*) AS securities_with_missing_fields
FROM security_master
WHERE exchange IS NULL
   OR symbol IS NULL
   OR security_name IS NULL
   OR currency IS NULL
   OR country IS NULL;
 
 
-- 6. Market price history count
SELECT COUNT(*) AS market_history_count
FROM market_price_history;
 
 
-- 7. Latest price count
SELECT COUNT(*) AS latest_price_count
FROM latest_market_price;
 
 
-- 8. Mutual Fund NAV count
SELECT COUNT(*) AS mutual_fund_nav_count
FROM mutual_fund_nav_history;
 
 
-- 9. Theme allocation totals
SELECT
    it.theme_id,
    it.theme_name,
    SUM(ta.target_percentage) AS total_target
FROM investment_theme it
JOIN theme_allocation ta
    ON it.theme_id = ta.theme_id
GROUP BY it.theme_id, it.theme_name;
 
 
-- 10. Benchmark history
SELECT
    bm.benchmark_id,
    bm.benchmark_name,
    COUNT(bph.benchmark_price_id) AS history_count,
    MIN(bph.price_date) AS first_date,
    MAX(bph.price_date) AS latest_date
FROM benchmark_master bm
LEFT JOIN benchmark_price_history bph
    ON bm.benchmark_id = bph.benchmark_id
GROUP BY bm.benchmark_id, bm.benchmark_name;
 