CREATE TABLE asset_class(asset_class_id SERIAL PRIMARY KEY,
						 asset_class_name VARCHAR(100) NOT NULL,
						 asset_description VARCHAR(500),
						 sub_asset_class VARCHAR(100),
						 sub_asset_description VARCHAR(500),
						 risk_level VARCHAR(50),
						 investment_horizon VARCHAR(100),
						 status VARCHAR(20) NOT NULL DEFAULT 'Active'
						 	CHECK (status IN ('Active','Inactive')),
						 createdd_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
						 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
						 UNIQUE( asset_class_name, sub_asset_class));
						 
CREATE TABLE security_master(security_id SERIAL PRIMARY KEY,
							exchange VARCHAR(100) NOT NULL,
							symbol VARCHAR(50) NOT NULL,
							security_name VARCHAR(255) NOT NULL,
							isin VARCHAR(50),
							series VARCHAR(100),
							security_code VARCHAR(100),
							security_type VARCHAR(100),
							asset_class_id INTEGER,
							country VARCHAR(100) NOT NULL,
							currency VARCHAR(20) NOT NULL,
							sector VARCHAR(150),
							industry VARCHAR(150),
							listing_date DATE,
							paid_up_value NUMERIC(18,4),
							market_lot INTEGER,
							face_value NUMERIC(18,4),
							market_cap NUMERIC(24,2),
							scheme_code VARCHAR(100),
							status VARCHAR(20) NOT NULL DEFAULT 'Active'
								CHECK( status IN ('Active','Inactive','Delisted')),
							source VARCHAR(100) NOT NULL,
							last_updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							CONSTRAINT fk_secuirty_asset_class
								FOREIGN KEY ( asset_class_id)
							 	REFERENCES asset_class(asset_class_id),
							CONSTRAINT uq_security_exchange_symbol
							 	UNIQUE ( exchange, symbol));
								
CREATE TABLE market_price_history(price_id SERIAL PRIMARY KEY,
								 security_id INTEGER NOT NULL,
								 trade_date DATE NOT NULL,
								 previous_close NUMERIC(18,4),
								 open_price NUMERIC(18,4),
								 high_price NUMERIC(18,4),
								 low_price NUMERIC(18,4),
								 last_price NUMERIC(18,4),
								 close_price NUMERIC(18,4),
								 average_price NUMERIC(18,4),
								 volume BIGINT,
								 turnover NUMERIC(24,4),
								 number_of_trades BIGINT,
								 deliverable_quantity BIGINT,
								 delivery_percentage NUMERIC(8,2),
								 source VARCHAR(100),
								 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
								 CONSTRAINT fk_market_price_security
								 	FOREIGN KEY (security_id)
								 	REFERENCES security_master(security_id),
								 CONSTRAINT qu_market_price
								 	UNIQUE ( security_id, trade_date));
									
CREATE TABLE latest_market_price(latest_price_id SERIAL PRIMARY KEY,
								security_id INTEGER NOT NULL UNIQUE,
								price NUMERIC(18,4) NOT NULL,
								price_date DATE NOT NULL,
								source VARCHAR(100),
								updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
								CONSTRAINT fk_latest_price_security
									FOREIGN KEY(security_id)
									REFERENCES security_master(security_id));
									
CREATE TABLE mutual_fund_nav_history(nav_id SERIAL PRIMARY KEY,
									security_id INTEGER NOT NULL,
									nav_date DATE NOT NULL,
									nav NUMERIC(18,4) NOT NULL,
									plan VARCHAR(100),
									option_type VARCHAR(150),
									source VARCHAR(100) NOT NULL DEFAULT 'AMFI',
									created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
									CONSTRAINT fk_mf_nav_security
										FOREIGN KEY (security_id)
										REFERENCES security_master(security_id),
									CONSTRAINT uq_mf_nav
										UNIQUE(security_id, nav_date));
										
SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name;

SELECT COUNT(*) FROM asset_class;

SELECT COUNT(*) FROM security_master;

SELECT COUNT(*) FROM market_price_history;

SELECT COUNT(*) FROM latest_market_price;

SELECT COUNT(*) FROM mutual_fund_nav_history;

CREATE TABLE investment_theme(theme_id SERIAL PRIMARY KEY,
							 theme_name VARCHAR(100) NOT NULL,
							 description VARCHAR(500),
							 risk_level VARCHAR(50),
							 investment_horizon VARCHAR(100),
							 status VARCHAR(20) NOT NULL DEFAULT 'Active'
							 	CHECK (status IN ('Active','Inactive')),
							 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);
							 
CREATE TABLE theme_allocation(theme_allocation_id SERIAL PRIMARY KEY,
							 theme_id INTEGER NOT NULL,
							 asset_class_id INTEGER NOT NULL,
							 target_percentage NUMERIC(5,2) NOT NULL,
							 minimum_percentage NUMERIC(5,2),
							 maximum_percentage NUMERIC(5,2),
							 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							 CONSTRAINT fk_theme_allocation_theme
							 	FOREIGN KEY(theme_id)
							 	REFERENCES investment_theme(theme_id),
							 CONSTRAINT fk_theme_allocation_asset
							 	FOREIGN KEY(asset_class_id)
							 	REFERENCES asset_class(asset_class_id),
							  CONSTRAINT chk_target_percentage
							  	CHECK(target_percentage >= 0 AND target_percentage <=100),
							  CONSTRAINT chk_minimum_percentage
							  	CHECK( minimum_percentage IS NULL OR ( minimum_percentage >= 0 AND minimum_percentage <=100)),
							  CONSTRAINT chk_maximum_percentage
							  	CHECK( maximum_percentage IS NULL OR ( maximum_percentage >= 0 AND maximum_percentage <=100)),
							  CONSTRAINT chk_allocation_range
							  	CHECK( minimum_percentage IS NULL OR maximum_percentage IS NULL OR minimum_percentage <= maximum_percentage),
							 CONSTRAINT uq_theme_asset
							  	UNIQUE(theme_id, asset_class_id));
								
CREATE TABLE benchmark_master(benchmark_id SERIAL PRIMARY KEY,
							 benchmark_name VARCHAR(150) NOT NULL,
							 benchmark_code VARCHAR(100) NOT NULL UNIQUE,
							 exchange VARCHAR(50),
							 currency VARCHAR(20),
							 country VARCHAR(100),
							 description VARCHAR(500),
							 status VARCHAR(20) NOT NULL DEFAULT 'Active'
							 	CHECK(status IN ('Active', 'Inactive')),
							 source VARCHAR(100),
							 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);
							 
CREATE TABLE benchmark_price_history(benchmark_price_id SERIAL PRIMARY KEY,
									benchmark_id INTEGER NOT NULL,
									price_date DATE NOT NULL,
									close_value NUMERIC(18,4) NOT NULL,
									source VARCHAR(100),
									created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
									CONSTRAINT fk_benchmark_price
										FOREIGN KEY(benchmark_id)
										REFERENCES benchmark_master(benchmark_id),
									 CONSTRAINT uq_benchmark_price
									 	UNIQUE(benchmark_id,price_date));
										
CREATE TABLE portfolio(portfolio_id SERIAL PRIMARY KEY,
					   portfolio_name VARCHAR(150) NOT NULL,
					   portfolio_type VARCHAR(20) NOT NULL,
					   		CHECK(portfolio_type IN ('Weightage','Amount')),
					   currency VARCHAR(20) NOT NULL,
					   exchange VARCHAR(50) NOT NULL,
					   theme_id INTEGER NOT NULL,
					   benchmark_id INTEGER,
					   initial_investment NUMERIC(24,2) NOT NULL
					   		CHECK(initial_investment > 0),
					   available_balance NUMERIC(24,2) NOT NULL
					   		CHECK(available_balance >= 0),
					   rebalancing_frequency VARCHAR(30) NOT NULL
					   		CHECK(rebalancing_frequency IN('Daily','Monthly','Quarterly','Half-Yearly','Yearly')),
					   status VARCHAR(20) NOT NULL DEFAULT 'New'
					   		CHECK(status IN('New','Active','Closed')),
					   created_date DATE NOT NULL DEFAULT CURRENT_DATE,
					   go_live_date DATE,
					   closed_date DATE,
					   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
					   updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
					   CONSTRAINT fk_portfolio_theme
					   		FOREIGN KEY(theme_id)
							REFERENCES investment_theme(theme_id),
					   CONSTRAINT fk_portfolio_benchmark
					   		FOREIGN KEY(benchmark_id)
							REFERENCES benchmark_master(benchmark_id));
							
CREATE TABLE portfolio_holding(holding_id SERIAL PRIMARY KEY,
							   portfolio_id INTEGER NOT NULL,
							   security_id INTEGER NOT NULL,
							   quantity NUMERIC(18,4) NOT NULL,
									CHECK(quantity >= 0),
							   average_buy_price NUMERIC(18,4) NOT NULL
							   		CHECK(average_buy_price >= 0),
							   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							   updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							   CONSTRAINT fk_holding_portfolio
									FOREIGN KEY(portfolio_id)
									REFERENCES portfolio(portfolio_id),
							   CONSTRAINT uq_portfolio_security
									 UNIQUE(portfolio_id,security_id));
									 
CREATE TABLE portfolio_transaction(transaction_id SERIAL PRIMARY KEY,
								   portfolio_id INTEGER NOT NULL,
								   security_id INTEGER NOT NULL,
								   transaction_type VARCHAR(10) NOT NULL
								   		CHECK (transaction_type IN ('BUY', 'SELL')),
								   quantity NUMERIC(18,4) NOT NULL
								   		CHECK (quantity > 0),
								   price NUMERIC(18,4) NOT NULL
								   		CHECK (price >= 0),
								   transaction_amount NUMERIC(24,2) NOT NULL
								   		CHECK (transaction_amount >= 0),
								   transaction_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
								   created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
								   CONSTRAINT fk_transaction_portfolio
        								FOREIGN KEY (portfolio_id)
        								REFERENCES portfolio(portfolio_id),
								   CONSTRAINT fk_transaction_security
        								FOREIGN KEY (security_id)
        								REFERENCES security_master(security_id));
										
CREATE TABLE portfolio_alert(alert_id SERIAL PRIMARY KEY,
							 portfolio_id INTEGER NOT NULL,
							 asset_class_id INTEGER NOT NULL,
							 alert_type VARCHAR(50) NOT NULL,
							 alert_message VARCHAR(500) NOT NULL,
							 target_percentage NUMERIC(5,2),
							 current_percentage NUMERIC(5,2),
							 deviation_percentage NUMERIC(6,2),
							 status VARCHAR(20) NOT NULL DEFAULT 'NEW'
							 	CHECK (status IN ('NEW', 'READ', 'RESOLVED')),
							 generated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
							 resolved_at TIMESTAMP,
							 CONSTRAINT fk_alert_portfolio
        						FOREIGN KEY (portfolio_id)
        						REFERENCES portfolio(portfolio_id),
							 CONSTRAINT fk_alert_asset_class
        						FOREIGN KEY (asset_class_id)
        						REFERENCES asset_class(asset_class_id));
 
 SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name;

CREATE INDEX idx_security_symbol
ON security_master(symbol);
 
CREATE INDEX idx_security_isin
ON security_master(isin);
 
CREATE INDEX idx_security_asset_class
ON security_master(asset_class_id);
 
CREATE INDEX idx_market_price_trade_date
ON market_price_history(trade_date);
 
CREATE INDEX idx_mf_nav_date
ON mutual_fund_nav_history(nav_date);

CREATE INDEX idx_benchmark_price_date
ON benchmark_price_history(price_date);

CREATE INDEX idx_portfolio_theme
ON portfolio(theme_id);
 
CREATE INDEX idx_portfolio_benchmark
ON portfolio(benchmark_id);
 
CREATE INDEX idx_holding_portfolio
ON portfolio_holding(portfolio_id);
 
CREATE INDEX idx_transaction_portfolio
ON portfolio_transaction(portfolio_id);
 
CREATE INDEX idx_alert_portfolio
ON portfolio_alert(portfolio_id);
 
CREATE INDEX idx_alert_status
ON portfolio_alert(status);

INSERT INTO asset_class(asset_class_name,
						asset_description,
						sub_asset_class,
						sub_asset_description,
						risk_level,
						investment_horizon )
						VALUES
						(
							'Equity',
							'Investment representing ownership in companies',
							'Equity Shares',
							'Listed company equity shares',
							'HIGH',
							'LONG_TERM'
						), 
						(
							'Commodity',
							'Investment providing exposure to commodities',
							'Gold',
							'Gold-related investment instruments such as EGR',
							'MEDIUM',
							'MEDIUM_TO_LONG_TERM'
						),
						(
							'Mutual Fund',
							'Investment through pooled mutual fund schemes',
							'Mutual Fund Scheme',
							'Investment through mutual fund schemes',
							'MEDIUM',
							'MEDIUM_TO_LONG_TERM'
						),
						(
							'Digital Asset',
							'Digital investment asset used in the project',
							'Cryptocurrency',
							'Synthetic cryptocurrency instruments used for project demonstration',
							'HIGH',
							'LONG_TERM'
						),
						(
							'Cash',
							'Uninvested portfolio balance',
							'Cash',
							'Available portfolio balance not currently invested',
							'LOW',
							'SHORT_TERM'
						);
						
SELECT
    asset_class_id,
    asset_class_name,
    sub_asset_class,
    risk_level,
    investment_horizon
FROM asset_class
ORDER BY asset_class_id;
 