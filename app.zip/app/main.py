from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database.init_db import (
    initialize_database
)
 
from app.routers import (
    asset_classes ,
    themes ,
    market_data,
    securities,
    portfolios,
    alerts
)
 
app = FastAPI(
 
    title=(
        "NSE Portfolio Management System"
    ),
 
    version="1.0.0"
)
 
app.add_middleware(
    CORSMiddleware,
    allow_origins = [
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

@app.on_event("startup")
def startup():
 
    initialize_database()
 
 
# =========================================================
# ROUTERS
# =========================================================
 
app.include_router(
    asset_classes.router
)
app.include_router( themes.router )
app.include_router( market_data.router )
app.include_router(securities.router)
app.include_router(portfolios.router)
app.include_router(alerts.router)
# =========================================================
# BASIC ROUTES
# =========================================================
 
@app.get("/")
def home():
 
    return {
 
        "message":
            "NSE Portfolio Management "
            "System API is running"
    }
 
 
@app.get("/health")
def health():
 
    return {
 
        "status": "OK"
    }