from typing import Optional, List
from datetime import date
from pydantic import BaseModel
 
 
# =========================================================
# ASSET CLASS SCHEMAS
# =========================================================
 
class AssetClassCreate(BaseModel):
 
    asset_class_name: str
 
    asset_description: Optional[str] = None
 
    sub_asset_class: Optional[str] = None
 
    sub_asset_description: Optional[str] = None
 
    risk_level: Optional[str] = None
 
    investment_horizon: Optional[str] = None
 
 
class AssetClassUpdate(BaseModel):
 
    asset_class_name: str
 
    asset_description: Optional[str] = None
 
    sub_asset_class: Optional[str] = None
 
    sub_asset_description: Optional[str] = None
 
    risk_level: Optional[str] = None
 
    investment_horizon: Optional[str] = None
 
    status: str

# =========================================================
# THEME ALLOCATION INPUT
# =========================================================
 
class ThemeAllocationInput(BaseModel):
 
    asset_class_id: int
 
    allocation_percentage: float
 
 
# =========================================================
# THEME CREATE
# =========================================================
 
class ThemeCreate(BaseModel):
 
    theme_name: str
 
    description: str | None = None
 
    risk_level: str | None = None
 
    investment_horizon: str | None = None
 
    allocations: List[
        ThemeAllocationInput
    ]
 
 
# =========================================================
# THEME UPDATE
# =========================================================
 
class ThemeUpdate(BaseModel):
 
    theme_name: str
 
    description: str | None = None
 
    risk_level: str | None = None
 
    investment_horizon: str | None = None
 
    status: str
 
    allocations: List[
        ThemeAllocationInput
    ]

class PortfolioCreate(BaseModel):
    portfolio_name: str
    portfolio_manager: str
    portfolio_type: str
    theme_id: int
    initial_investment: float 
    portfolio_start_date: date 
    rebalancing_frequency: str

class BuyRequest(BaseModel):
    security_id: int
    transaction_date: date
    value: float

class SellRequest(BaseModel):
    security_id: int
    transaction_date: date
    quantity: int