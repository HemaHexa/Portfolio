from datetime import date

from fastapi import (
    APIRouter,
    HTTPException,
    Query
)

from app.services.security_service import (
    security_service
)


router = APIRouter(
    prefix="/api/securities",
    tags=["Securities"]
)


# =========================================================
# SEARCH SECURITIES
#
# Example:
# /api/securities/search?asset_class_id=1&query=H
# =========================================================

@router.get("/search")
def search_securities(

    asset_class_id: int,

    query: str = Query(
        min_length=1
    )

):

    try:

        return (
            security_service
            .search_securities(
                asset_class_id,
                query
            )
        )

    except ValueError as error:

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )


# =========================================================
# GET ONE SECURITY
# =========================================================

@router.get("/{security_id}")
def get_security(
    security_id: int
):

    try:

        return (
            security_service
            .get_security(
                security_id
            )
        )

    except ValueError as error:

        raise HTTPException(
            status_code=404,
            detail=str(error)
        )


# =========================================================
# HISTORICAL PRICE
#
# Example:
# /api/securities/1/price?transaction_date=2026-08-10
# =========================================================

@router.get(
    "/{security_id}/price"
)
def get_price_for_date(

    security_id: int,

    transaction_date: date

):

    try:

        return (
            security_service
            .get_price_for_date(
                security_id,
                transaction_date
            )
        )

    except ValueError as error:

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )


# =========================================================
# LATEST PRICE
# =========================================================

@router.get(
    "/{security_id}/latest-price"
)
def get_latest_price(
    security_id: int
):

    try:

        return (
            security_service
            .get_latest_price(
                security_id
            )
        )

    except ValueError as error:

        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
