from fastapi import (
    APIRouter,
    HTTPException
)
 
from app.services.market_data_service import (
    market_data_service
)
 
 
router = APIRouter(
 
    prefix="/api/market-data",
 
    tags=[
        "Market Data"
    ]
)
 
 
@router.post(
    "/download-nse-securities"
)
def download_nse_securities():
 
    try:
 
        return (
            market_data_service
            .download_nse_security_master()
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 