from fastapi import (
    APIRouter,
    HTTPException
)

from app.services.alert_service import (
    alert_service
)


router = APIRouter(
    prefix="/api/alerts",
    tags=["Alerts"]
)


# =========================================================
# GLOBAL ALERTS
# =========================================================

@router.get("")
def get_all_alerts():

    return (
        alert_service
        .get_all_alerts()
    )


# =========================================================
# ACKNOWLEDGE ALERT
#
# Accept button means READ only.
# It does NOT execute a trade.
# =========================================================

@router.put(
    "/{alert_id}/read"
)
def mark_alert_read(
    alert_id: int
):

    try:

        return (
            alert_service
            .mark_read(
                alert_id
            )
        )

    except ValueError as error:

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )