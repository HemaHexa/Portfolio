from fastapi import (
    APIRouter,
    HTTPException
)
 
from app.schemas import (
    ThemeCreate,
    ThemeUpdate
)
 
from app.services.theme_service import (
    theme_service
)
 
 
router = APIRouter(
 
    prefix="/api/themes",
 
    tags=[
        "Investment Themes"
    ]
)
 
 
# =========================================================
# CREATE
# =========================================================
 
@router.post("")
def create_theme(
    data: ThemeCreate
):
 
    try:
 
        return (
            theme_service
            .create_theme(
                data
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
 
# =========================================================
# GET ALL
# =========================================================
 
@router.get("")
def get_all_themes():
 
    return (
        theme_service
        .get_all_themes()
    )
 
 
# =========================================================
# GET ONE
# =========================================================
 
@router.get("/{theme_id}")
def get_theme_by_id(
    theme_id: int
):
 
    try:
 
        return (
            theme_service
            .get_theme_by_id(
                theme_id
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
 
# =========================================================
# UPDATE
# =========================================================
 
@router.put("/{theme_id}")
def update_theme(
 
    theme_id: int,
 
    data: ThemeUpdate
):
 
    try:
 
        return (
            theme_service
            .update_theme(
                theme_id,
                data
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
 
# =========================================================
# DELETE / DEACTIVATE
# =========================================================
 
@router.delete("/{theme_id}")
def delete_theme(
    theme_id: int
):
 
    try:
 
        return (
            theme_service
            .deactivate_theme(
                theme_id
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )