from fastapi import (
    APIRouter,
    HTTPException
)
 
from app.schemas import (
    AssetClassCreate,
    AssetClassUpdate
)
 
from app.services.asset_class_service import (
    asset_class_service
)
 
 
router = APIRouter(
 
    prefix="/api/asset-classes",
 
    tags=[
        "Asset Classes"
    ]
)
 
 
# =========================================================
# CREATE
# =========================================================
 
@router.post("")
def create_asset_class(
    data: AssetClassCreate
):
 
    try:
 
        return (
            asset_class_service
            .create_asset_class(
                data
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
 
# =========================================================
# GET ALL
# =========================================================
 
@router.get("")
def get_all_asset_classes():
 
    return (
        asset_class_service
        .get_all_asset_classes()
    )
 
 
# =========================================================
# GET BY ID
# =========================================================
 
@router.get("/{asset_class_id}")
def get_asset_class_by_id(
    asset_class_id: int
):
 
    try:
 
        return (
            asset_class_service
            .get_asset_class_by_id(
                asset_class_id
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
 
# =========================================================
# UPDATE
# =========================================================
 
@router.put("/{asset_class_id}")
def update_asset_class(
 
    asset_class_id: int,
 
    data: AssetClassUpdate
):
 
    try:
 
        return (
            asset_class_service
            .update_asset_class(
                asset_class_id,
                data
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
 
# =========================================================
# DELETE / DEACTIVATE
# =========================================================
 
@router.delete("/{asset_class_id}")
def delete_asset_class(
    asset_class_id: int
):
 
    try:
 
        return (
            asset_class_service
            .delete_asset_class(
                asset_class_id
            )
        )
 
 
    except ValueError as error:
 
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 