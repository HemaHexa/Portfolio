import os 
from dotenv import load_dotenv

load_dotenv()

EODHD_API_TOKEN = os.getenv("EODHD_API_TOKEN")
EODHD_BASE_URL = ("https://eodhd.com/api")
NSE_EXCHANGE_CODE = "NSE"