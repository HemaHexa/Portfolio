from app.database.connection import get_db_connection


class PortfolioRepository:


    # =====================================================
    # CREATE PORTFOLIO
    # =====================================================

    def create_portfolio(
        self,
        data
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                INSERT INTO portfolio (

                    portfolio_name,
                    portfolio_manager,
                    portfolio_type,

                    currency,
                    exchange,

                    theme_id,

                    benchmark_name,
                    benchmark_key,

                    initial_investment,
                    available_balance,

                    portfolio_start_date,

                    rebalancing_frequency,

                    status

                )

                VALUES (

                    %s,
                    %s,
                    %s,

                    'INR',
                    'NSE',

                    %s,

                    'NIFTY 50',
                    'NIFTY50',

                    %s,
                    %s,

                    %s,

                    %s,

                    'New'
                )

                RETURNING *
            """, (

                data.portfolio_name,
                data.portfolio_manager,
                data.portfolio_type,

                data.theme_id,

                data.initial_investment,
                data.initial_investment,

                data.portfolio_start_date,

                data.rebalancing_frequency
            ))


            portfolio = (
                cursor.fetchone()
            )

            conn.commit()

            return portfolio


        except Exception:

            conn.rollback()
            raise


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET ALL PORTFOLIOS
    # =====================================================

    def get_all_portfolios(self):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    p.*,

                    t.theme_name

                FROM portfolio p

                JOIN investment_theme t
                    ON p.theme_id =
                       t.theme_id

                ORDER BY
                    p.portfolio_id DESC
            """)

            return cursor.fetchall()


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET ONE PORTFOLIO
    # =====================================================

    def get_portfolio(
        self,
        portfolio_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    p.*,

                    t.theme_name

                FROM portfolio p

                JOIN investment_theme t
                    ON p.theme_id =
                       t.theme_id

                WHERE
                    p.portfolio_id = %s
            """, (
                portfolio_id,
            ))

            return cursor.fetchone()


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # CHECK THEME
    # =====================================================

    def get_theme(
        self,
        theme_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    *

                FROM investment_theme

                WHERE
                    theme_id = %s

                    AND
                    status = 'ACTIVE'
            """, (
                theme_id,
            ))

            return cursor.fetchone()


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET BENCHMARK PRICE FOR START DATE
    #
    # Previous trading date automatically selected
    # when start date is weekend / market holiday.
    # =====================================================

    def get_benchmark_price(
        self,
        portfolio_start_date
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    benchmark_code,
                    benchmark_name,
                    price_date,
                    close_value

                FROM benchmark_price_history

                WHERE
                    benchmark_code = 'NIFTY50'

                    AND
                    price_date <= %s

                ORDER BY
                    price_date DESC

                LIMIT 1
            """, (
                portfolio_start_date,
            ))

            return cursor.fetchone()


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # ACTIVATE PORTFOLIO
    # =====================================================

    def activate_portfolio(
        self,
        portfolio_id,
        benchmark_value
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                UPDATE portfolio

                SET

                    status = 'Active',

                    benchmark_start_value = %s,

                    benchmark_name =
                        'NIFTY 50',

                    benchmark_key =
                        'NIFTY50',

                    activated_at =
                        CURRENT_TIMESTAMP

                WHERE
                    portfolio_id = %s

                RETURNING *
            """, (

                benchmark_value,

                portfolio_id
            ))


            portfolio = (
                cursor.fetchone()
            )

            conn.commit()

            return portfolio


        except Exception:

            conn.rollback()
            raise


        finally:

            cursor.close()
            conn.close()


portfolio_repository = (
    PortfolioRepository()
)