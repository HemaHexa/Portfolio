from typing import Optional
 
from pydantic import BaseModel
 
 
# =========================================================
# ASSET CLASS SCHEMAS
# =========================================================
 
class AssetClassCreate(BaseModel):
 
    asset_class_name: str
 
    asset_description: Optional[str] = None
 
    sub_asset_class: Optional[str] = None
 
    sub_asset_description: Optional[str] = None
 
    risk_level: Optional[str] = None
 
    investment_horizon: Optional[str] = None
 
 
class AssetClassUpdate(BaseModel):
 
    asset_class_name: str
 
    asset_description: Optional[str] = None
 
    sub_asset_class: Optional[str] = None
 
    sub_asset_description: Optional[str] = None
 
    risk_level: Optional[str] = None
 
    investment_horizon: Optional[str] = None
 
    status: str
 
from app.database.connection import (
    get_db_connection
)
 
 
class AssetClassRepository:
 
 
    # =====================================================
    # CREATE
    # =====================================================
 
    def create_asset_class(
        self,
        asset_class_name,
        asset_description,
        sub_asset_class,
        sub_asset_description,
        risk_level,
        investment_horizon
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                INSERT INTO asset_class (
 
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon
 
                )
                VALUES (
                    %s, %s, %s,
                    %s, %s, %s
                )
 
                RETURNING asset_class_id;
                """,
                (
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon
                )
            )
 
 
            row = cursor.fetchone()
 
            asset_class_id = (
                row["asset_class_id"]
            )
 
 
            conn.commit()
 
            return asset_class_id
 
 
        except Exception:
 
            conn.rollback()
            raise
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # GET ALL
    # =====================================================
 
    def get_all_asset_classes(self):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
 
                    asset_class_id,
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon,
                    status,
                    created_at,
                    updated_at
 
                FROM asset_class
 
                ORDER BY asset_class_id;
                """
            )
 
 
            return cursor.fetchall()
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # GET ONE
    # =====================================================
 
    def get_asset_class_by_id(
        self,
        asset_class_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
 
                    asset_class_id,
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon,
                    status,
                    created_at,
                    updated_at
 
                FROM asset_class
 
                WHERE asset_class_id = %s;
                """,
                (
                    asset_class_id,
                )
            )
 
 
            return cursor.fetchone()
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # CHECK NAME
    # =====================================================
 
    def get_asset_class_by_name(
        self,
        asset_class_name
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                SELECT
                    asset_class_id,
                    asset_class_name
 
                FROM asset_class
 
                WHERE LOWER(asset_class_name)
                    = LOWER(%s);
                """,
                (
                    asset_class_name,
                )
            )
 
 
            return cursor.fetchone()
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # UPDATE
    # =====================================================
 
    def update_asset_class(
        self,
        asset_class_id,
        asset_class_name,
        asset_description,
        sub_asset_class,
        sub_asset_description,
        risk_level,
        investment_horizon,
        status
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute(
                """
                UPDATE asset_class
 
                SET
 
                    asset_class_name = %s,
 
                    asset_description = %s,
 
                    sub_asset_class = %s,
 
                    sub_asset_description = %s,
 
                    risk_level = %s,
 
                    investment_horizon = %s,
 
                    status = %s,
 
                    updated_at =
                        CURRENT_TIMESTAMP
 
                WHERE asset_class_id = %s;
                """,
                (
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon,
                    status,
                    asset_class_id
                )
            )
 
 
            conn.commit()
 
 
        except Exception:
 
            conn.rollback()
            raise
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # DELETE / DEACTIVATE
    # =====================================================
 
    def delete_asset_class(
        self,
        asset_class_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            # We are NOT physically deleting.
            #
            # Asset Class may already be used by
            # themes / securities / alerts.
            #
            # So DELETE means:
            #
            # ACTIVE -> INACTIVE
 
            cursor.execute(
                """
                UPDATE asset_class
 
                SET
 
                    status = 'INACTIVE',
 
                    updated_at =
                        CURRENT_TIMESTAMP
 
                WHERE asset_class_id = %s;
                """,
                (
                    asset_class_id,
                )
            )
 
 
            conn.commit()
 
 
        except Exception:
 
            conn.rollback()
            raise
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
asset_class_repository = (
    AssetClassRepository()
)
 