from app.database.connection import get_db_connection


class AlertRepository:


    # =====================================================
    # GET EXISTING ACTIVE ALERT
    # =====================================================

    def get_active_alert(
        self,
        portfolio_id,
        asset_class_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    *

                FROM portfolio_alert

                WHERE
                    portfolio_id = %s

                    AND
                    asset_class_id = %s

                    AND
                    status IN (
                        'NEW',
                        'READ'
                    )

                ORDER BY
                    alert_id DESC

                LIMIT 1
            """, (
                portfolio_id,
                asset_class_id
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # CREATE ALERT
    # =====================================================

    def create_alert(
        self,
        portfolio_id,
        asset_class_id,
        message,
        target_percentage,
        current_percentage,
        deviation_percentage,
        action,
        amount
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                INSERT INTO portfolio_alert (

                    portfolio_id,
                    asset_class_id,

                    alert_type,
                    alert_message,

                    target_percentage,
                    current_percentage,
                    deviation_percentage,

                    recommendation_action,
                    recommendation_amount,

                    status

                )

                VALUES (

                    %s,
                    %s,

                    'ALLOCATION_DEVIATION',
                    %s,

                    %s,
                    %s,
                    %s,

                    %s,
                    %s,

                    'NEW'
                )

                RETURNING *
            """, (

                portfolio_id,
                asset_class_id,

                message,

                target_percentage,
                current_percentage,
                deviation_percentage,

                action,
                amount

            ))

            alert = cursor.fetchone()

            conn.commit()

            return alert

        except Exception:

            conn.rollback()
            raise

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # UPDATE EXISTING ALERT
    # =====================================================

    def update_alert(
        self,
        alert_id,
        message,
        target_percentage,
        current_percentage,
        deviation_percentage,
        action,
        amount
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                UPDATE portfolio_alert

                SET
                    alert_message = %s,

                    target_percentage = %s,

                    current_percentage = %s,

                    deviation_percentage = %s,

                    recommendation_action = %s,

                    recommendation_amount = %s,

                    generated_at =
                        CURRENT_TIMESTAMP

                WHERE
                    alert_id = %s

                RETURNING *
            """, (

                message,
                target_percentage,
                current_percentage,
                deviation_percentage,
                action,
                amount,
                alert_id

            ))

            alert = cursor.fetchone()

            conn.commit()

            return alert

        except Exception:

            conn.rollback()
            raise

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # RESOLVE ALERT
    # =====================================================

    def resolve_alert(
        self,
        alert_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                UPDATE portfolio_alert

                SET
                    status = 'RESOLVED',

                    resolved_at =
                        CURRENT_TIMESTAMP

                WHERE
                    alert_id = %s
            """, (
                alert_id,
            ))

            conn.commit()

        except Exception:

            conn.rollback()
            raise

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # MARK READ
    # =====================================================

    def mark_read(
        self,
        alert_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                UPDATE portfolio_alert

                SET
                    status = 'READ'

                WHERE
                    alert_id = %s

                    AND
                    status = 'NEW'

                RETURNING *
            """, (
                alert_id,
            ))

            alert = cursor.fetchone()

            conn.commit()

            return alert

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET PORTFOLIO ALERTS
    # =====================================================

    def get_portfolio_alerts(
        self,
        portfolio_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    pa.*,
                    ac.asset_class_name

                FROM portfolio_alert pa

                JOIN asset_class ac
                    ON pa.asset_class_id =
                       ac.asset_class_id

                WHERE
                    pa.portfolio_id = %s

                ORDER BY
                    pa.alert_id DESC
            """, (
                portfolio_id,
            ))

            return cursor.fetchall()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GLOBAL ALERTS
    # =====================================================

    def get_all_alerts(self):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    pa.*,
                    p.portfolio_name,
                    ac.asset_class_name

                FROM portfolio_alert pa

                JOIN portfolio p
                    ON pa.portfolio_id =
                       p.portfolio_id

                JOIN asset_class ac
                    ON pa.asset_class_id =
                       ac.asset_class_id

                ORDER BY
                    pa.alert_id DESC
            """)

            return cursor.fetchall()

        finally:

            cursor.close()
            conn.close()


alert_repository = AlertRepository()