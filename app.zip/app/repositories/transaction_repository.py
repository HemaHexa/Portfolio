from app.database.connection import get_db_connection


class TransactionRepository:


    # =====================================================
    # GET PORTFOLIO
    # =====================================================

    def get_portfolio(
        self,
        portfolio_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    *

                FROM portfolio

                WHERE
                    portfolio_id = %s
            """, (
                portfolio_id,
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET SECURITY
    # =====================================================

    def get_security(
        self,
        security_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    sm.*,
                    ac.asset_class_name

                FROM security_master sm

                JOIN asset_class ac
                    ON sm.asset_class_id =
                       ac.asset_class_id

                WHERE
                    sm.security_id = %s

                    AND
                    sm.status = 'ACTIVE'
            """, (
                security_id,
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # HISTORICAL TRANSACTION PRICE
    #
    # If date is holiday/weekend,
    # nearest previous trading date is used.
    # =====================================================

    def get_price_for_date(
        self,
        security_id,
        transaction_date
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    trade_date,
                    close_price,
                    source

                FROM market_price_history

                WHERE
                    security_id = %s

                    AND
                    trade_date <= %s

                ORDER BY
                    trade_date DESC

                LIMIT 1
            """, (
                security_id,
                transaction_date
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET CURRENT / LATEST PRICE
    # =====================================================

    def get_latest_price(
        self,
        security_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    trade_date,
                    close_price,
                    source

                FROM market_price_history

                WHERE
                    security_id = %s

                ORDER BY
                    trade_date DESC

                LIMIT 1
            """, (
                security_id,
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET CURRENT PORTFOLIO VALUE
    #
    # Current Portfolio Value =
    # available cash + latest value of holdings
    # =====================================================

    def get_portfolio_current_value(
        self,
        portfolio_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    p.available_balance
                    +
                    COALESCE(
                        SUM(
                            ph.quantity
                            *
                            latest.close_price
                        ),
                        0
                    )
                    AS current_portfolio_value

                FROM portfolio p

                LEFT JOIN portfolio_holding ph
                    ON p.portfolio_id =
                       ph.portfolio_id

                LEFT JOIN LATERAL (

                    SELECT
                        mph.close_price

                    FROM market_price_history mph

                    WHERE
                        mph.security_id =
                            ph.security_id

                    ORDER BY
                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE

                WHERE
                    p.portfolio_id = %s

                GROUP BY
                    p.portfolio_id,
                    p.available_balance
            """, (
                portfolio_id,
            ))

            row = cursor.fetchone()

            if not row:
                return None

            return row[
                "current_portfolio_value"
            ]

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # CURRENT VALUE OF ONE ASSET CLASS
    # =====================================================

    def get_asset_class_current_value(
        self,
        portfolio_id,
        asset_class_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    COALESCE(
                        SUM(
                            ph.quantity
                            *
                            latest.close_price
                        ),
                        0
                    )
                    AS asset_value

                FROM portfolio_holding ph

                JOIN security_master sm
                    ON ph.security_id =
                       sm.security_id

                LEFT JOIN LATERAL (

                    SELECT
                        mph.close_price

                    FROM market_price_history mph

                    WHERE
                        mph.security_id =
                            ph.security_id

                    ORDER BY
                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE

                WHERE
                    ph.portfolio_id = %s

                    AND
                    sm.asset_class_id = %s
            """, (
                portfolio_id,
                asset_class_id
            ))

            row = cursor.fetchone()

            return row["asset_value"]

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET THEME LIMIT
    # =====================================================

    def get_theme_allocation(
        self,
        theme_id,
        asset_class_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    allocation_percentage

                FROM theme_allocation

                WHERE
                    theme_id = %s

                    AND
                    asset_class_id = %s
            """, (
                theme_id,
                asset_class_id
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # EXECUTE BUY
    #
    # Holding + transaction + cash update happen
    # in ONE database transaction.
    # =====================================================

    def execute_buy(
        self,
        portfolio_id,
        security_id,
        quantity,
        buy_price,
        transaction_amount,
        transaction_date
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            # ---------------------------------------------
            # Lock portfolio during purchase
            # ---------------------------------------------

            cursor.execute("""
                SELECT
                    available_balance

                FROM portfolio

                WHERE
                    portfolio_id = %s

                FOR UPDATE
            """, (
                portfolio_id,
            ))

            portfolio = cursor.fetchone()


            if not portfolio:

                raise ValueError(
                    "Portfolio not found"
                )


            if (
                portfolio["available_balance"]
                <
                transaction_amount
            ):

                raise ValueError(
                    "Insufficient available balance"
                )


            # ---------------------------------------------
            # Existing holding
            # ---------------------------------------------

            cursor.execute("""
                SELECT
                    *

                FROM portfolio_holding

                WHERE
                    portfolio_id = %s

                    AND
                    security_id = %s

                FOR UPDATE
            """, (
                portfolio_id,
                security_id
            ))

            holding = cursor.fetchone()


            # ---------------------------------------------
            # If already owned:
            # calculate weighted average buy price
            # ---------------------------------------------

            if holding:

                old_quantity = (
                    holding["quantity"]
                )

                old_average = (
                    holding[
                        "average_buy_price"
                    ]
                )


                new_quantity = (
                    old_quantity
                    +
                    quantity
                )


                new_average = (

                    (
                        old_quantity
                        *
                        old_average
                    )

                    +

                    (
                        quantity
                        *
                        buy_price
                    )

                ) / new_quantity


                cursor.execute("""
                    UPDATE portfolio_holding

                    SET
                        quantity = %s,

                        average_buy_price = %s,

                        updated_at =
                            CURRENT_TIMESTAMP

                    WHERE
                        holding_id = %s

                    RETURNING *
                """, (

                    new_quantity,

                    new_average,

                    holding["holding_id"]

                ))


            # ---------------------------------------------
            # First purchase
            # ---------------------------------------------

            else:

                cursor.execute("""
                    INSERT INTO portfolio_holding (

                        portfolio_id,
                        security_id,
                        quantity,
                        average_buy_price

                    )

                    VALUES (
                        %s,
                        %s,
                        %s,
                        %s
                    )

                    RETURNING *
                """, (

                    portfolio_id,

                    security_id,

                    quantity,

                    buy_price

                ))


            updated_holding = (
                cursor.fetchone()
            )


            # ---------------------------------------------
            # Save BUY transaction
            # ---------------------------------------------

            cursor.execute("""
                INSERT INTO portfolio_transaction (

                    portfolio_id,

                    security_id,

                    transaction_type,

                    quantity,

                    price,

                    transaction_amount,

                    transaction_date

                )

                VALUES (

                    %s,
                    %s,
                    'BUY',
                    %s,
                    %s,
                    %s,
                    %s

                )

                RETURNING *
            """, (

                portfolio_id,

                security_id,

                quantity,

                buy_price,

                transaction_amount,

                transaction_date

            ))


            transaction = (
                cursor.fetchone()
            )


            # ---------------------------------------------
            # Reduce cash
            # ---------------------------------------------

            cursor.execute("""
                UPDATE portfolio

                SET
                    available_balance =
                        available_balance - %s

                WHERE
                    portfolio_id = %s

                RETURNING
                    available_balance
            """, (

                transaction_amount,

                portfolio_id

            ))


            balance = (
                cursor.fetchone()
            )


            conn.commit()


            return {

                "holding":
                    updated_holding,

                "transaction":
                    transaction,

                "available_balance":
                    balance[
                        "available_balance"
                    ]
            }


        except Exception:

            conn.rollback()
            raise


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET HOLDINGS
    # =====================================================

    def get_holdings(
        self,
        portfolio_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    ph.holding_id,

                    ph.portfolio_id,

                    ph.security_id,

                    sm.symbol,

                    sm.security_name,

                    ac.asset_class_name,

                    ph.quantity,

                    ph.average_buy_price,

                    latest.trade_date
                        AS latest_price_date,

                    latest.close_price
                        AS latest_price,

                    (
                        ph.quantity
                        *
                        ph.average_buy_price
                    )
                        AS invested_value,

                    (
                        ph.quantity
                        *
                        latest.close_price
                    )
                        AS current_value,

                    (
                        ph.quantity
                        *
                        (
                            latest.close_price
                            -
                            ph.average_buy_price
                        )
                    )
                        AS profit_loss

                FROM portfolio_holding ph

                JOIN security_master sm
                    ON ph.security_id =
                       sm.security_id

                JOIN asset_class ac
                    ON sm.asset_class_id =
                       ac.asset_class_id

                LEFT JOIN LATERAL (

                    SELECT
                        mph.trade_date,
                        mph.close_price

                    FROM market_price_history mph

                    WHERE
                        mph.security_id =
                            ph.security_id

                    ORDER BY
                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE

                WHERE
                    ph.portfolio_id = %s

                ORDER BY
                    sm.symbol
            """, (
                portfolio_id,
            ))

            return cursor.fetchall()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET TRANSACTIONS
    # =====================================================

    def get_transactions(
        self,
        portfolio_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    pt.transaction_id,

                    pt.portfolio_id,

                    pt.security_id,

                    sm.symbol,

                    sm.security_name,

                    pt.transaction_type,

                    pt.quantity,

                    pt.price,

                    pt.transaction_amount,

                    pt.transaction_date,

                    pt.created_at

                FROM portfolio_transaction pt

                JOIN security_master sm
                    ON pt.security_id =
                       sm.security_id

                WHERE
                    pt.portfolio_id = %s

                ORDER BY
                    pt.transaction_id DESC
            """, (
                portfolio_id,
            ))

            return cursor.fetchall()

        finally:

            cursor.close()
            conn.close()

    # =====================================================
    # GET ONE HOLDING
    # =====================================================

    def get_holding(
        self,
        portfolio_id,
        security_id
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    *

                FROM portfolio_holding

                WHERE
                    portfolio_id = %s
                    AND
                    security_id = %s
            """, (
                portfolio_id,
                security_id
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # EXECUTE SELL
    # =====================================================

    def execute_sell(
        self,
        portfolio_id,
        security_id,
        quantity,
        sell_price,
        transaction_amount,
        transaction_date
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            # ---------------------------------------------
            # Lock holding
            # ---------------------------------------------

            cursor.execute("""
                SELECT
                    *

                FROM portfolio_holding

                WHERE
                    portfolio_id = %s
                    AND
                    security_id = %s

                FOR UPDATE
            """, (
                portfolio_id,
                security_id
            ))

            holding = cursor.fetchone()


            if not holding:

                raise ValueError(
                    "Security is not available "
                    "in this portfolio"
                )


            current_quantity = (
                holding["quantity"]
            )


            if quantity > current_quantity:

                raise ValueError(
                    f"Cannot sell {quantity} units. "
                    f"Only {current_quantity} units "
                    f"are available."
                )


            # ---------------------------------------------
            # Remaining Quantity
            # ---------------------------------------------

            remaining_quantity = (
                current_quantity
                -
                quantity
            )


            # ---------------------------------------------
            # Full Sell
            # ---------------------------------------------

            if remaining_quantity == 0:

                cursor.execute("""
                    DELETE FROM portfolio_holding

                    WHERE
                        holding_id = %s
                """, (
                    holding["holding_id"],
                ))


            # ---------------------------------------------
            # Partial Sell
            #
            # Average Buy Price remains unchanged.
            # ---------------------------------------------

            else:

                cursor.execute("""
                    UPDATE portfolio_holding

                    SET
                        quantity = %s,

                        updated_at =
                            CURRENT_TIMESTAMP

                    WHERE
                        holding_id = %s
                """, (
                    remaining_quantity,
                    holding["holding_id"]
                ))


            # ---------------------------------------------
            # Save SELL transaction
            # ---------------------------------------------

            cursor.execute("""
                INSERT INTO portfolio_transaction (

                    portfolio_id,

                    security_id,

                    transaction_type,

                    quantity,

                    price,

                    transaction_amount,

                    transaction_date

                )

                VALUES (
                    %s,
                    %s,
                    'SELL',
                    %s,
                    %s,
                    %s,
                    %s
                )

                RETURNING *
            """, (

                portfolio_id,

                security_id,

                quantity,

                sell_price,

                transaction_amount,

                transaction_date

            ))


            transaction = (
                cursor.fetchone()
            )


            # ---------------------------------------------
            # SELL adds money back to Cash
            # ---------------------------------------------

            cursor.execute("""
                UPDATE portfolio

                SET
                    available_balance =
                        available_balance + %s

                WHERE
                    portfolio_id = %s

                RETURNING
                    available_balance
            """, (
                transaction_amount,
                portfolio_id
            ))


            balance = (
                cursor.fetchone()
            )


            conn.commit()


            return {

                "transaction":
                    transaction,

                "remaining_quantity":
                    remaining_quantity,

                "available_balance":
                    balance[
                        "available_balance"
                    ]
            }


        except Exception:

            conn.rollback()
            raise


        finally:

            cursor.close()
            conn.close()
            
transaction_repository = (
    TransactionRepository()
)