from app.database.connection import (
    get_db_connection
)
 
 
class ThemeRepository:
 
 
    # =====================================================
    # GET ALL THEMES
    # =====================================================
 
    def get_all_themes(self):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
 
                    theme_id,
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status,
                    created_at,
                    updated_at
 
                FROM investment_theme
 
                ORDER BY theme_id;
            """)
 
            themes = cursor.fetchall()
 
            result = []
 
 
            for theme in themes:
 
                cursor.execute("""
                    SELECT
 
                        ta.theme_allocation_id,
 
                        ta.asset_class_id,
 
                        ac.asset_class_name,
 
                        ta.allocation_percentage
 
                    FROM theme_allocation ta
 
                    JOIN asset_class ac
 
                        ON ta.asset_class_id
                        =
                        ac.asset_class_id
 
                    WHERE ta.theme_id = %s
 
                    ORDER BY
                        ta.asset_class_id;
                """, (
                    theme["theme_id"],
                ))
 
 
                allocations = (
                    cursor.fetchall()
                )
 
 
                result.append({
 
                    "theme_id":
                        theme["theme_id"],
 
                    "theme_name":
                        theme["theme_name"],
 
                    "description":
                        theme["description"],
 
                    "risk_level":
                        theme["risk_level"],
 
                    "investment_horizon":
                        theme[
                            "investment_horizon"
                        ],
 
                    "status":
                        theme["status"],
 
                    "allocations":
                        allocations,
 
                    "created_at":
                        theme["created_at"],
 
                    "updated_at":
                        theme["updated_at"]
                })
 
 
            return result
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # GET THEME BY ID
    # =====================================================
 
    def get_theme_by_id(
        self,
        theme_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
 
                    theme_id,
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status,
                    created_at,
                    updated_at
 
                FROM investment_theme
 
                WHERE theme_id = %s;
            """, (
                theme_id,
            ))
 
 
            theme = cursor.fetchone()
 
 
            if theme is None:
 
                return None
 
 
            cursor.execute("""
                SELECT
 
                    ta.theme_allocation_id,
 
                    ta.asset_class_id,
 
                    ac.asset_class_name,
 
                    ta.allocation_percentage
 
                FROM theme_allocation ta
 
                JOIN asset_class ac
 
                    ON ta.asset_class_id
                    =
                    ac.asset_class_id
 
                WHERE ta.theme_id = %s
 
                ORDER BY
                    ta.asset_class_id;
            """, (
                theme_id,
            ))
 
 
            allocations = (
                cursor.fetchall()
            )
 
 
            return {
 
                "theme_id":
                    theme["theme_id"],
 
                "theme_name":
                    theme["theme_name"],
 
                "description":
                    theme["description"],
 
                "risk_level":
                    theme["risk_level"],
 
                "investment_horizon":
                    theme[
                        "investment_horizon"
                    ],
 
                "status":
                    theme["status"],
 
                "allocations":
                    allocations,
 
                "created_at":
                    theme["created_at"],
 
                "updated_at":
                    theme["updated_at"]
            }
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # GET THEME BY NAME
    # =====================================================
 
    def get_theme_by_name(
        self,
        theme_name
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
 
                    theme_id,
                    theme_name
 
                FROM investment_theme
 
                WHERE LOWER(theme_name)
                    =
                    LOWER(%s);
            """, (
                theme_name,
            ))
 
 
            return cursor.fetchone()
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # GET ACTIVE ASSET CLASSES
    # =====================================================
 
    def get_active_asset_classes(
        self
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                SELECT
 
                    asset_class_id,
                    asset_class_name
 
                FROM asset_class
 
                WHERE status = 'ACTIVE'
 
                ORDER BY asset_class_id;
            """)
 
 
            return cursor.fetchall()
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # CREATE THEME
    # =====================================================
 
    def create_theme(
        self,
        theme_name,
        description,
        risk_level,
        investment_horizon,
        allocations
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            # ---------------------------------------------
            # Insert theme
            # ---------------------------------------------
 
            cursor.execute("""
                INSERT INTO investment_theme (
 
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon
 
                )
 
                VALUES (
                    %s, %s, %s, %s
                )
 
                RETURNING theme_id;
            """, (
                theme_name,
                description,
                risk_level,
                investment_horizon
            ))
 
 
            row = cursor.fetchone()
 
            theme_id = (
                row["theme_id"]
            )
 
 
            # ---------------------------------------------
            # Insert allocations
            # ---------------------------------------------
 
            for item in allocations:
 
                cursor.execute("""
                    INSERT INTO theme_allocation (
 
                        theme_id,
                        asset_class_id,
                        allocation_percentage
 
                    )
 
                    VALUES (
                        %s, %s, %s
                    );
                """, (
                    theme_id,
                    item.asset_class_id,
                    item.allocation_percentage
                ))
 
 
            conn.commit()
 
            return theme_id
 
 
        except Exception:
 
            conn.rollback()
            raise
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # UPDATE THEME
    # =====================================================
 
    def update_theme(
        self,
        theme_id,
        theme_name,
        description,
        risk_level,
        investment_horizon,
        status,
        allocations
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            # ---------------------------------------------
            # Update header
            # ---------------------------------------------
 
            cursor.execute("""
                UPDATE investment_theme
 
                SET
 
                    theme_name = %s,
 
                    description = %s,
 
                    risk_level = %s,
 
                    investment_horizon = %s,
 
                    status = %s,
 
                    updated_at =
                        CURRENT_TIMESTAMP
 
                WHERE theme_id = %s;
            """, (
                theme_name,
                description,
                risk_level,
                investment_horizon,
                status,
                theme_id
            ))
 
 
            # ---------------------------------------------
            # Delete previous allocations
            # ---------------------------------------------
 
            cursor.execute("""
                DELETE FROM theme_allocation
 
                WHERE theme_id = %s;
            """, (
                theme_id,
            ))
 
 
            # ---------------------------------------------
            # Insert new allocations
            # ---------------------------------------------
 
            for item in allocations:
 
                cursor.execute("""
                    INSERT INTO theme_allocation (
 
                        theme_id,
                        asset_class_id,
                        allocation_percentage
 
                    )
 
                    VALUES (
                        %s, %s, %s
                    );
                """, (
                    theme_id,
                    item.asset_class_id,
                    item.allocation_percentage
                ))
 
 
            conn.commit()
 
 
        except Exception:
 
            conn.rollback()
            raise
 
 
        finally:
 
            cursor.close()
            conn.close()
 
 
    # =====================================================
    # DELETE / DEACTIVATE
    # =====================================================
 
    def deactivate_theme(
        self,
        theme_id
    ):
 
        conn = get_db_connection()
        cursor = conn.cursor()
 
        try:
 
            cursor.execute("""
                UPDATE investment_theme
 
                SET
 
                    status = 'INACTIVE',
 
                    updated_at =
                        CURRENT_TIMESTAMP
 
                WHERE theme_id = %s;
            """, (
                theme_id,
            ))
 
 
            conn.commit()
 
 
        except Exception:
 
            conn.rollback()
            raise
 
        finally:
            cursor.close()
            conn.close()
 
 
theme_repository = (
    ThemeRepository()
)
 