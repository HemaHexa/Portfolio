from app.database.connection import get_db_connection


class SecurityRepository:


    # =====================================================
    # SEARCH SECURITIES
    # =====================================================

    def search_securities(
        self,
        asset_class_id: int,
        query: str
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            search_value = (
                f"%{query.strip()}%"
            )

            cursor.execute("""
                SELECT
                    sm.security_id,
                    sm.instrument_key,
                    sm.exchange,
                    sm.symbol,
                    sm.security_name,
                    sm.isin,
                    sm.instrument_type,
                    sm.asset_class_id,
                    ac.asset_class_name,
                    sm.last_price,
                    sm.price_updated_at,
                    sm.data_source,
                    sm.status

                FROM security_master sm

                JOIN asset_class ac
                    ON sm.asset_class_id =
                       ac.asset_class_id

                WHERE
                    sm.asset_class_id = %s

                    AND sm.status = 'ACTIVE'

                    AND (
                        sm.symbol ILIKE %s
                        OR
                        sm.security_name ILIKE %s
                    )

                ORDER BY
                    sm.symbol

                LIMIT 20
            """, (
                asset_class_id,
                search_value,
                search_value
            ))

            return cursor.fetchall()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET SECURITY
    # =====================================================

    def get_security(
        self,
        security_id: int
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    sm.security_id,
                    sm.instrument_key,
                    sm.exchange,
                    sm.symbol,
                    sm.security_name,
                    sm.isin,
                    sm.instrument_type,
                    sm.asset_class_id,
                    ac.asset_class_name,
                    sm.last_price,
                    sm.price_updated_at,
                    sm.data_source,
                    sm.status

                FROM security_master sm

                JOIN asset_class ac
                    ON sm.asset_class_id =
                       ac.asset_class_id

                WHERE
                    sm.security_id = %s
            """, (
                security_id,
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET HISTORICAL PRICE
    #
    # If requested date is weekend / holiday,
    # previous available trading date is returned.
    # =====================================================

    def get_price_for_date(
        self,
        security_id: int,
        requested_date
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    mph.price_id,
                    mph.security_id,
                    mph.trade_date,
                    mph.previous_close,
                    mph.open_price,
                    mph.high_price,
                    mph.low_price,
                    mph.last_price,
                    mph.close_price,
                    mph.average_price,
                    mph.volume,
                    mph.source

                FROM market_price_history mph

                WHERE
                    mph.security_id = %s

                    AND
                    mph.trade_date <= %s

                ORDER BY
                    mph.trade_date DESC

                LIMIT 1
            """, (
                security_id,
                requested_date
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET LATEST PRICE
    # =====================================================

    def get_latest_price(
        self,
        security_id: int
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT
                    mph.security_id,
                    mph.trade_date,
                    mph.close_price,
                    mph.source

                FROM market_price_history mph

                WHERE
                    mph.security_id = %s

                ORDER BY
                    mph.trade_date DESC

                LIMIT 1
            """, (
                security_id,
            ))

            return cursor.fetchone()

        finally:

            cursor.close()
            conn.close()


security_repository = SecurityRepository()