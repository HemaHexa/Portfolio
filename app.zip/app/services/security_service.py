from datetime import date

from app.repositories.security_repository import (
    security_repository
)


class SecurityService:


    # =====================================================
    # SEARCH
    # =====================================================

    def search_securities(
        self,
        asset_class_id: int,
        query: str
    ):

        if asset_class_id <= 0:

            raise ValueError(
                "Valid asset class is required"
            )


        if not query.strip():

            raise ValueError(
                "Search text is required"
            )


        return (
            security_repository
            .search_securities(
                asset_class_id,
                query
            )
        )


    # =====================================================
    # GET SECURITY
    # =====================================================

    def get_security(
        self,
        security_id: int
    ):

        security = (
            security_repository
            .get_security(
                security_id
            )
        )


        if not security:

            raise ValueError(
                "Security not found"
            )


        return security


    # =====================================================
    # HISTORICAL PRICE
    # =====================================================

    def get_price_for_date(
        self,
        security_id: int,
        requested_date: date
    ):

        security = self.get_security(
            security_id
        )


        price = (
            security_repository
            .get_price_for_date(
                security_id,
                requested_date
            )
        )


        if not price:

            raise ValueError(
                "No historical price is available "
                "on or before the selected date"
            )


        return {

            "security_id":
                security["security_id"],

            "symbol":
                security["symbol"],

            "security_name":
                security["security_name"],

            "asset_class_name":
                security["asset_class_name"],

            "requested_date":
                requested_date,

            "actual_price_date":
                price["trade_date"],

            "price":
                price["close_price"],

            "price_type":
                "HISTORICAL_CLOSE",

            "source":
                price["source"]
        }


    # =====================================================
    # LATEST PRICE
    # =====================================================

    def get_latest_price(
        self,
        security_id: int
    ):

        security = self.get_security(
            security_id
        )


        price = (
            security_repository
            .get_latest_price(
                security_id
            )
        )


        if not price:

            raise ValueError(
                "Latest price not available"
            )


        return {

            "security_id":
                security["security_id"],

            "symbol":
                security["symbol"],

            "security_name":
                security["security_name"],

            "asset_class_name":
                security["asset_class_name"],

            "price_date":
                price["trade_date"],

            "price":
                price["close_price"],

            "price_type":
                "LATEST_AVAILABLE_CLOSE",

            "source":
                price["source"]
        }


security_service = SecurityService()