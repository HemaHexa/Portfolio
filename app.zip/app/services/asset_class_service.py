from app.repositories.asset_class_repository import (
    asset_class_repository
)
 
 
class AssetClassService:
 
 
    # =====================================================
    # CREATE
    # =====================================================
 
    def create_asset_class(
        self,
        data
    ):
 
        # Check duplicate name
 
        existing = (
            asset_class_repository
            .get_asset_class_by_name(
                data.asset_class_name
            )
        )
 
 
        if existing is not None:
 
            raise ValueError(
                "Asset class already exists"
            )
 
 
        asset_class_id = (
            asset_class_repository
            .create_asset_class(
                asset_class_name=(
                    data.asset_class_name
                ),
 
                asset_description=(
                    data.asset_description
                ),
 
                sub_asset_class=(
                    data.sub_asset_class
                ),
 
                sub_asset_description=(
                    data.sub_asset_description
                ),
 
                risk_level=(
                    data.risk_level
                ),
 
                investment_horizon=(
                    data.investment_horizon
                )
            )
        )
 
 
        return {
 
            "message":
                "Asset class created successfully",
 
            "asset_class_id":
                asset_class_id
        }
 
 
    # =====================================================
    # GET ALL
    # =====================================================
 
    def get_all_asset_classes(self):
 
        return (
            asset_class_repository
            .get_all_asset_classes()
        )
 
 
    # =====================================================
    # GET ONE
    # =====================================================
 
    def get_asset_class_by_id(
        self,
        asset_class_id
    ):
 
        asset_class = (
            asset_class_repository
            .get_asset_class_by_id(
                asset_class_id
            )
        )
 
 
        if asset_class is None:
 
            raise ValueError(
                "Asset class not found"
            )
 
 
        return asset_class
 
 
    # =====================================================
    # UPDATE
    # =====================================================
 
    def update_asset_class(
        self,
        asset_class_id,
        data
    ):
 
        # Check asset exists
 
        current = (
            asset_class_repository
            .get_asset_class_by_id(
                asset_class_id
            )
        )
 
 
        if current is None:
 
            raise ValueError(
                "Asset class not found"
            )
 
 
        # Status validation
 
        if data.status not in [
            "ACTIVE",
            "INACTIVE"
        ]:
 
            raise ValueError(
                "Status must be ACTIVE or INACTIVE"
            )
 
 
        # Check if another record
        # already has same name
 
        same_name = (
            asset_class_repository
            .get_asset_class_by_name(
                data.asset_class_name
            )
        )
 
 
        if (
            same_name is not None
            and
            same_name["asset_class_id"]
            != asset_class_id
        ):
 
            raise ValueError(
                "Another asset class "
                "already uses this name"
            )
 
 
        asset_class_repository.update_asset_class(
 
            asset_class_id=(
                asset_class_id
            ),
 
            asset_class_name=(
                data.asset_class_name
            ),
 
            asset_description=(
                data.asset_description
            ),
 
            sub_asset_class=(
                data.sub_asset_class
            ),
 
            sub_asset_description=(
                data.sub_asset_description
            ),
 
            risk_level=(
                data.risk_level
            ),
 
            investment_horizon=(
                data.investment_horizon
            ),
 
            status=(
                data.status
            )
        )
 
 
        return {
 
            "message":
                "Asset class updated successfully"
        }
 
 
    # =====================================================
    # DELETE / DEACTIVATE
    # =====================================================
 
    def delete_asset_class(
        self,
        asset_class_id
    ):
 
        asset_class = (
            asset_class_repository
            .get_asset_class_by_id(
                asset_class_id
            )
        )
 
 
        if asset_class is None:
 
            raise ValueError(
                "Asset class not found"
            )
 
 
        if (
            asset_class["status"]
            == "INACTIVE"
        ):
 
            raise ValueError(
                "Asset class is already inactive"
            )
 
 
        asset_class_repository.delete_asset_class(
            asset_class_id
        )
 
 
        return {
 
            "message":
                "Asset class deactivated successfully"
        }
 
 
asset_class_service = (
    AssetClassService()
)