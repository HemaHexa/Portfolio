import math

from datetime import date

from decimal import Decimal

from app.repositories.transaction_repository import (
    transaction_repository
)

from app.services.alert_service import alert_service

class TransactionService:


    # =====================================================
    # BUY
    # =====================================================

    def buy(
        self,
        portfolio_id,
        data
    ):

        # ---------------------------------------------
        # Portfolio
        # ---------------------------------------------

        portfolio = (
            transaction_repository
            .get_portfolio(
                portfolio_id
            )
        )


        if not portfolio:

            raise ValueError(
                "Portfolio not found"
            )


        if (
            portfolio["status"]
            != "Active"
        ):

            raise ValueError(
                "Portfolio must be Active "
                "before buying securities"
            )


        # ---------------------------------------------
        # Transaction Date Validation
        # ---------------------------------------------

        if (
            data.transaction_date
            <
            portfolio[
                "portfolio_start_date"
            ]
        ):

            raise ValueError(
                "Transaction date cannot be "
                "before portfolio start date"
            )


        if (
            data.transaction_date
            >
            date.today()
        ):

            raise ValueError(
                "Transaction date cannot "
                "be in the future"
            )


        # ---------------------------------------------
        # User Input
        # ---------------------------------------------

        if data.value <= 0:

            raise ValueError(
                "Purchase value must "
                "be greater than 0"
            )


        # ---------------------------------------------
        # Security
        # ---------------------------------------------

        security = (
            transaction_repository
            .get_security(
                data.security_id
            )
        )


        if not security:

            raise ValueError(
                "Security not found"
            )


        # Cash itself cannot be bought as security.

        if (
            security[
                "asset_class_name"
            ]
            == "Cash"
        ):

            raise ValueError(
                "Cash is managed through "
                "available balance and "
                "cannot be purchased"
            )


        # ---------------------------------------------
        # Historical BUY Price
        # ---------------------------------------------

        price_row = (
            transaction_repository
            .get_price_for_date(

                data.security_id,

                data.transaction_date

            )
        )


        if not price_row:

            raise ValueError(
                "No historical price is available "
                "for the selected transaction date"
            )


        buy_price = Decimal(
            price_row[
                "close_price"
            ]
        )


        # ---------------------------------------------
        # Current Portfolio Value
        # ---------------------------------------------

        current_portfolio_value = (
            transaction_repository
            .get_portfolio_current_value(
                portfolio_id
            )
        )


        if current_portfolio_value is None:

            raise ValueError(
                "Unable to calculate "
                "portfolio value"
            )


        current_portfolio_value = Decimal(
            current_portfolio_value
        )


        # ---------------------------------------------
        # Amount Portfolio
        # ---------------------------------------------

        if (
            portfolio[
                "portfolio_type"
            ]
            == "Amount"
        ):

            desired_amount = Decimal(
                str(
                    data.value
                )
            )


        # ---------------------------------------------
        # Weightage Portfolio
        # ---------------------------------------------

        elif (
            portfolio[
                "portfolio_type"
            ]
            == "Weightage"
        ):

            percentage = Decimal(
                str(
                    data.value
                )
            )


            if percentage > 100:

                raise ValueError(
                    "Weightage cannot "
                    "be greater than 100%"
                )


            desired_amount = (

                current_portfolio_value
                *
                percentage

                /
                Decimal("100")

            )


        else:

            raise ValueError(
                "Invalid portfolio type"
            )


        # ---------------------------------------------
        # Whole quantity only
        # ---------------------------------------------

        quantity = math.floor(

            desired_amount
            /
            buy_price

        )


        if quantity <= 0:

            raise ValueError(
                "Purchase value is too small "
                "to buy even one unit"
            )


        transaction_amount = (

            Decimal(quantity)

            *
            buy_price

        )


        # ---------------------------------------------
        # Available Balance
        # ---------------------------------------------

        available_balance = Decimal(

            portfolio[
                "available_balance"
            ]

        )


        if (
            transaction_amount
            >
            available_balance
        ):

            raise ValueError(

                "Insufficient available balance. "
                f"Required = {transaction_amount}, "
                f"Available = {available_balance}"

            )


        # =================================================
        # THEME ALLOCATION LIMIT CHECK
        # =================================================

        target_row = (
            transaction_repository
            .get_theme_allocation(

                portfolio[
                    "theme_id"
                ],

                security[
                    "asset_class_id"
                ]

            )
        )


        if not target_row:

            raise ValueError(

                "This asset class is not "
                "allowed in the selected theme"

            )


        target_percentage = Decimal(

            target_row[
                "allocation_percentage"
            ]

        )


        # ---------------------------------------------
        # Current value of selected asset class
        # ---------------------------------------------

        current_asset_value = Decimal(

            transaction_repository
            .get_asset_class_current_value(

                portfolio_id,

                security[
                    "asset_class_id"
                ]

            )

        )


        # ---------------------------------------------
        # Latest price of newly purchased security
        #
        # Current allocation must use latest price,
        # not historical BUY price.
        # ---------------------------------------------

        latest_price_row = (
            transaction_repository
            .get_latest_price(
                data.security_id
            )
        )


        if not latest_price_row:

            raise ValueError(
                "Latest price not available"
            )


        latest_price = Decimal(

            latest_price_row[
                "close_price"
            ]

        )


        # ---------------------------------------------
        # Current value added by new holding
        # ---------------------------------------------

        proposed_current_value = (

            Decimal(quantity)

            *
            latest_price

        )


        # ---------------------------------------------
        # Projected total portfolio value
        #
        # Cash decreases by historical transaction
        # amount.
        #
        # Holding current value increases using
        # latest price.
        # ---------------------------------------------

        projected_portfolio_value = (

            current_portfolio_value

            -
            transaction_amount

            +
            proposed_current_value

        )


        projected_asset_value = (

            current_asset_value

            +
            proposed_current_value

        )


        if projected_portfolio_value <= 0:

            raise ValueError(
                "Invalid projected portfolio value"
            )


        projected_percentage = (

            projected_asset_value

            /
            projected_portfolio_value

            *
            Decimal("100")

        )


        # ---------------------------------------------
        # Theme percentage acts as BUY CAP
        # ---------------------------------------------

        if (
            projected_percentage
            >
            target_percentage
        ):

            raise ValueError(

                f"Purchase rejected. "
                f"{security['asset_class_name']} "
                f"theme limit = "
                f"{target_percentage:.2f}%. "
                f"Projected allocation = "
                f"{projected_percentage:.2f}%."

            )


        # =================================================
        # EXECUTE BUY
        # =================================================

        result = (
            transaction_repository
            .execute_buy(

                portfolio_id=
                    portfolio_id,

                security_id=
                    data.security_id,

                quantity=
                    quantity,

                buy_price=
                    buy_price,

                transaction_amount=
                    transaction_amount,

                transaction_date=
                    data.transaction_date

            )
        )

        alert_result = (
            alert_service.recalculate_alerts(portfolio_id)
        )


        return {

            "message":
                "Security purchased successfully",

            "symbol":
                security["symbol"],

            "security_name":
                security[
                    "security_name"
                ],

            "asset_class":
                security[
                    "asset_class_name"
                ],

            "requested_transaction_date":
                data.transaction_date,

            "actual_price_date":
                price_row[
                    "trade_date"
                ],

            "buy_price":
                buy_price,

            "latest_price":
                latest_price,

            "quantity":
                quantity,

            "transaction_amount":
                transaction_amount,

            "theme_limit_percentage":
                target_percentage,

            "projected_allocation_percentage":
                round(
                    projected_percentage,
                    2
                ),

            "available_balance":
                result[
                    "available_balance"
                ],

            "holding":
                result["holding"],

            "transaction":
                result["transaction"],

            "automatic_alerts": alert_result
        }

        # =====================================================
    # SELL
    # =====================================================

    def sell(
        self,
        portfolio_id,
        data
    ):

        # ---------------------------------------------
        # Portfolio
        # ---------------------------------------------

        portfolio = (
            transaction_repository
            .get_portfolio(
                portfolio_id
            )
        )


        if not portfolio:

            raise ValueError(
                "Portfolio not found"
            )


        if (
            portfolio["status"]
            != "Active"
        ):

            raise ValueError(
                "Portfolio must be Active "
                "before selling securities"
            )


        # ---------------------------------------------
        # Date Validation
        # ---------------------------------------------

        if (
            data.transaction_date
            <
            portfolio[
                "portfolio_start_date"
            ]
        ):

            raise ValueError(
                "Transaction date cannot be "
                "before portfolio start date"
            )


        if (
            data.transaction_date
            >
            date.today()
        ):

            raise ValueError(
                "Transaction date cannot "
                "be in the future"
            )


        # ---------------------------------------------
        # Quantity
        # ---------------------------------------------

        if data.quantity <= 0:

            raise ValueError(
                "Sell quantity must be "
                "greater than 0"
            )


        # ---------------------------------------------
        # Security
        # ---------------------------------------------

        security = (
            transaction_repository
            .get_security(
                data.security_id
            )
        )


        if not security:

            raise ValueError(
                "Security not found"
            )


        # ---------------------------------------------
        # Holding
        # ---------------------------------------------

        holding = (
            transaction_repository
            .get_holding(

                portfolio_id,

                data.security_id

            )
        )


        if not holding:

            raise ValueError(
                "You do not own this security "
                "in this portfolio"
            )


        if (
            data.quantity
            >
            holding["quantity"]
        ):

            raise ValueError(

                f"Cannot sell {data.quantity} units. "
                f"Available quantity = "
                f"{holding['quantity']}."

            )


        # ---------------------------------------------
        # SELL Price
        #
        # Uses selected transaction date.
        # Weekend/holiday automatically uses
        # previous available trading day.
        # ---------------------------------------------

        price_row = (
            transaction_repository
            .get_price_for_date(

                data.security_id,

                data.transaction_date

            )
        )


        if not price_row:

            raise ValueError(
                "Price not available for "
                "the selected sell date"
            )


        sell_price = Decimal(

            price_row[
                "close_price"
            ]

        )


        transaction_amount = (

            Decimal(
                data.quantity
            )

            *
            sell_price

        )


        # ---------------------------------------------
        # Profit / Loss on this SELL
        # ---------------------------------------------

        average_buy_price = Decimal(

            holding[
                "average_buy_price"
            ]

        )


        realised_profit_loss = (

            (
                sell_price
                -
                average_buy_price
            )

            *
            Decimal(
                data.quantity
            )

        )


        # ---------------------------------------------
        # Execute
        # ---------------------------------------------

        result = (
            transaction_repository
            .execute_sell(

                portfolio_id=
                    portfolio_id,

                security_id=
                    data.security_id,

                quantity=
                    data.quantity,

                sell_price=
                    sell_price,

                transaction_amount=
                    transaction_amount,

                transaction_date=
                    data.transaction_date

            )
        )

        alert_result = (alert_service.recalculate_alerts(portfolio_id))


        return {

            "message":
                "Security sold successfully",

            "symbol":
                security["symbol"],

            "security_name":
                security[
                    "security_name"
                ],

            "asset_class":
                security[
                    "asset_class_name"
                ],

            "requested_transaction_date":
                data.transaction_date,

            "actual_price_date":
                price_row[
                    "trade_date"
                ],

            "quantity_sold":
                data.quantity,

            "average_buy_price":
                average_buy_price,

            "sell_price":
                sell_price,

            "transaction_amount":
                transaction_amount,

            "realised_profit_loss":
                realised_profit_loss,

            "remaining_quantity":
                result[
                    "remaining_quantity"
                ],

            "available_balance":
                result[
                    "available_balance"
                ],

            "transaction":
                result[
                    "transaction"
                ],
                
            "automatic_alerts": alert_result
        }


    # =====================================================
    # HOLDINGS
    # =====================================================

    def get_holdings(
        self,
        portfolio_id
    ):

        portfolio = (
            transaction_repository
            .get_portfolio(
                portfolio_id
            )
        )


        if not portfolio:

            raise ValueError(
                "Portfolio not found"
            )


        return (
            transaction_repository
            .get_holdings(
                portfolio_id
            )
        )


    # =====================================================
    # TRANSACTIONS
    # =====================================================

    def get_transactions(
        self,
        portfolio_id
    ):

        portfolio = (
            transaction_repository
            .get_portfolio(
                portfolio_id
            )
        )


        if not portfolio:

            raise ValueError(
                "Portfolio not found"
            )


        return (
            transaction_repository
            .get_transactions(
                portfolio_id
            )
        )


transaction_service = (
    TransactionService()
)
