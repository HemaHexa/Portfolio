import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path

from app.database.connection import get_db_connection


# =========================================================
# PATHS
# =========================================================

BACKEND_DIR = Path(__file__).resolve().parents[2]

DATA_DIR = BACKEND_DIR / "data"

REAL_EQUITY_DIR = (
    DATA_DIR / "real" / "equity"
)

REAL_BENCHMARK_DIR = (
    DATA_DIR / "real" / "benchmark"
)

MOCK_DIR = (
    DATA_DIR / "mock"
)

MOCK_MASTER_FILE = (
    MOCK_DIR /
    "mock_security_master.csv"
)


MOCK_HISTORY_FILES = [

    MOCK_DIR /
    "equity_etf" /
    "equity_etf_all_4_months.csv",

    MOCK_DIR /
    "debt_etf" /
    "debt_etf_all_4_months.csv",

    MOCK_DIR /
    "gold_etf" /
    "gold_etf_all_4_months.csv",
]


# =========================================================
# REAL EQUITY DISPLAY NAMES
# =========================================================

REAL_SECURITY_NAMES = {

    "TCS":
        "Tata Consultancy Services Limited",

    "INFY":
        "Infosys Limited",

    "HCLTECH":
        "HCL Technologies Limited",

    "HEXT":
        "Hexaware Technologies Limited",

    "KOTAKBANK":
        "Kotak Mahindra Bank Limited",

    "DMART":
        "Avenue Supermarts Limited",

    "HINDPETRO":
        "Hindustan Petroleum Corporation Limited",

    "SBIN":
        "State Bank of India",

    "RELIANCE":
        "Reliance Industries Limited",
}


# =========================================================
# HELPER FUNCTIONS
# =========================================================

def clean_text(value):

    if value is None:
        return None

    value = str(
        value
    ).strip()

    if value == "":
        return None

    return value


def clean_number(value):

    value = clean_text(
        value
    )

    if value is None:
        return None


    value = (
        value
        .replace(",", "")
        .replace("₹", "")
        .replace("%", "")
        .strip()
    )


    if value.upper() in {

        "",
        "-",
        "--",
        "NA",
        "N/A"

    }:

        return None


    try:

        return Decimal(
            value
        )


    except InvalidOperation:

        raise ValueError(

            f"Invalid numeric value: "
            f"{value}"

        )


def clean_integer(value):

    number = clean_number(
        value
    )


    if number is None:

        return None


    return int(
        number
    )


def parse_date(value):

    value = clean_text(
        value
    )


    if value is None:

        raise ValueError(
            "Date is missing"
        )


    date_formats = [

        "%d-%b-%Y",

        "%d %b %Y",

        "%Y-%m-%d",

        "%d-%m-%Y",

        "%d/%m/%Y"
    ]


    for date_format in date_formats:

        try:

            return datetime.strptime(

                value,

                date_format

            ).date()


        except ValueError:

            pass


    raise ValueError(

        f"Unsupported date format: "
        f"{value}"

    )


def read_csv_rows(
    file_path
):

    with open(

        file_path,

        "r",

        encoding="utf-8-sig",

        newline=""

    ) as file:


        reader = (
            csv.DictReader(
                file
            )
        )


        rows = []


        for row in reader:

            cleaned_row = {}


            for key, value in row.items():

                if key is None:

                    continue


                clean_key = (
                    key.strip()
                )


                if isinstance(
                    value,
                    str
                ):

                    value = (
                        value.strip()
                    )


                cleaned_row[
                    clean_key
                ] = value


            rows.append(
                cleaned_row
            )


        return rows


# =========================================================
# GET ASSET CLASS IDS
# =========================================================

def get_asset_class_ids(
    cursor
):

    cursor.execute("""
        SELECT
            asset_class_id,
            asset_class_name

        FROM asset_class

        WHERE status = 'ACTIVE'
    """)


    rows = (
        cursor.fetchall()
    )


    return {

        row["asset_class_name"]:
            row["asset_class_id"]

        for row in rows
    }


# =========================================================
# INSERT / UPDATE SECURITY
# =========================================================

def upsert_security(

    cursor,

    symbol,

    security_name,

    instrument_type,

    asset_class_id,

    source,

    isin=None

):


    symbol = (
        symbol
        .strip()
        .upper()
    )


    # -----------------------------------------
    # Internal project key.
    # No API required.
    # -----------------------------------------

    instrument_key = (
        f"NSE|{symbol}"
    )


    cursor.execute("""
        INSERT INTO security_master (

            instrument_key,

            exchange,

            symbol,

            security_name,

            isin,

            instrument_type,

            asset_class_id,

            status,

            data_source

        )

        VALUES (

            %s,

            'NSE',

            %s,

            %s,

            %s,

            %s,

            %s,

            'ACTIVE',

            %s

        )


        ON CONFLICT (
            instrument_key
        )

        DO UPDATE SET

            symbol =
                EXCLUDED.symbol,

            security_name =
                EXCLUDED.security_name,

            isin =
                COALESCE(

                    EXCLUDED.isin,

                    security_master.isin

                ),

            instrument_type =
                EXCLUDED.instrument_type,

            asset_class_id =
                EXCLUDED.asset_class_id,

            status =
                'ACTIVE',

            data_source =
                EXCLUDED.data_source,

            updated_at =
                CURRENT_TIMESTAMP


        RETURNING security_id

    """, (

        instrument_key,

        symbol,

        security_name,

        isin,

        instrument_type,

        asset_class_id,

        source

    ))


    row = (
        cursor.fetchone()
    )


    return (
        row["security_id"]
    )


# =========================================================
# GET SECURITY ID
# =========================================================

def get_security_id(

    cursor,

    symbol

):


    instrument_key = (

        f"NSE|"
        f"{symbol.strip().upper()}"

    )


    cursor.execute("""
        SELECT
            security_id

        FROM security_master

        WHERE
            instrument_key = %s
    """, (

        instrument_key,

    ))


    row = (
        cursor.fetchone()
    )


    if not row:

        raise ValueError(

            f"Security not found: "
            f"{symbol}"

        )


    return (
        row["security_id"]
    )


# =========================================================
# INSERT MARKET HISTORY
# =========================================================

def insert_market_history(

    cursor,

    security_id,

    rows,

    source

):


    values = []


    for row in rows:


        series = clean_text(

            row.get(
                "Series"
            )

        )


        # -----------------------------------------
        # For real NSE Equity,
        # use only EQ series
        # -----------------------------------------

        if (

            source == "REAL_CSV"

            and

            series is not None

            and

            series.upper() != "EQ"

        ):

            continue


        close_price = clean_number(

            row.get(
                "Close Price"
            )

        )


        if close_price is None:

            continue


        values.append((

            security_id,

            parse_date(
                row.get(
                    "Date"
                )
            ),

            clean_number(
                row.get(
                    "Prev Close"
                )
            ),

            clean_number(
                row.get(
                    "Open Price"
                )
            ),

            clean_number(
                row.get(
                    "High Price"
                )
            ),

            clean_number(
                row.get(
                    "Low Price"
                )
            ),

            clean_number(
                row.get(
                    "Last Price"
                )
            ),

            close_price,

            clean_number(
                row.get(
                    "Average Price"
                )
            ),

            clean_integer(
                row.get(
                    "Total Traded Quantity"
                )
            ),

            source

        ))


    if not values:

        return 0


    cursor.executemany("""
        INSERT INTO market_price_history (

            security_id,

            trade_date,

            previous_close,

            open_price,

            high_price,

            low_price,

            last_price,

            close_price,

            average_price,

            volume,

            source

        )

        VALUES (

            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s

        )


        ON CONFLICT (

            security_id,

            trade_date

        )

        DO UPDATE SET

            previous_close =
                EXCLUDED.previous_close,

            open_price =
                EXCLUDED.open_price,

            high_price =
                EXCLUDED.high_price,

            low_price =
                EXCLUDED.low_price,

            last_price =
                EXCLUDED.last_price,

            close_price =
                EXCLUDED.close_price,

            average_price =
                EXCLUDED.average_price,

            volume =
                EXCLUDED.volume,

            source =
                EXCLUDED.source

    """, values)


    return len(
        values
    )


# =========================================================
# IMPORT REAL EQUITY
# =========================================================

def import_real_equities(

    cursor,

    asset_class_ids

):


    equity_id = (

        asset_class_ids.get(
            "Equity"
        )

    )


    if not equity_id:

        raise ValueError(

            "Equity asset class "
            "not found"

        )


    if not REAL_EQUITY_DIR.exists():

        raise FileNotFoundError(

            f"Folder not found: "
            f"{REAL_EQUITY_DIR}"

        )


    csv_files = sorted(

        REAL_EQUITY_DIR.glob(
            "*.csv"
        )

    )


    if not csv_files:

        raise FileNotFoundError(

            "No real Equity CSV "
            f"files found in "
            f"{REAL_EQUITY_DIR}"

        )


    security_count = 0

    price_count = 0


    print(
        "\nImporting REAL Equity data..."
    )


    for file_path in csv_files:


        rows = read_csv_rows(
            file_path
        )


        if not rows:

            print(

                "Skipped empty file:",

                file_path.name

            )

            continue


        symbol = clean_text(

            rows[0].get(
                "Symbol"
            )

        )


        if not symbol:

            raise ValueError(

                f"Symbol column missing "
                f"in {file_path.name}"

            )


        symbol = (
            symbol.upper()
        )


        security_name = (

            REAL_SECURITY_NAMES.get(

                symbol,

                symbol

            )

        )


        security_id = upsert_security(

            cursor=cursor,

            symbol=symbol,

            security_name=
                security_name,

            instrument_type="EQ",

            asset_class_id=
                equity_id,

            source="REAL_CSV"

        )


        inserted = insert_market_history(

            cursor=cursor,

            security_id=
                security_id,

            rows=rows,

            source="REAL_CSV"

        )


        security_count += 1

        price_count += (
            inserted
        )


        print(

            f"  {symbol}: "
            f"{inserted} rows"

        )


    return (

        security_count,

        price_count

    )


# =========================================================
# IMPORT MOCK SECURITY MASTER
# =========================================================

def import_mock_security_master(

    cursor,

    asset_class_ids

):


    if not MOCK_MASTER_FILE.exists():

        raise FileNotFoundError(

            f"Mock master not found: "
            f"{MOCK_MASTER_FILE}"

        )


    rows = read_csv_rows(

        MOCK_MASTER_FILE

    )


    count = 0


    print(
        "\nImporting MOCK securities..."
    )


    for row in rows:


        symbol = clean_text(

            row.get(
                "symbol"
            )

        )


        security_name = clean_text(

            row.get(
                "security_name"
            )

        )


        asset_class_name = clean_text(

            row.get(
                "asset_class_name"
            )

        )


        isin = clean_text(

            row.get(
                "isin"
            )

        )


        instrument_type = (

            clean_text(

                row.get(
                    "instrument_type"
                )

            )

            or

            "ETF"

        )


        if (

            not symbol

            or

            not security_name

            or

            not asset_class_name

        ):

            raise ValueError(

                "Invalid row in "
                "mock_security_master.csv"

            )


        asset_class_id = (

            asset_class_ids.get(

                asset_class_name

            )

        )


        if not asset_class_id:

            raise ValueError(

                f"Asset class "
                f"not found: "
                f"{asset_class_name}"

            )


        upsert_security(

            cursor=cursor,

            symbol=symbol,

            security_name=
                security_name,

            instrument_type=
                instrument_type,

            asset_class_id=
                asset_class_id,

            source="MOCK",

            isin=isin

        )


        count += 1


        print(

            f"  {symbol} -> "
            f"{asset_class_name}"

        )


    return count


# =========================================================
# IMPORT MOCK ETF HISTORY
# =========================================================

def import_mock_history(
    cursor
):


    total = 0


    print(
        "\nImporting MOCK ETF history..."
    )


    for file_path in MOCK_HISTORY_FILES:


        if not file_path.exists():

            raise FileNotFoundError(

                f"Mock file not found: "
                f"{file_path}"

            )


        rows = read_csv_rows(

            file_path

        )


        symbols = sorted({

            clean_text(
                row.get(
                    "Symbol"
                )
            )

            for row in rows

            if clean_text(
                row.get(
                    "Symbol"
                )
            )

        })


        file_total = 0


        for symbol in symbols:


            symbol_rows = [

                row

                for row in rows

                if clean_text(

                    row.get(
                        "Symbol"
                    )

                ) == symbol

            ]


            security_id = (
                get_security_id(

                    cursor,

                    symbol

                )
            )


            inserted = (
                insert_market_history(

                    cursor=cursor,

                    security_id=
                        security_id,

                    rows=
                        symbol_rows,

                    source=
                        "MOCK"

                )
            )


            file_total += (
                inserted
            )


        total += (
            file_total
        )


        print(

            f"  {file_path.name}: "
            f"{file_total} rows"

        )


    return total


# =========================================================
# IMPORT REAL NIFTY 50
# =========================================================

def import_real_nifty50(
    cursor
):


    if not REAL_BENCHMARK_DIR.exists():

        raise FileNotFoundError(

            f"Benchmark folder "
            f"not found: "
            f"{REAL_BENCHMARK_DIR}"

        )


    csv_files = sorted(

        REAL_BENCHMARK_DIR.glob(
            "*.csv"
        )

    )


    if not csv_files:

        raise FileNotFoundError(

            "No benchmark CSV "
            f"found in "
            f"{REAL_BENCHMARK_DIR}"

        )


    # -----------------------------------------
    # We use one real NIFTY 50 CSV
    # -----------------------------------------

    file_path = (
        csv_files[0]
    )


    rows = read_csv_rows(

        file_path

    )


    values = []


    for row in rows:


        close_value = clean_number(

            row.get(
                "Close"
            )

        )


        if close_value is None:

            continue


        values.append((

            "NIFTY50",

            clean_text(

                row.get(
                    "Index Name"
                )

            )

            or

            "NIFTY 50",

            parse_date(

                row.get(
                    "Date"
                )

            ),

            close_value,

            "REAL_CSV"

        ))


    cursor.executemany("""
        INSERT INTO benchmark_price_history (

            benchmark_code,

            benchmark_name,

            price_date,

            close_value,

            source

        )

        VALUES (

            %s,
            %s,
            %s,
            %s,
            %s

        )


        ON CONFLICT (

            benchmark_code,

            price_date

        )

        DO UPDATE SET

            benchmark_name =
                EXCLUDED.benchmark_name,

            close_value =
                EXCLUDED.close_value,

            source =
                EXCLUDED.source

    """, values)


    print(

        f"\nNIFTY 50: "
        f"{len(values)} rows"

    )


    return len(
        values
    )


# =========================================================
# UPDATE LATEST SECURITY PRICE
# =========================================================

def update_latest_security_prices(
    cursor
):


    cursor.execute("""
        UPDATE security_master AS sm

        SET

            last_price =
                latest.close_price,

            price_updated_at =
                latest.trade_date::timestamp,

            updated_at =
                CURRENT_TIMESTAMP

        FROM (

            SELECT DISTINCT ON (
                security_id
            )

                security_id,

                trade_date,

                close_price

            FROM
                market_price_history

            ORDER BY

                security_id,

                trade_date DESC

        ) AS latest

        WHERE

            sm.security_id =
                latest.security_id
    """)


    return (
        cursor.rowcount
    )


# =========================================================
# IMPORT EVERYTHING
# =========================================================

def import_all_data():


    print(
        "Starting CSV market data import..."
    )


    print(
        "Data folder:",
        DATA_DIR
    )


    conn = (
        get_db_connection()
    )


    cursor = (
        conn.cursor()
    )


    try:


        asset_class_ids = (

            get_asset_class_ids(
                cursor
            )

        )


        # -----------------------------------------
        # Real Equity
        # -----------------------------------------

        (

            real_security_count,

            real_price_count

        ) = import_real_equities(

            cursor,

            asset_class_ids

        )


        # -----------------------------------------
        # Mock Security Master
        # -----------------------------------------

        mock_security_count = (

            import_mock_security_master(

                cursor,

                asset_class_ids

            )

        )


        # -----------------------------------------
        # Mock ETF History
        # -----------------------------------------

        mock_price_count = (

            import_mock_history(
                cursor
            )

        )


        # -----------------------------------------
        # Real NIFTY 50
        # -----------------------------------------

        benchmark_count = (

            import_real_nifty50(
                cursor
            )

        )


        # -----------------------------------------
        # Latest Price
        # -----------------------------------------

        latest_count = (

            update_latest_security_prices(

                cursor

            )

        )


        conn.commit()


        print(
            "\n================================"
        )

        print(
            "CSV IMPORT COMPLETED SUCCESSFULLY"
        )

        print(
            "================================"
        )


        print(

            "Real Equity Securities:",

            real_security_count

        )


        print(

            "Real Equity Price Rows:",

            real_price_count

        )


        print(

            "Mock ETF Securities:",

            mock_security_count

        )


        print(

            "Mock ETF Price Rows:",

            mock_price_count

        )


        print(

            "NIFTY 50 Rows:",

            benchmark_count

        )


        print(

            "Latest Prices Updated:",

            latest_count

        )


    except Exception as error:


        conn.rollback()


        print(
            "\nCSV IMPORT FAILED"
        )


        print(
            error
        )


        raise


    finally:


        cursor.close()

        conn.close()


# =========================================================
# RUN DIRECTLY
# =========================================================

if __name__ == "__main__":

    import_all_data()