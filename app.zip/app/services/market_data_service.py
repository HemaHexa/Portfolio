import os

import requests

from app.config import (
    EODHD_API_TOKEN,
    EODHD_BASE_URL,
    NSE_EXCHANGE_CODE,
)


# The trust bundle we built earlier with get_cerf.py
CERT_BUNDLE = r"C:\Users\2000209446\OneDrive - Hexaware Technologies\Desktop\Final_portfolio\backend\certs.pem"
CERT_DIR    = r"C:\Users\2000209446\OneDrive - Hexaware Technologies\Desktop\Final_portfolio\backend"


# --- Belt and susspenders: set every env var name the shim might read ---
# so the low-level wrap can find the CA even if the kwarg route is ignored
os.environ["SSL_CA_CERTS"]       = CERT_BUNDLE
os.environ["SSL_CA_CERTS_DIR"]   = CERT_DIR
os.environ["SSL_CERT_VERIFY"]    = CERT_BUNDLE
os.environ["SSL_CERT_VERIFY_1"]  = CERT_BUNDLE


class MarketDataService:

    def check_token(self):
        if not EODHD_API_TOKEN:
            raise ValueError("EODHD_API_TOKEN is missing in .env")

    # =====================================================
    # DOWNLOAD NSE SECURITY MASTER
    # =====================================================
    def download_nse_security_master(self):
        self.check_token()

        url = (
            f"{EODHD_BASE_URL}"
            f"/exchange-symbol-list/"
            f"{NSE_EXCHANGE_CODE}"
        )

        params = {
            "api_token": EODHD_API_TOKEN,
            "fmt": "csv",
        }

        response = requests.get(
            url,
            params=params,
            timeout=60,
            verify=CERT_BUNDLE,
            ca_certs=CERT_BUNDLE,          # <-- try; remove if TypeError
            ca_cert_dir=CERT_DIR,          # <-- try; remove if TypeError
        )

        if response.status_code != 200:
            raise ValueError(
                "Unable to download NSE securities: " + response.text
            )

        folder = "data/raw/securities"
        os.makedirs(folder, exist_ok=True)

        file_path = f"{folder}/nse_securities_raw.csv"
        with open(file_path, "wb") as file:
            file.write(response.content)

        return {
            "message": "NSE security master downloaded successfully",
            "file_path": file_path,
        }


market_data_service = MarketDataService()