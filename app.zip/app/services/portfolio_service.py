from datetime import date

from app.repositories.portfolio_repository import (
    portfolio_repository
)


class PortfolioService:


    # =====================================================
    # CREATE PORTFOLIO
    # =====================================================

    def create_portfolio(
        self,
        data
    ):

        # -----------------------------------------
        # Portfolio Name
        # -----------------------------------------

        if not data.portfolio_name.strip():

            raise ValueError(
                "Portfolio name is required"
            )


        # -----------------------------------------
        # Manager
        # -----------------------------------------

        if not data.portfolio_manager.strip():

            raise ValueError(
                "Portfolio manager is required"
            )


        # -----------------------------------------
        # Portfolio Type
        # -----------------------------------------

        if data.portfolio_type not in [
            "Amount",
            "Weightage"
        ]:

            raise ValueError(
                "Portfolio type must be "
                "Amount or Weightage"
            )


        # -----------------------------------------
        # Investment
        # -----------------------------------------

        if data.initial_investment <= 0:

            raise ValueError(
                "Initial investment must "
                "be greater than 0"
            )


        # -----------------------------------------
        # Start Date
        # -----------------------------------------

        if (
            data.portfolio_start_date
            >
            date.today()
        ):

            raise ValueError(
                "Portfolio start date "
                "cannot be in the future"
            )


        # -----------------------------------------
        # Rebalancing Frequency
        # -----------------------------------------

        valid_frequencies = [

            "Daily",
            "Weekly",
            "Monthly",
            "Quarterly",
            "Half-Yearly",
            "Yearly"
        ]


        if (
            data.rebalancing_frequency
            not in valid_frequencies
        ):

            raise ValueError(
                "Invalid rebalancing frequency"
            )


        # -----------------------------------------
        # Theme Exists?
        # -----------------------------------------

        theme = (
            portfolio_repository
            .get_theme(
                data.theme_id
            )
        )


        if not theme:

            raise ValueError(
                "Active investment theme "
                "not found"
            )


        # -----------------------------------------
        # Create
        # -----------------------------------------

        return (
            portfolio_repository
            .create_portfolio(
                data
            )
        )


    # =====================================================
    # GET ALL
    # =====================================================

    def get_all_portfolios(self):

        return (
            portfolio_repository
            .get_all_portfolios()
        )


    # =====================================================
    # GET ONE
    # =====================================================

    def get_portfolio(
        self,
        portfolio_id
    ):

        portfolio = (
            portfolio_repository
            .get_portfolio(
                portfolio_id
            )
        )


        if not portfolio:

            raise ValueError(
                "Portfolio not found"
            )


        return portfolio


    # =====================================================
    # ACTIVATE
    # =====================================================

    def activate_portfolio(
        self,
        portfolio_id
    ):

        portfolio = (
            self.get_portfolio(
                portfolio_id
            )
        )


        if (
            portfolio["status"]
            == "Closed"
        ):

            raise ValueError(
                "Closed portfolio "
                "cannot be activated"
            )


        if (
            portfolio["status"]
            == "Active"
        ):

            raise ValueError(
                "Portfolio is already active"
            )


        # -----------------------------------------
        # Find NIFTY price corresponding
        # to Portfolio Start Date
        # -----------------------------------------

        benchmark = (
            portfolio_repository
            .get_benchmark_price(

                portfolio[
                    "portfolio_start_date"
                ]

            )
        )


        if not benchmark:

            raise ValueError(

                "NIFTY 50 benchmark price "
                "is not available on or before "
                "the portfolio start date"

            )


        # -----------------------------------------
        # Activate
        # -----------------------------------------

        activated = (
            portfolio_repository
            .activate_portfolio(

                portfolio_id,

                benchmark[
                    "close_value"
                ]

            )
        )


        return {

            "message":
                "Portfolio activated successfully",

            "portfolio":
                activated,

            "benchmark": {

                "benchmark_name":
                    benchmark[
                        "benchmark_name"
                    ],

                "requested_start_date":
                    portfolio[
                        "portfolio_start_date"
                    ],

                "actual_benchmark_date":
                    benchmark[
                        "price_date"
                    ],

                "benchmark_start_value":
                    benchmark[
                        "close_value"
                    ]
            }
        }


portfolio_service = (
    PortfolioService()
)
