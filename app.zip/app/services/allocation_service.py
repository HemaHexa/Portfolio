from decimal import Decimal

from app.database.connection import get_db_connection


class AllocationService:


    # =====================================================
    # CURRENT PORTFOLIO ALLOCATION
    # =====================================================

    def get_allocation(
        self,
        portfolio_id: int
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            # -----------------------------------------
            # Portfolio
            # -----------------------------------------

            cursor.execute("""
                SELECT
                    p.portfolio_id,
                    p.theme_id,
                    p.available_balance,
                    p.status

                FROM portfolio p

                WHERE
                    p.portfolio_id = %s
            """, (
                portfolio_id,
            ))

            portfolio = cursor.fetchone()


            if not portfolio:

                raise ValueError(
                    "Portfolio not found"
                )


            # -----------------------------------------
            # All Theme Asset Classes
            # -----------------------------------------

            cursor.execute("""
                SELECT
                    ac.asset_class_id,
                    ac.asset_class_name,
                    ta.allocation_percentage

                FROM theme_allocation ta

                JOIN asset_class ac
                    ON ta.asset_class_id =
                       ac.asset_class_id

                WHERE
                    ta.theme_id = %s

                ORDER BY
                    ac.asset_class_id
            """, (
                portfolio["theme_id"],
            ))

            targets = cursor.fetchall()


            # -----------------------------------------
            # Holding values grouped by asset class
            # -----------------------------------------

            cursor.execute("""
                SELECT
                    sm.asset_class_id,

                    COALESCE(
                        SUM(
                            ph.quantity
                            *
                            latest.close_price
                        ),
                        0
                    ) AS current_value

                FROM portfolio_holding ph

                JOIN security_master sm
                    ON ph.security_id =
                       sm.security_id

                LEFT JOIN LATERAL (

                    SELECT
                        mph.close_price

                    FROM market_price_history mph

                    WHERE
                        mph.security_id =
                            ph.security_id

                    ORDER BY
                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE

                WHERE
                    ph.portfolio_id = %s

                GROUP BY
                    sm.asset_class_id
            """, (
                portfolio_id,
            ))

            value_rows = cursor.fetchall()


            value_map = {

                row["asset_class_id"]:
                    Decimal(
                        row["current_value"]
                    )

                for row in value_rows
            }


            # -----------------------------------------
            # Cash
            # -----------------------------------------

            available_balance = Decimal(

                portfolio[
                    "available_balance"
                ]

            )


            # -----------------------------------------
            # Calculate Total Portfolio Value
            # -----------------------------------------

            holdings_total = sum(
                value_map.values(),
                Decimal("0")
            )


            total_portfolio_value = (

                holdings_total
                +
                available_balance

            )


            if total_portfolio_value <= 0:

                raise ValueError(
                    "Portfolio value must be "
                    "greater than zero"
                )


            result = []


            # -----------------------------------------
            # Calculate each asset allocation
            # -----------------------------------------

            for target in targets:


                asset_class_id = (
                    target[
                        "asset_class_id"
                    ]
                )


                asset_class_name = (
                    target[
                        "asset_class_name"
                    ]
                )


                target_percentage = Decimal(

                    target[
                        "allocation_percentage"
                    ]

                )


                # -------------------------------------
                # Cash value
                # -------------------------------------

                if asset_class_name == "Cash":

                    current_value = (
                        available_balance
                    )


                # -------------------------------------
                # Security-based asset class
                # -------------------------------------

                else:

                    current_value = (

                        value_map.get(

                            asset_class_id,

                            Decimal("0")

                        )

                    )


                current_percentage = (

                    current_value

                    /
                    total_portfolio_value

                    *
                    Decimal("100")

                )


                deviation = (

                    current_percentage

                    -
                    target_percentage

                )


                result.append({

                    "asset_class_id":
                        asset_class_id,

                    "asset_class_name":
                        asset_class_name,

                    "target_percentage":
                        round(
                            target_percentage,
                            2
                        ),

                    "current_percentage":
                        round(
                            current_percentage,
                            2
                        ),

                    "deviation_percentage":
                        round(
                            deviation,
                            2
                        ),

                    "current_value":
                        round(
                            current_value,
                            2
                        )
                })


            return {

                "portfolio_id":
                    portfolio_id,

                "total_portfolio_value":
                    round(
                        total_portfolio_value,
                        2
                    ),

                "available_balance":
                    round(
                        available_balance,
                        2
                    ),

                "allocations":
                    result
            }


        finally:

            cursor.close()
            conn.close()


allocation_service = AllocationService()