import math

from decimal import Decimal

from app.database.connection import (
    get_db_connection
)

from app.services.allocation_service import (
    allocation_service
)


class RebalancingService:


    # =====================================================
    # GET REBALANCING RECOMMENDATIONS
    # =====================================================

    def get_rebalancing(
        self,
        portfolio_id
    ):

        data = (
            allocation_service
            .get_allocation(
                portfolio_id
            )
        )


        total_value = Decimal(

            data[
                "total_portfolio_value"
            ]

        )


        recommendations = []


        for item in data[
            "allocations"
        ]:


            target = Decimal(

                item[
                    "target_percentage"
                ]

            )


            current = Decimal(

                item[
                    "current_percentage"
                ]

            )


            current_value = Decimal(

                item[
                    "current_value"
                ]

            )


            deviation = (

                current
                -
                target

            )


            target_value = (

                total_value

                *
                target

                /
                Decimal("100")

            )


            adjustment = (

                target_value
                -
                current_value

            )


            # ---------------------------------------------
            # Underallocated
            # ---------------------------------------------

            if deviation < Decimal("-5"):

                action = "INCREASE"

                amount = abs(
                    adjustment
                )


            # ---------------------------------------------
            # Overallocated
            # ---------------------------------------------

            elif deviation > Decimal("5"):

                action = "REDUCE"

                amount = abs(
                    adjustment
                )


            # ---------------------------------------------
            # Within tolerance
            # ---------------------------------------------

            else:

                action = "HOLD"

                amount = Decimal("0")


            recommendations.append({

                "asset_class_id":
                    item[
                        "asset_class_id"
                    ],

                "asset_class_name":
                    item[
                        "asset_class_name"
                    ],

                "target_percentage":
                    round(
                        target,
                        2
                    ),

                "current_percentage":
                    round(
                        current,
                        2
                    ),

                "deviation_percentage":
                    round(
                        deviation,
                        2
                    ),

                "target_value":
                    round(
                        target_value,
                        2
                    ),

                "current_value":
                    round(
                        current_value,
                        2
                    ),

                "recommendation_action":
                    action,

                "recommendation_amount":
                    round(
                        amount,
                        2
                    )
            })


        return {

            "portfolio_id":
                portfolio_id,

            "total_portfolio_value":
                round(
                    total_value,
                    2
                ),

            "recommendations":
                recommendations
        }


    # =====================================================
    # GET ONE REBALANCING ITEM
    # =====================================================

    def get_rebalancing_item(
        self,
        portfolio_id,
        asset_class_id
    ):

        data = (
            self.get_rebalancing(
                portfolio_id
            )
        )


        for item in data[
            "recommendations"
        ]:

            if (
                item[
                    "asset_class_id"
                ]
                ==
                asset_class_id
            ):

                return item


        raise ValueError(
            "Asset class is not part "
            "of this portfolio theme"
        )


    # =====================================================
    # INCREASE SUGGESTIONS
    #
    # Show active securities from that asset class.
    # =====================================================

    def get_increase_suggestions(
        self,
        portfolio_id,
        asset_class_id,
        recommended_amount
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    sm.security_id,

                    sm.symbol,

                    sm.security_name,

                    sm.instrument_type,

                    sm.data_source,

                    COALESCE(
                        ph.quantity,
                        0
                    ) AS current_quantity,

                    latest.trade_date
                        AS latest_price_date,

                    latest.close_price
                        AS latest_price

                FROM security_master sm


                LEFT JOIN portfolio_holding ph

                    ON
                        ph.security_id =
                            sm.security_id

                    AND

                        ph.portfolio_id = %s


                LEFT JOIN LATERAL (

                    SELECT

                        mph.trade_date,

                        mph.close_price

                    FROM market_price_history mph

                    WHERE

                        mph.security_id =
                            sm.security_id

                    ORDER BY

                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE


                WHERE

                    sm.asset_class_id = %s

                    AND

                    sm.status = 'ACTIVE'

                    AND

                    latest.close_price
                        IS NOT NULL


                ORDER BY

                    sm.symbol


                LIMIT 20
            """, (

                portfolio_id,

                asset_class_id

            ))


            rows = (
                cursor.fetchall()
            )


            suggestions = []


            amount = Decimal(
                recommended_amount
            )


            for row in rows:


                latest_price = Decimal(

                    row[
                        "latest_price"
                    ]

                )


                if latest_price <= 0:

                    continue


                # -----------------------------------------
                # Approx quantity if entire recommended
                # amount is invested in this security.
                # -----------------------------------------

                suggested_quantity = (

                    math.floor(

                        amount
                        /
                        latest_price

                    )

                )


                suggested_investment = (

                    Decimal(
                        suggested_quantity
                    )

                    *
                    latest_price

                )


                suggestions.append({

                    "security_id":
                        row[
                            "security_id"
                        ],

                    "symbol":
                        row[
                            "symbol"
                        ],

                    "security_name":
                        row[
                            "security_name"
                        ],

                    "instrument_type":
                        row[
                            "instrument_type"
                        ],

                    "data_source":
                        row[
                            "data_source"
                        ],

                    "already_owned_quantity":
                        row[
                            "current_quantity"
                        ],

                    "latest_price_date":
                        row[
                            "latest_price_date"
                        ],

                    "latest_price":
                        round(
                            latest_price,
                            2
                        ),

                    "suggested_quantity":
                        suggested_quantity,

                    "suggested_investment":
                        round(
                            suggested_investment,
                            2
                        )
                })


            return suggestions


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # REDUCE SUGGESTIONS
    #
    # Only show securities already owned in that
    # asset class.
    # =====================================================

    def get_reduce_suggestions(
        self,
        portfolio_id,
        asset_class_id,
        recommended_amount
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            cursor.execute("""
                SELECT

                    ph.holding_id,

                    ph.security_id,

                    sm.symbol,

                    sm.security_name,

                    ph.quantity,

                    ph.average_buy_price,

                    latest.trade_date
                        AS latest_price_date,

                    latest.close_price
                        AS latest_price,

                    (
                        ph.quantity
                        *
                        latest.close_price
                    ) AS current_value,

                    (
                        ph.quantity
                        *
                        (
                            latest.close_price
                            -
                            ph.average_buy_price
                        )
                    ) AS profit_loss


                FROM portfolio_holding ph


                JOIN security_master sm

                    ON
                        ph.security_id =
                            sm.security_id


                LEFT JOIN LATERAL (

                    SELECT

                        mph.trade_date,

                        mph.close_price

                    FROM market_price_history mph

                    WHERE

                        mph.security_id =
                            ph.security_id

                    ORDER BY

                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE


                WHERE

                    ph.portfolio_id = %s

                    AND

                    sm.asset_class_id = %s

                    AND

                    latest.close_price
                        IS NOT NULL


                ORDER BY

                    current_value DESC
            """, (

                portfolio_id,

                asset_class_id

            ))


            rows = (
                cursor.fetchall()
            )


            suggestions = []


            amount = Decimal(
                recommended_amount
            )


            for row in rows:


                latest_price = Decimal(

                    row[
                        "latest_price"
                    ]

                )


                quantity_owned = int(

                    row[
                        "quantity"
                    ]

                )


                if latest_price <= 0:

                    continue


                # -----------------------------------------
                # Quantity to sell approximately equal
                # to recommendation amount.
                #
                # Never greater than owned quantity.
                # -----------------------------------------

                calculated_quantity = (

                    math.floor(

                        amount
                        /
                        latest_price

                    )

                )


                suggested_quantity = min(

                    quantity_owned,

                    calculated_quantity

                )


                suggested_sell_value = (

                    Decimal(
                        suggested_quantity
                    )

                    *
                    latest_price

                )


                suggestions.append({

                    "holding_id":
                        row[
                            "holding_id"
                        ],

                    "security_id":
                        row[
                            "security_id"
                        ],

                    "symbol":
                        row[
                            "symbol"
                        ],

                    "security_name":
                        row[
                            "security_name"
                        ],

                    "quantity_owned":
                        quantity_owned,

                    "average_buy_price":
                        round(
                            Decimal(
                                row[
                                    "average_buy_price"
                                ]
                            ),
                            2
                        ),

                    "latest_price_date":
                        row[
                            "latest_price_date"
                        ],

                    "latest_price":
                        round(
                            latest_price,
                            2
                        ),

                    "current_value":
                        round(
                            Decimal(
                                row[
                                    "current_value"
                                ]
                            ),
                            2
                        ),

                    "profit_loss":
                        round(
                            Decimal(
                                row[
                                    "profit_loss"
                                ]
                            ),
                            2
                        ),

                    "suggested_quantity_to_sell":
                        suggested_quantity,

                    "suggested_sell_value":
                        round(
                            suggested_sell_value,
                            2
                        )
                })


            return suggestions


        finally:

            cursor.close()
            conn.close()


    # =====================================================
    # GET SECURITY SUGGESTIONS FOR REBALANCING
    # =====================================================

    def get_suggestions(
        self,
        portfolio_id,
        asset_class_id
    ):


        recommendation = (

            self.get_rebalancing_item(

                portfolio_id,

                asset_class_id

            )

        )


        action = (

            recommendation[
                "recommendation_action"
            ]

        )


        amount = Decimal(

            recommendation[
                "recommendation_amount"
            ]

        )


        asset_class_name = (

            recommendation[
                "asset_class_name"
            ]

        )


        # =================================================
        # HOLD
        # =================================================

        if action == "HOLD":

            return {

                "portfolio_id":
                    portfolio_id,

                "asset_class_id":
                    asset_class_id,

                "asset_class_name":
                    asset_class_name,

                "action":
                    "HOLD",

                "recommended_amount":
                    Decimal("0"),

                "message":
                    "Allocation is within the "
                    "5% tolerance. No transaction "
                    "is required.",

                "suggestions":
                    []
            }


        # =================================================
        # CASH
        #
        # Cash itself is not bought/sold.
        # =================================================

        if asset_class_name == "Cash":


            rebalancing = (
                self.get_rebalancing(
                    portfolio_id
                )
            )


            related_classes = []


            # ---------------------------------------------
            # Too much Cash:
            # invest into underallocated classes.
            # ---------------------------------------------

            if action == "REDUCE":


                for item in rebalancing[
                    "recommendations"
                ]:

                    if (

                        item[
                            "asset_class_name"
                        ]
                        !=
                        "Cash"

                        and

                        item[
                            "recommendation_action"
                        ]
                        ==
                        "INCREASE"

                    ):

                        related_classes.append({

                            "asset_class_id":
                                item[
                                    "asset_class_id"
                                ],

                            "asset_class_name":
                                item[
                                    "asset_class_name"
                                ],

                            "action":
                                "INCREASE",

                            "recommended_amount":
                                item[
                                    "recommendation_amount"
                                ]
                        })


                return {

                    "portfolio_id":
                        portfolio_id,

                    "asset_class_id":
                        asset_class_id,

                    "asset_class_name":
                        "Cash",

                    "action":
                        "REDUCE",

                    "recommended_amount":
                        round(
                            amount,
                            2
                        ),

                    "message":
                        "Cash is overallocated. "
                        "Use available cash to buy "
                        "securities from underallocated "
                        "asset classes.",

                    "related_asset_classes":
                        related_classes,

                    "suggestions":
                        []
                }


            # ---------------------------------------------
            # Too little Cash:
            # sell from overallocated classes.
            # ---------------------------------------------

            if action == "INCREASE":


                for item in rebalancing[
                    "recommendations"
                ]:

                    if (

                        item[
                            "asset_class_name"
                        ]
                        !=
                        "Cash"

                        and

                        item[
                            "recommendation_action"
                        ]
                        ==
                        "REDUCE"

                    ):

                        related_classes.append({

                            "asset_class_id":
                                item[
                                    "asset_class_id"
                                ],

                            "asset_class_name":
                                item[
                                    "asset_class_name"
                                ],

                            "action":
                                "REDUCE",

                            "recommended_amount":
                                item[
                                    "recommendation_amount"
                                ]
                        })


                return {

                    "portfolio_id":
                        portfolio_id,

                    "asset_class_id":
                        asset_class_id,

                    "asset_class_name":
                        "Cash",

                    "action":
                        "INCREASE",

                    "recommended_amount":
                        round(
                            amount,
                            2
                        ),

                    "message":
                        "Cash is underallocated. "
                        "Sell securities from "
                        "overallocated asset classes "
                        "to increase available cash.",

                    "related_asset_classes":
                        related_classes,

                    "suggestions":
                        []
                }


        # =================================================
        # NORMAL ASSET CLASS - INCREASE
        # =================================================

        if action == "INCREASE":


            suggestions = (

                self.get_increase_suggestions(

                    portfolio_id,

                    asset_class_id,

                    amount

                )

            )


            return {

                "portfolio_id":
                    portfolio_id,

                "asset_class_id":
                    asset_class_id,

                "asset_class_name":
                    asset_class_name,

                "action":
                    "INCREASE",

                "recommended_amount":
                    round(
                        amount,
                        2
                    ),

                "message":
                    f"{asset_class_name} is "
                    f"underallocated. Buy approximately "
                    f"₹{amount:.2f} from this asset class.",

                "suggestions":
                    suggestions
            }


        # =================================================
        # NORMAL ASSET CLASS - REDUCE
        # =================================================

        if action == "REDUCE":


            suggestions = (

                self.get_reduce_suggestions(

                    portfolio_id,

                    asset_class_id,

                    amount

                )

            )


            return {

                "portfolio_id":
                    portfolio_id,

                "asset_class_id":
                    asset_class_id,

                "asset_class_name":
                    asset_class_name,

                "action":
                    "REDUCE",

                "recommended_amount":
                    round(
                        amount,
                        2
                    ),

                "message":
                    f"{asset_class_name} is "
                    f"overallocated. Sell approximately "
                    f"₹{amount:.2f} from existing holdings.",

                "suggestions":
                    suggestions
            }


rebalancing_service = (
    RebalancingService()
)