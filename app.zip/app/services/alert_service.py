from decimal import Decimal

from app.services.allocation_service import (
    allocation_service
)

from app.repositories.alert_repository import (
    alert_repository
)


class AlertService:


    # =====================================================
    # RECALCULATE ALERTS
    # =====================================================

    def recalculate_alerts(
        self,
        portfolio_id
    ):

        allocation_data = (
            allocation_service
            .get_allocation(
                portfolio_id
            )
        )


        total_value = Decimal(

            allocation_data[
                "total_portfolio_value"
            ]

        )


        generated_alerts = []


        for item in allocation_data[
            "allocations"
        ]:


            target = Decimal(

                item[
                    "target_percentage"
                ]

            )


            current = Decimal(

                item[
                    "current_percentage"
                ]

            )


            deviation = (

                current
                -
                target

            )


            existing_alert = (
                alert_repository
                .get_active_alert(

                    portfolio_id,

                    item[
                        "asset_class_id"
                    ]

                )
            )


            # =============================================
            # ALERT ONLY WHEN MORE THAN 5%
            # Exactly 5% does NOT create alert.
            # =============================================

            if abs(deviation) > Decimal("5"):


                target_value = (

                    total_value

                    *
                    target

                    /
                    Decimal("100")

                )


                current_value = Decimal(

                    item[
                        "current_value"
                    ]

                )


                adjustment = (

                    target_value
                    -
                    current_value

                )


                # -----------------------------------------
                # Underallocated
                # -----------------------------------------

                if adjustment > 0:

                    action = "INCREASE"

                    amount = adjustment


                # -----------------------------------------
                # Overallocated
                # -----------------------------------------

                else:

                    action = "REDUCE"

                    amount = abs(
                        adjustment
                    )


                message = (

                    f"{item['asset_class_name']} "
                    f"allocation deviation is "
                    f"{deviation:.2f}%. "

                    f"Target = "
                    f"{target:.2f}%, "

                    f"Current = "
                    f"{current:.2f}%."

                )


                # -----------------------------------------
                # Existing alert → update
                # -----------------------------------------

                if existing_alert:

                    alert = (
                        alert_repository
                        .update_alert(

                            existing_alert[
                                "alert_id"
                            ],

                            message,

                            target,

                            current,

                            deviation,

                            action,

                            amount

                        )
                    )


                # -----------------------------------------
                # New alert
                # -----------------------------------------

                else:

                    alert = (
                        alert_repository
                        .create_alert(

                            portfolio_id,

                            item[
                                "asset_class_id"
                            ],

                            message,

                            target,

                            current,

                            deviation,

                            action,

                            amount

                        )
                    )


                generated_alerts.append(
                    alert
                )


            # =============================================
            # Deviation now within ±5%
            # Resolve previous alert.
            # =============================================

            else:

                if existing_alert:

                    alert_repository.resolve_alert(

                        existing_alert[
                            "alert_id"
                        ]

                    )


        return {

            "portfolio_id":
                portfolio_id,

            "alert_count":
                len(
                    generated_alerts
                ),

            "alerts":
                generated_alerts
        }


    # =====================================================
    # GET PORTFOLIO ALERTS
    # =====================================================

    def get_portfolio_alerts(
        self,
        portfolio_id
    ):

        return (
            alert_repository
            .get_portfolio_alerts(
                portfolio_id
            )
        )


    # =====================================================
    # GLOBAL ALERTS
    # =====================================================

    def get_all_alerts(self):

        return (
            alert_repository
            .get_all_alerts()
        )


    # =====================================================
    # ACCEPT / ACKNOWLEDGE
    # =====================================================

    def mark_read(
        self,
        alert_id
    ):

        alert = (
            alert_repository
            .mark_read(
                alert_id
            )
        )


        if not alert:

            raise ValueError(
                "Alert not found or "
                "already acknowledged"
            )


        return {

            "message":
                "Alert acknowledged successfully",

            "alert":
                alert
        }


alert_service = AlertService()