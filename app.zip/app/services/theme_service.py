from app.repositories.theme_repository import (
    theme_repository
)
 
 
class ThemeService:
 
 
    # =====================================================
    # VALIDATE ALLOCATIONS
    # =====================================================
 
    def validate_allocations(
        self,
        allocations
    ):
 
        # ---------------------------------------------
        # 1. Must contain allocations
        # ---------------------------------------------
 
        if len(allocations) == 0:
 
            raise ValueError(
                "Theme must contain "
                "asset class allocations"
            )
 
 
        # ---------------------------------------------
        # 2. Get active Asset Classes
        # ---------------------------------------------
 
        active_assets = (
            theme_repository
            .get_active_asset_classes()
        )
 
 
        active_asset_ids = []
 
        for asset in active_assets:
 
            active_asset_ids.append(
                asset["asset_class_id"]
            )
 
 
        # ---------------------------------------------
        # 3. Check duplicate asset classes
        # ---------------------------------------------
 
        entered_ids = []
 
 
        for item in allocations:
 
            if (
                item.asset_class_id
                in entered_ids
            ):
 
                raise ValueError(
                    "Same asset class "
                    "cannot be added twice"
                )
 
 
            entered_ids.append(
                item.asset_class_id
            )
 
 
        # ---------------------------------------------
        # 4. Validate Asset Class IDs
        # ---------------------------------------------
 
        for item in allocations:
 
            if (
                item.asset_class_id
                not in active_asset_ids
            ):
 
                raise ValueError(
                    f"Asset class ID "
                    f"{item.asset_class_id} "
                    f"is invalid or inactive"
                )
 
 
        # ---------------------------------------------
        # 5. Percentage validation
        # ---------------------------------------------
 
        total = 0
 
 
        for item in allocations:
 
            if (
                item.allocation_percentage
                < 0
                or
                item.allocation_percentage
                > 100
            ):
 
                raise ValueError(
                    "Allocation percentage "
                    "must be between 0 and 100"
                )
 
 
            total = (
                total
                +
                item.allocation_percentage
            )
 
 
        # ---------------------------------------------
        # 6. Total MUST BE 100
        # ---------------------------------------------
 
        if round(total, 2) != 100:
 
            raise ValueError(
                f"Theme allocation must "
                f"total exactly 100%. "
                f"Current total = "
                f"{round(total, 2)}%"
            )
 
 
    # =====================================================
    # CREATE
    # =====================================================
 
    def create_theme(
        self,
        data
    ):
 
        existing = (
            theme_repository
            .get_theme_by_name(
                data.theme_name
            )
        )
 
 
        if existing is not None:
 
            raise ValueError(
                "Theme already exists"
            )
 
 
        self.validate_allocations(
            data.allocations
        )
 
 
        theme_id = (
            theme_repository
            .create_theme(
 
                theme_name=(
                    data.theme_name
                ),
 
                description=(
                    data.description
                ),
 
                risk_level=(
                    data.risk_level
                ),
 
                investment_horizon=(
                    data.investment_horizon
                ),
 
                allocations=(
                    data.allocations
                )
            )
        )
 
 
        return {
 
            "message":
                "Theme created successfully",
 
            "theme_id":
                theme_id
        }
 
 
    # =====================================================
    # GET ALL
    # =====================================================
 
    def get_all_themes(self):
 
        return (
            theme_repository
            .get_all_themes()
        )
 
 
    # =====================================================
    # GET ONE
    # =====================================================
 
    def get_theme_by_id(
        self,
        theme_id
    ):
 
        theme = (
            theme_repository
            .get_theme_by_id(
                theme_id
            )
        )
 
 
        if theme is None:
 
            raise ValueError(
                "Theme not found"
            )
 
 
        return theme
 
 
    # =====================================================
    # UPDATE
    # =====================================================
 
    def update_theme(
        self,
        theme_id,
        data
    ):
 
        current = (
            theme_repository
            .get_theme_by_id(
                theme_id
            )
        )
 
 
        if current is None:
 
            raise ValueError(
                "Theme not found"
            )
 
 
        if data.status not in [
            "ACTIVE",
            "INACTIVE"
        ]:
 
            raise ValueError(
                "Status must be ACTIVE "
                "or INACTIVE"
            )
 
 
        same_name = (
            theme_repository
            .get_theme_by_name(
                data.theme_name
            )
        )
 
 
        if (
            same_name is not None
            and
            same_name["theme_id"]
            != theme_id
        ):
 
            raise ValueError(
                "Another theme already "
                "uses this name"
            )
 
 
        self.validate_allocations(
            data.allocations
        )
 
 
        theme_repository.update_theme(
 
            theme_id=theme_id,
 
            theme_name=(
                data.theme_name
            ),
 
            description=(
                data.description
            ),
 
            risk_level=(
                data.risk_level
            ),
 
            investment_horizon=(
                data.investment_horizon
            ),
 
            status=(
                data.status
            ),
 
            allocations=(
                data.allocations
            )
        )
 
 
        return {
 
            "message":
                "Theme updated successfully"
        }
 
 
    # =====================================================
    # DELETE / DEACTIVATE
    # =====================================================
 
    def deactivate_theme(
        self,
        theme_id
    ):
 
        theme = (
            theme_repository
            .get_theme_by_id(
                theme_id
            )
        )
 
 
        if theme is None:
 
            raise ValueError(
                "Theme not found"
            )
 
 
        if (
            theme["status"]
            == "INACTIVE"
        ):
 
            raise ValueError(
                "Theme is already inactive"
            )
 
 
        theme_repository.deactivate_theme(
            theme_id
        )
 
 
        return {
 
            "message":
                "Theme deactivated successfully"
        }
 
 
theme_service = ThemeService()