from decimal import Decimal

from app.database.connection import (
    get_db_connection
)


class PerformanceService:


    # =====================================================
    # GET PORTFOLIO PERFORMANCE
    # =====================================================

    def get_performance(
        self,
        portfolio_id: int
    ):

        conn = get_db_connection()
        cursor = conn.cursor()

        try:

            # =================================================
            # 1. PORTFOLIO BASIC DETAILS
            # =================================================

            cursor.execute("""
                SELECT

                    portfolio_id,
                    portfolio_name,

                    initial_investment,
                    available_balance,

                    portfolio_start_date,

                    benchmark_name,
                    benchmark_key,
                    benchmark_start_value,

                    status

                FROM portfolio

                WHERE
                    portfolio_id = %s
            """, (
                portfolio_id,
            ))


            portfolio = (
                cursor.fetchone()
            )


            if not portfolio:

                raise ValueError(
                    "Portfolio not found"
                )


            initial_investment = Decimal(

                portfolio[
                    "initial_investment"
                ]

            )


            available_balance = Decimal(

                portfolio[
                    "available_balance"
                ]

            )


            # =================================================
            # 2. CURRENT VALUE OF ALL HOLDINGS
            # =================================================

            cursor.execute("""
                SELECT

                    COALESCE(

                        SUM(

                            ph.quantity

                            *

                            latest.close_price

                        ),

                        0

                    ) AS holdings_current_value

                FROM portfolio_holding ph


                LEFT JOIN LATERAL (

                    SELECT
                        mph.close_price

                    FROM market_price_history mph

                    WHERE
                        mph.security_id =
                            ph.security_id

                    ORDER BY
                        mph.trade_date DESC

                    LIMIT 1

                ) latest
                    ON TRUE


                WHERE
                    ph.portfolio_id = %s
            """, (
                portfolio_id,
            ))


            holdings_row = (
                cursor.fetchone()
            )


            holdings_current_value = Decimal(

                holdings_row[
                    "holdings_current_value"
                ]

                or 0

            )


            # =================================================
            # 3. CURRENT PORTFOLIO VALUE
            # =================================================

            current_portfolio_value = (

                available_balance

                +

                holdings_current_value

            )


            # =================================================
            # 4. OVERALL PROFIT / LOSS
            # =================================================

            profit_loss = (

                current_portfolio_value

                -

                initial_investment

            )


            # =================================================
            # 5. PORTFOLIO RETURN %
            # =================================================

            if initial_investment > 0:

                portfolio_return = (

                    profit_loss

                    /

                    initial_investment

                    *

                    Decimal("100")

                )

            else:

                portfolio_return = (
                    Decimal("0")
                )


            # =================================================
            # 6. BENCHMARK START VALUE
            # =================================================

            benchmark_start_value = (

                portfolio[
                    "benchmark_start_value"
                ]

            )


            if benchmark_start_value is None:

                raise ValueError(

                    "Benchmark start value is not available. "
                    "Activate the portfolio first."

                )


            benchmark_start_value = Decimal(

                benchmark_start_value

            )


            # =================================================
            # 7. GET LATEST NIFTY 50 VALUE
            # =================================================

            cursor.execute("""
                SELECT

                    benchmark_code,
                    benchmark_name,
                    price_date,
                    close_value

                FROM benchmark_price_history

                WHERE
                    benchmark_code = 'NIFTY50'

                ORDER BY
                    price_date DESC

                LIMIT 1
            """)


            benchmark_latest = (
                cursor.fetchone()
            )


            if not benchmark_latest:

                raise ValueError(
                    "NIFTY 50 benchmark data "
                    "is not available"
                )


            benchmark_current_value = Decimal(

                benchmark_latest[
                    "close_value"
                ]

            )


            # =================================================
            # 8. NIFTY RETURN %
            # =================================================

            benchmark_return = (

                (
                    benchmark_current_value

                    -

                    benchmark_start_value
                )

                /

                benchmark_start_value

                *

                Decimal("100")

            )


            # =================================================
            # 9. RELATIVE PERFORMANCE
            # =================================================

            relative_performance = (

                portfolio_return

                -

                benchmark_return

            )


            # =================================================
            # 10. SIMPLE DISPLAY RESULT
            # =================================================

            if relative_performance > 0:

                comparison = (
                    "Portfolio return is above "
                    "the benchmark return"
                )


            elif relative_performance < 0:

                comparison = (
                    "Portfolio return is below "
                    "the benchmark return"
                )


            else:

                comparison = (
                    "Portfolio return is equal "
                    "to the benchmark return"
                )


            return {

                "portfolio_id":
                    portfolio[
                        "portfolio_id"
                    ],

                "portfolio_name":
                    portfolio[
                        "portfolio_name"
                    ],

                "portfolio_start_date":
                    portfolio[
                        "portfolio_start_date"
                    ],


                # -----------------------------------------
                # Portfolio
                # -----------------------------------------

                "initial_investment":
                    round(
                        initial_investment,
                        2
                    ),

                "available_balance":
                    round(
                        available_balance,
                        2
                    ),

                "holdings_current_value":
                    round(
                        holdings_current_value,
                        2
                    ),

                "current_portfolio_value":
                    round(
                        current_portfolio_value,
                        2
                    ),

                "profit_loss":
                    round(
                        profit_loss,
                        2
                    ),

                "portfolio_return_percentage":
                    round(
                        portfolio_return,
                        2
                    ),


                # -----------------------------------------
                # Benchmark
                # -----------------------------------------

                "benchmark_name":
                    portfolio[
                        "benchmark_name"
                    ],

                "benchmark_start_value":
                    round(
                        benchmark_start_value,
                        2
                    ),

                "benchmark_latest_date":
                    benchmark_latest[
                        "price_date"
                    ],

                "benchmark_current_value":
                    round(
                        benchmark_current_value,
                        2
                    ),

                "benchmark_return_percentage":
                    round(
                        benchmark_return,
                        2
                    ),


                # -----------------------------------------
                # Comparison
                # -----------------------------------------

                "relative_performance_percentage":
                    round(
                        relative_performance,
                        2
                    ),

                "comparison":
                    comparison
            }


        finally:

            cursor.close()
            conn.close()


performance_service = (
    PerformanceService()
)