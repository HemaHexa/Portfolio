import {
  NavLink,
  useNavigate
} from "react-router-dom";

import "../styles/common.css";


function Sidebar() {

  const navigate = useNavigate();


  const logout = () => {

    localStorage.removeItem(
      "portfolio_user"
    );

    navigate("/login");

  };


  const menu = [

    {
      name: "Dashboard",
      path: "/dashboard",
      icon: "⌂"
    },

    {
      name: "Security Master",
      path: "/securities",
      icon: "◆"
    },

    {
      name: "Asset Classes",
      path: "/asset-classes",
      icon: "▦"
    },

    {
      name: "Investment Themes",
      path: "/themes",
      icon: "◈"
    },

    {
      name: "Portfolios",
      path: "/portfolios",
      icon: "▣"
    },

    {
      name: "Alerts",
      path: "/alerts",
      icon: "!"
    }

  ];


  return (

    <aside className="sidebar">

      <div className="sidebar-logo">

        <h2>FundSphere</h2>

        <span>
          Portfolio Management
        </span>

      </div>


      <div className="sidebar-menu">

        {
          menu.map(
            item => (

              <NavLink

                key={item.path}

                to={item.path}

                className={
                  ({ isActive }) =>
                    isActive
                      ? "sidebar-link active"
                      : "sidebar-link"
                }

              >

                <span className="sidebar-icon">
                  {item.icon}
                </span>

                <span>
                  {item.name}
                </span>

              </NavLink>

            )
          )
        }

      </div>


      <div className="sidebar-bottom">

        <button

          onClick={logout}

          className="sidebar-link"

          style={{
            width: "100%",
            border: "none",
            background: "transparent"
          }}

        >

          <span className="sidebar-icon">
            ↗
          </span>

          <span>
            Logout
          </span>

        </button>

      </div>

    </aside>

  );

}


export default Sidebar;