import { NavLink } from "react-router-dom";
 
function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <h2>Portfolio</h2>
        <span>Management System</span>
      </div>
 
      <nav className="sidebar-nav">
        <NavLink to="/" end>
          Dashboard
        </NavLink>
 
        <NavLink to="/portfolios">
          Portfolios
        </NavLink>
 
        <NavLink to="/securities">
          Security Master
        </NavLink>
 
        <NavLink to="/asset-classes">
          Asset Classes
        </NavLink>
 
        <NavLink to="/themes">
          Investment Themes
        </NavLink>
 
        <NavLink to="/benchmarks">
          Benchmarks
        </NavLink>
      </nav>
    </aside>
  );
}
 
export default Sidebar;