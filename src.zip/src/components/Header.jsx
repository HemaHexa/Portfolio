function Header() {
  return (
    <header className="header">
      <div>
        <h3>Portfolio Management System</h3>
      </div>
 
      <div className="header-user">
        <span>Fund Manager</span>
      </div>
    </header>
  );
}
 
export default Header;