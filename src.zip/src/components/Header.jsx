function Header() {

  return (

    <header className="top-header">

      <div className="header-title">

        Portfolio Management System

      </div>


      <div className="header-user">

        <div className="user-avatar">
          FM
        </div>


        <div className="user-info">

          <strong>
            Fund Manager
          </strong>

          <span>
            Portfolio Manager
          </span>

        </div>

      </div>

    </header>

  );

}


export default Header;
