import React from "react";

import ReactDOM
from "react-dom/client";

import {
  BrowserRouter
} from "react-router-dom";

import App
from "./App";

import "./index.css";

import { AlertToastProvider } from "./context/AlertToastContext";

ReactDOM
  .createRoot(
    document.getElementById(
      "root"
    )
  )
  .render(

    <React.StrictMode>

      <BrowserRouter>
        <AlertToastProvider>
          <App />
        </AlertToastProvider>

      </BrowserRouter>

    </React.StrictMode>

  );