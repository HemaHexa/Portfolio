import {
  useEffect,
  useState
} from "react";

import api from "../api/api";

import "../styles/common.css";


function Themes() {

  const [themes, setThemes] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [editingTheme, setEditingTheme] =
    useState(null);

  const [message, setMessage] =
    useState("");

  const [form, setForm] =
    useState({

      theme_name: "",

      description: "",

      risk_level: "",

      investment_horizon: "",

      status: "ACTIVE",

      allocations: []

    });


  // =====================================================
  // LOAD THEMES
  // =====================================================

  useEffect(() => {

    loadThemes();

  }, []);


  async function loadThemes() {

    try {

      setLoading(true);

      setMessage("");


      const response =
        await api.get(
          "/api/themes"
        );


      console.log(
        "THEME LIST RESPONSE:",
        response.data
      );


      let list = [];


      if (
        Array.isArray(
          response.data
        )
      ) {

        list =
          response.data;

      }

      else if (
        Array.isArray(
          response.data?.themes
        )
      ) {

        list =
          response.data.themes;

      }

      else if (
        Array.isArray(
          response.data?.data
        )
      ) {

        list =
          response.data.data;

      }


      // =================================================
      // GET FULL DETAILS FOR EACH THEME
      // So allocations are definitely available.
      // =================================================

      const detailedThemes =
        await Promise.all(

          list.map(
            async theme => {

              try {

                const detailResponse =
                  await api.get(

                    `/api/themes/${theme.theme_id}`

                  );


                console.log(
                  `THEME ${theme.theme_id}:`,
                  detailResponse.data
                );


                return normalizeTheme(

                  detailResponse.data,

                  theme

                );

              }

              catch (error) {

                console.log(
                  "THEME DETAIL ERROR:",
                  error
                );


                return normalizeTheme(
                  theme,
                  theme
                );

              }

            }
          )

        );


      setThemes(
        detailedThemes
      );

    }

    catch (error) {

      console.log(
        "THEMES ERROR:",
        error
      );


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to load investment themes"

      );

    }

    finally {

      setLoading(false);

    }

  }


  // =====================================================
  // NORMALIZE BACKEND RESPONSE
  // =====================================================

  function normalizeTheme(
    data,
    fallback
  ) {

    const themeData =
      data?.theme
      ||
      data?.data?.theme
      ||
      data?.data
      ||
      data
      ||
      fallback;


    let allocations = [];


    if (
      Array.isArray(
        data?.allocations
      )
    ) {

      allocations =
        data.allocations;

    }

    else if (
      Array.isArray(
        data?.theme_allocations
      )
    ) {

      allocations =
        data.theme_allocations;

    }

    else if (
      Array.isArray(
        themeData?.allocations
      )
    ) {

      allocations =
        themeData.allocations;

    }

    else if (
      Array.isArray(
        fallback?.allocations
      )
    ) {

      allocations =
        fallback.allocations;

    }


    return {

      ...fallback,

      ...themeData,

      allocations:
        allocations

    };

  }


  // =====================================================
  // EDIT
  // =====================================================

  async function editTheme(
    theme
  ) {

    try {

      const response =
        await api.get(

          `/api/themes/${theme.theme_id}`

        );


      const fullTheme =
        normalizeTheme(
          response.data,
          theme
        );


      setEditingTheme(
        fullTheme
      );


      setForm({

        theme_name:
          fullTheme.theme_name
          || "",

        description:
          fullTheme.description
          || "",

        risk_level:
          fullTheme.risk_level
          || "",

        investment_horizon:
          fullTheme.investment_horizon
          || "",

        status:
          fullTheme.status
          || "ACTIVE",

        allocations:
          fullTheme.allocations
          .map(
            item => ({

              asset_class_id:
                item.asset_class_id,

              asset_class_name:
                item.asset_class_name,

              allocation_percentage:
                Number(
                  item.allocation_percentage
                  || 0
                )

            })
          )

      });


      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });

    }

    catch (error) {

      console.log(error);

      setMessage(
        "Unable to load theme details"
      );

    }

  }


  // =====================================================
  // BASIC INPUT CHANGE
  // =====================================================

  function handleChange(e) {

    const {
      name,
      value
    } = e.target;


    setForm({

      ...form,

      [name]:
        value

    });

  }


  // =====================================================
  // ALLOCATION CHANGE
  // =====================================================

  function changeAllocation(
    assetClassId,
    value
  ) {

    const numericValue =
      value === ""
        ? 0
        : Number(value);


    setForm({

      ...form,

      allocations:
        form.allocations.map(

          item =>

            item.asset_class_id
            ===
            assetClassId

              ? {
                  ...item,

                  allocation_percentage:
                    numericValue
                }

              : item

        )

    });

  }


  // =====================================================
  // TOTAL
  // =====================================================

  const allocationTotal =
    form.allocations.reduce(

      (total, item) =>

        total
        +
        Number(
          item.allocation_percentage
          || 0
        ),

      0

    );


  // =====================================================
  // SAVE
  // =====================================================

  async function saveTheme(e) {

    e.preventDefault();


    if (!editingTheme) {

      return;

    }


    if (
      Math.abs(
        allocationTotal - 100
      )
      > 0.001
    ) {

      setMessage(
        `Allocation must total 100%. Current total = ${allocationTotal}%`
      );

      return;

    }


    try {

      const payload = {

        theme_name:
          form.theme_name,

        description:
          form.description,

        risk_level:
          form.risk_level,

        investment_horizon:
          form.investment_horizon,

        status:
          form.status,

        allocations:
          form.allocations.map(
            item => ({

              asset_class_id:
                item.asset_class_id,

              allocation_percentage:
                Number(
                  item.allocation_percentage
                )

            })
          )

      };


      await api.put(

        `/api/themes/${editingTheme.theme_id}`,

        payload

      );


      setMessage(
        "Investment theme updated successfully"
      );


      closeEdit();

      await loadThemes();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to update investment theme"

      );

    }

  }


  // =====================================================
  // DEACTIVATE
  // =====================================================

  async function deactivateTheme(
    theme
  ) {

    if (
      !window.confirm(
        `Deactivate ${theme.theme_name}?`
      )
    ) {

      return;

    }


    try {

      await api.delete(

        `/api/themes/${theme.theme_id}`

      );


      setMessage(
        "Investment theme deactivated successfully"
      );


      await loadThemes();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to deactivate theme"

      );

    }

  }


  // =====================================================
  // ACTIVATE
  // =====================================================

  async function activateTheme(
    theme
  ) {

    try {

      const response =
        await api.get(

          `/api/themes/${theme.theme_id}`

        );


      const fullTheme =
        normalizeTheme(
          response.data,
          theme
        );


      const payload = {

        theme_name:
          fullTheme.theme_name,

        description:
          fullTheme.description,

        risk_level:
          fullTheme.risk_level,

        investment_horizon:
          fullTheme.investment_horizon,

        status:
          "ACTIVE",

        allocations:
          fullTheme.allocations.map(
            item => ({

              asset_class_id:
                item.asset_class_id,

              allocation_percentage:
                Number(
                  item.allocation_percentage
                )

            })
          )

      };


      await api.put(

        `/api/themes/${theme.theme_id}`,

        payload

      );


      setMessage(
        "Investment theme activated successfully"
      );


      await loadThemes();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to activate theme"

      );

    }

  }


  // =====================================================
  // CLOSE
  // =====================================================

  function closeEdit() {

    setEditingTheme(
      null
    );


    setForm({

      theme_name: "",

      description: "",

      risk_level: "",

      investment_horizon: "",

      status: "ACTIVE",

      allocations: []

    });

  }


  // =====================================================
  // UI
  // =====================================================

  return (

    <div>


      <div className="page-heading">

        <h1>
          Investment Themes
        </h1>

        <p>
          Manage risk profiles and target
          asset allocations for the five
          investment themes.
        </p>

      </div>


      {
        message
        &&
        (

          <div className="asset-message">

            {message}

          </div>

        )
      }


      {/* =================================================
          EDIT FORM
      ================================================= */}

      {
        editingTheme
        &&
        (

          <div className="content-card">

            <div className="section-heading">

              <div>

                <h3>
                  Edit {form.theme_name}
                </h3>

                <p>
                  Allocation percentages must
                  total exactly 100%.
                </p>

              </div>


              <button

                className="close-form-button"

                onClick={
                  closeEdit
                }

              >

                ×

              </button>

            </div>


            <form
              onSubmit={
                saveTheme
              }
            >

              <div className="asset-form-grid">


                <div className="form-group">

                  <label>
                    Theme Name
                  </label>


                  <input

                    className="form-control"

                    name="theme_name"

                    value={
                      form.theme_name
                    }

                    onChange={
                      handleChange
                    }

                  />

                </div>


                <div className="form-group">

                  <label>
                    Risk Level
                  </label>


                  <input

                    className="form-control"

                    name="risk_level"

                    value={
                      form.risk_level
                    }

                    onChange={
                      handleChange
                    }

                  />

                </div>


                <div className="form-group">

                  <label>
                    Investment Horizon
                  </label>


                  <input

                    className="form-control"

                    name="investment_horizon"

                    value={
                      form.investment_horizon
                    }

                    onChange={
                      handleChange
                    }

                  />

                </div>


                <div className="form-group">

                  <label>
                    Status
                  </label>


                  <input

                    className="form-control"

                    value={
                      form.status
                    }

                    disabled

                  />

                </div>


                <div className="form-group full-width">

                  <label>
                    Description
                  </label>


                  <textarea

                    className="form-control asset-textarea"

                    name="description"

                    value={
                      form.description
                    }

                    onChange={
                      handleChange
                    }

                  />

                </div>

              </div>


              {/* =========================================
                  ALLOCATIONS
              ========================================= */}

              <div className="theme-allocation-editor">

                <div className="theme-allocation-header">

                  <div>

                    <h3>
                      Target Allocation
                    </h3>

                    <p>
                      Enter the target percentage
                      for each asset class.
                    </p>

                  </div>


                  <div
                    className={
                      Math.abs(
                        allocationTotal - 100
                      )
                      < 0.001

                        ? "allocation-total valid-total"

                        : "allocation-total invalid-total"
                    }
                  >

                    Total:
                    {" "}
                    {allocationTotal.toFixed(2)}%

                  </div>

                </div>


                <div className="allocation-edit-grid">

                  {
                    form.allocations.map(
                      item => (

                        <div

                          className="allocation-edit-row"

                          key={
                            item.asset_class_id
                          }

                        >

                          <div>

                            <strong>
                              {
                                item.asset_class_name
                              }
                            </strong>

                          </div>


                          <div className="allocation-input-wrap">

                            <input

                              type="number"

                              min="0"

                              max="100"

                              step="0.01"

                              className="form-control"

                              value={
                                item.allocation_percentage
                              }

                              onChange={
                                e =>
                                  changeAllocation(

                                    item.asset_class_id,

                                    e.target.value

                                  )
                              }

                            />

                            <span>
                              %
                            </span>

                          </div>

                        </div>

                      )
                    )
                  }

                </div>

              </div>


              <div className="form-actions">

                <button

                  type="button"

                  className="secondary-button"

                  onClick={
                    closeEdit
                  }

                >

                  Cancel

                </button>


                <button

                  type="submit"

                  className="primary-button"

                  disabled={
                    Math.abs(
                      allocationTotal - 100
                    )
                    > 0.001
                  }

                >

                  Save Theme

                </button>

              </div>

            </form>

          </div>

        )
      }


      {/* =================================================
          THEME CARDS
      ================================================= */}

      {
        loading
        ?

        (

          <p className="small-muted">
            Loading themes...
          </p>

        )

        :

        (

          <div className="theme-grid">

            {
              themes.map(
                theme => {

                  const total =
                    theme.allocations
                    ?.reduce(
                      (sum, item) =>
                        sum
                        +
                        Number(
                          item.allocation_percentage
                          || 0
                        ),
                      0
                    )
                    || 0;


                  return (

                    <div

                      className="theme-card"

                      key={
                        theme.theme_id
                      }

                    >

                      <div className="asset-class-card-top">

                        <div className="card-icon icon-purple">

                          ◈

                        </div>


                        <span

                          className={
                            theme.status === "ACTIVE"

                              ? "status-badge active-status"

                              : "status-badge inactive-status"
                          }

                        >

                          {theme.status}

                        </span>

                      </div>


                      <h3>
                        {theme.theme_name}
                      </h3>


                      <p className="theme-description">

                        {
                          theme.description
                          ||
                          "No description available"
                        }

                      </p>


                      <div className="theme-meta">

                        <div>

                          <span>
                            Risk
                          </span>

                          <strong>
                            {
                              theme.risk_level
                              || "-"
                            }
                          </strong>

                        </div>


                        <div>

                          <span>
                            Horizon
                          </span>

                          <strong>
                            {
                              theme.investment_horizon
                              || "-"
                            }
                          </strong>

                        </div>

                      </div>


                      <div className="theme-allocation-list">

                        {
                          theme.allocations
                          ?.map(
                            allocation => (

                              <div

                                className="theme-allocation-item"

                                key={
                                  allocation.asset_class_id
                                }

                              >

                                <div className="theme-allocation-label">

                                  <span>

                                    {
                                      allocation.asset_class_name
                                    }

                                  </span>


                                  <strong>

                                    {
                                      Number(
                                        allocation.allocation_percentage
                                        || 0
                                      )
                                    }
                                    %

                                  </strong>

                                </div>


                                <div className="allocation-bar">

                                  <div

                                    className="allocation-bar-fill"

                                    style={{

                                      width:
                                        `${Math.min(
                                          Number(
                                            allocation.allocation_percentage
                                            || 0
                                          ),
                                          100
                                        )}%`

                                    }}

                                  />

                                </div>

                              </div>

                            )
                          )
                        }

                      </div>


                      <div className="theme-total">

                        Total Allocation

                        <strong>
                          {total.toFixed(0)}%
                        </strong>

                      </div>


                      <div className="asset-card-actions">

                        <button

                          className="small-action-button"

                          onClick={
                            () =>
                              editTheme(
                                theme
                              )
                          }

                        >

                          Edit

                        </button>


                        {
                          theme.status === "ACTIVE"
                          ?

                          (

                            <button

                              className="small-action-button danger-button"

                              onClick={
                                () =>
                                  deactivateTheme(
                                    theme
                                  )
                              }

                            >

                              Deactivate

                            </button>

                          )

                          :

                          (

                            <button

                              className="small-action-button activate-button"

                              onClick={
                                () =>
                                  activateTheme(
                                    theme
                                  )
                              }

                            >

                              Activate

                            </button>

                          )
                        }

                      </div>

                    </div>

                  );

                }
              )
            }

          </div>

        )
      }

    </div>

  );

}


export default Themes;