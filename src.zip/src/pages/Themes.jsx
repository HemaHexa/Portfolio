import { useEffect, useState } from "react";
import { getThemes } from "../api/api";
 
 
function Themes() {
 
  const [themes, setThemes] = useState([]);
 
 
  useEffect(() => {
 
    getThemes().then((data) => {
      setThemes(data);
    });
 
  }, []);
 
 
  return (
    <div>
 
      <h1>Investment Themes</h1>
 
      <table border="1" cellPadding="10">
 
        <thead>
          <tr>
            <th>ID</th>
            <th>Theme Name</th>
            <th>Description</th>
            <th>Risk</th>
            <th>Investment Horizon</th>
            <th>Status</th>
          </tr>
        </thead>
 
        <tbody>
 
          {themes.map((theme) => (
 
            <tr key={theme.theme_id}>
 
              <td>{theme.theme_id}</td>
 
              <td>{theme.theme_name}</td>
 
              <td>{theme.description}</td>
 
              <td>{theme.risk_level}</td>
 
              <td>{theme.investment_horizon}</td>
 
              <td>{theme.status}</td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
    </div>
  );
}
 
 
export default Themes;