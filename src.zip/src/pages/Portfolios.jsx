import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
 
import { getPortfolios } from "../api/api";
 
 
function Portfolios() {
 
  const [portfolios, setPortfolios] = useState([]);
 
 
  useEffect(() => {
 
    getPortfolios().then((data) => {
      setPortfolios(data);
    });
 
  }, []);
 
 
  return (
    <div>
 
      <h1>Portfolios</h1>
 
      <Link to="/portfolios/create">
        <button>Create Portfolio</button>
      </Link>
 
      <br />
      <br />
 
      <table border="1" cellPadding="10">
 
        <thead>
 
          <tr>
            <th>ID</th>
            <th>Portfolio Name</th>
            <th>Type</th>
            <th>Currency</th>
            <th>Exchange</th>
            <th>Initial Investment</th>
            <th>Available Balance</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {portfolios.map((portfolio) => (
 
            <tr key={portfolio.portfolio_id}>
 
              <td>
                {portfolio.portfolio_id}
              </td>
 
              <td>
                {portfolio.portfolio_name}
              </td>
 
              <td>
                {portfolio.portfolio_type}
              </td>
 
              <td>
                {portfolio.currency}
              </td>
 
              <td>
                {portfolio.exchange}
              </td>
 
              <td>
                {portfolio.initial_investment}
              </td>
 
              <td>
                {portfolio.available_balance}
              </td>
 
              <td>
                {portfolio.status}
              </td>
 
              <td>
 
                <Link
                  to={`/portfolios/${portfolio.portfolio_id}`}
                >
                  <button>
                    View
                  </button>
                </Link>
 
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
    </div>
  );
}
 
 
export default Portfolios;
 