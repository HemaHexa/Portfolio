import {
  useEffect,
  useState
} from "react";

import {
  useNavigate
} from "react-router-dom";

import api from "../api/api";

import "../styles/common.css";


function Portfolios() {

  const navigate = useNavigate();


  const [portfolios, setPortfolios] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [message, setMessage] =
    useState("");


  // =====================================================
  // LOAD PORTFOLIOS
  // =====================================================

  useEffect(() => {

    loadPortfolios();

  }, []);


  async function loadPortfolios() {

    try {

      setLoading(true);

      setMessage("");


      const response =
        await api.get(
          "/api/portfolios"
        );


      console.log(
        "PORTFOLIO LIST:",
        response.data
      );


      let list = [];


      if (
        Array.isArray(
          response.data
        )
      ) {

        list =
          response.data;

      }

      else if (
        Array.isArray(
          response.data?.portfolios
        )
      ) {

        list =
          response.data.portfolios;

      }

      else if (
        Array.isArray(
          response.data?.data
        )
      ) {

        list =
          response.data.data;

      }


      setPortfolios(
        list
      );

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to load portfolios"

      );

    }

    finally {

      setLoading(false);

    }

  }


  // =====================================================
  // ACTIVATE PORTFOLIO
  // =====================================================

  async function activatePortfolio(
    portfolioId
  ) {

    const confirmed =
      window.confirm(
        "Activate this portfolio?"
      );


    if (!confirmed) {

      return;

    }


    try {

      const response =
        await api.put(

          `/api/portfolios/${portfolioId}/activate`

        );


      console.log(
        "ACTIVATE RESPONSE:",
        response.data
      );


      setMessage(
        "Portfolio activated successfully"
      );


      await loadPortfolios();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to activate portfolio"

      );

    }

  }


  // =====================================================
  // MONEY FORMAT
  // =====================================================

  function money(value) {

    return Number(
      value || 0
    ).toLocaleString(
      "en-IN",
      {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }
    );

  }


  return (

    <div>


      {/* ===============================================
          HEADER
      =============================================== */}

      <div className="page-heading-row">

        <div className="page-heading">

          <h1>
            Portfolios
          </h1>

          <p>
            Create, activate and manage
            investment portfolios.
          </p>

        </div>


        <button

          className="primary-button"

          onClick={
            () =>
              navigate(
                "/portfolios/new"
              )
          }

        >

          + Create Portfolio

        </button>

      </div>


      {/* ===============================================
          MESSAGE
      =============================================== */}

      {
        message
        &&
        (

          <div className="asset-message">

            {message}

          </div>

        )
      }


      {/* ===============================================
          LIST
      =============================================== */}

      {
        loading
        ?

        (

          <p className="small-muted">
            Loading portfolios...
          </p>

        )

        :

        portfolios.length === 0
        ?

        (

          <div className="content-card">

            <h3>
              No Portfolios Yet
            </h3>

            <p className="content-card-subtitle">

              Create your first portfolio
              to begin investing.

            </p>

          </div>

        )

        :

        (

          <div className="portfolio-grid">

            {
              portfolios.map(
                portfolio => (

                  <div

                    className="portfolio-card"

                    key={
                      portfolio.portfolio_id
                    }

                  >


                    {/* TOP */}

                    <div className="portfolio-card-top">

                      <div
                        className="card-icon icon-blue"
                      >

                        ▣

                      </div>


                      <span

                        className={
                          portfolio.status === "Active"

                            ? "status-badge active-status"

                            : portfolio.status === "Closed"

                              ? "status-badge inactive-status"

                              : "status-badge new-status"
                        }

                      >

                        {
                          portfolio.status
                        }

                      </span>

                    </div>


                    {/* NAME */}

                    <h3>

                      {
                        portfolio.portfolio_name
                      }

                    </h3>


                    <p className="portfolio-manager">

                      Manager:
                      {" "}
                      {
                        portfolio.portfolio_manager
                      }

                    </p>


                    {/* DETAILS */}

                    <div className="portfolio-details">


                      <div>

                        <span>
                          Theme
                        </span>

                        <strong>

                          {
                            portfolio.theme_name
                            ||
                            "-"
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Type
                        </span>

                        <strong>

                          {
                            portfolio.portfolio_type
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Benchmark
                        </span>

                        <strong>

                          {
                            portfolio.benchmark_name
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Start Date
                        </span>

                        <strong>

                          {
                            portfolio.portfolio_start_date
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Initial Investment
                        </span>

                        <strong>

                          ₹
                          {
                            money(
                              portfolio.initial_investment
                            )
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Available Cash
                        </span>

                        <strong>

                          ₹
                          {
                            money(
                              portfolio.available_balance
                            )
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Rebalancing
                        </span>

                        <strong>

                          {
                            portfolio.rebalancing_frequency
                          }

                        </strong>

                      </div>

                    </div>


                    {/* ACTIONS */}

                    <div className="portfolio-actions">


                      <button

                        className="small-action-button"

                        onClick={
                          () =>
                            navigate(

                              `/portfolios/${portfolio.portfolio_id}`

                            )
                        }

                      >

                        View

                      </button>


                      {
                        portfolio.status === "New"
                        &&
                        (

                          <button

                            className="small-action-button activate-button"

                            onClick={
                              () =>
                                activatePortfolio(
                                  portfolio.portfolio_id
                                )
                            }

                          >

                            Activate

                          </button>

                        )
                      }

                    </div>

                  </div>

                )
              )
            }

          </div>

        )
      }

    </div>

  );

}


export default Portfolios;