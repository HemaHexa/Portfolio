import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
 
import {
  getPortfolios,
  getAssetClasses,
  getThemes,
  getBenchmarks
} from "../api/api";
 
 
function Dashboard() {
 
  const [portfolios, setPortfolios] = useState([]);
 
  const [assetClasses, setAssetClasses] = useState([]);
 
  const [themes, setThemes] = useState([]);
 
  const [benchmarks, setBenchmarks] = useState([]);
 
 
  useEffect(() => {
 
    getPortfolios().then((data) => {
      setPortfolios(data);
    });
 
    getAssetClasses().then((data) => {
      setAssetClasses(data);
    });
 
    getThemes().then((data) => {
      setThemes(data);
    });
 
    getBenchmarks().then((data) => {
      setBenchmarks(data);
    });
 
  }, []);
 
 
  const activePortfolios = portfolios.filter(
    (portfolio) => portfolio.status === "Active"
  );
 
 
  const closedPortfolios = portfolios.filter(
    (portfolio) => portfolio.status === "Closed"
  );
 
 
  return (
    <div>
 
      <h1>Dashboard</h1>
 
      <h2>Portfolio Overview</h2>
 
 
      <div>
 
        <p>
          <b>Total Portfolios:</b>{" "}
          {portfolios.length}
        </p>
 
        <p>
          <b>Active Portfolios:</b>{" "}
          {activePortfolios.length}
        </p>
 
        <p>
          <b>Closed Portfolios:</b>{" "}
          {closedPortfolios.length}
        </p>
 
        <p>
          <b>Asset Classes:</b>{" "}
          {assetClasses.length}
        </p>
 
        <p>
          <b>Investment Themes:</b>{" "}
          {themes.length}
        </p>
 
        <p>
          <b>Benchmarks:</b>{" "}
          {benchmarks.length}
        </p>
 
      </div>
 
 
      <hr />
 
 
      <h2>Quick Actions</h2>
 
      <Link to="/portfolios">
        <button>
          View Portfolios
        </button>
      </Link>
 
      {" "}
 
      <Link to="/portfolios/create">
        <button>
          Create Portfolio
        </button>
      </Link>
 
      {" "}
 
      <Link to="/securities">
        <button>
          Search Securities
        </button>
      </Link>
 
 
      <hr />
 
 
      <h2>Recent Portfolios</h2>
 
 
      <table border="1" cellPadding="10">
 
        <thead>
 
          <tr>
            <th>ID</th>
            <th>Portfolio Name</th>
            <th>Initial Investment</th>
            <th>Available Balance</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {portfolios.map((portfolio) => (
 
            <tr key={portfolio.portfolio_id}>
 
              <td>
                {portfolio.portfolio_id}
              </td>
 
              <td>
                {portfolio.portfolio_name}
              </td>
 
              <td>
                {portfolio.initial_investment}
              </td>
 
              <td>
                {portfolio.available_balance}
              </td>
 
              <td>
                {portfolio.status}
              </td>
 
              <td>
 
                <Link
                  to={`/portfolios/${portfolio.portfolio_id}`}
                >
                  <button>
                    View
                  </button>
                </Link>
 
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
    </div>
  );
}
 
 
export default Dashboard;