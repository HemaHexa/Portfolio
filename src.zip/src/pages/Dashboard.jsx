import {
  useEffect,
  useState
} from "react";

import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend
} from "recharts";

import api from "../api/api";

import "../styles/common.css";


function Dashboard() {

  const [portfolios, setPortfolios] =
    useState([]);

  const [assetClasses, setAssetClasses] =
    useState([]);

  const [alerts, setAlerts] =
    useState([]);

  const [recentTransactions, setRecentTransactions] =
    useState([]);

  const [totalPortfolioValue, setTotalPortfolioValue] =
    useState(0);

  const [selectedPortfolioId, setSelectedPortfolioId] =
    useState("");

  const [allocation, setAllocation] =
    useState(null);

  const [performance, setPerformance] =
    useState(null);

  const [loading, setLoading] =
    useState(true);


  // =====================================================
  // INITIAL LOAD
  // =====================================================

  useEffect(() => {

    loadDashboard();

  }, []);


  // =====================================================
  // SELECTED PORTFOLIO CHART DATA
  // =====================================================

  useEffect(() => {

    if (
      selectedPortfolioId
    ) {

      loadSelectedPortfolioData(
        selectedPortfolioId
      );

    }

  }, [selectedPortfolioId]);


  // =====================================================
  // ARRAY NORMALIZER
  // =====================================================

  function getArray(
    data,
    possibleKey
  ) {

    if (
      Array.isArray(data)
    ) {

      return data;

    }


    if (
      Array.isArray(
        data?.[possibleKey]
      )
    ) {

      return data[possibleKey];

    }


    if (
      Array.isArray(
        data?.data
      )
    ) {

      return data.data;

    }


    return [];

  }


  // =====================================================
  // LOAD DASHBOARD
  // =====================================================

  async function loadDashboard() {

    try {

      setLoading(true);


      const [
        portfolioResponse,
        assetResponse,
        alertResponse
      ] =
        await Promise.all([

          api.get(
            "/api/portfolios"
          ),

          api.get(
            "/api/asset-classes"
          ),

          api.get(
            "/api/alerts"
          )

        ]);


      const portfolioList =
        getArray(
          portfolioResponse.data,
          "portfolios"
        );


      const assetList =
        getArray(
          assetResponse.data,
          "asset_classes"
        );


      const alertList =
        getArray(
          alertResponse.data,
          "alerts"
        );


      setPortfolios(
        portfolioList
      );

      setAssetClasses(
        assetList
      );

      setAlerts(
        alertList
      );


      // =================================================
      // SELECT FIRST ACTIVE PORTFOLIO
      // =================================================

      const activePortfolio =
        portfolioList.find(
          item =>
            item.status === "Active"
        );


      if (
        activePortfolio
      ) {

        setSelectedPortfolioId(
          String(
            activePortfolio.portfolio_id
          )
        );

      }

      else if (
        portfolioList.length > 0
      ) {

        setSelectedPortfolioId(
          String(
            portfolioList[0]
              .portfolio_id
          )
        );

      }


      // =================================================
      // TOTAL CURRENT PORTFOLIO VALUE
      // =================================================

      const activePortfolios =
        portfolioList.filter(
          item =>
            item.status === "Active"
        );


      const performanceRequests =
        activePortfolios.map(

          item =>
            api.get(

              `/api/portfolios/${item.portfolio_id}/performance`

            )

        );


      const performanceResults =
        await Promise.allSettled(
          performanceRequests
        );


      let totalValue = 0;


      performanceResults.forEach(
        result => {

          if (
            result.status ===
            "fulfilled"
          ) {

            totalValue += Number(

              result.value.data
                ?.current_portfolio_value

              || 0

            );

          }

        }
      );


      setTotalPortfolioValue(
        totalValue
      );


      // =================================================
      // RECENT TRANSACTIONS FROM ALL PORTFOLIOS
      // =================================================

      const transactionRequests =
        portfolioList.map(

          portfolio =>
            api.get(

              `/api/portfolios/${portfolio.portfolio_id}/transactions`

            )

        );


      const transactionResults =
        await Promise.allSettled(
          transactionRequests
        );


      let allTransactions = [];


      transactionResults.forEach(
        (result, index) => {

          if (
            result.status ===
            "fulfilled"
          ) {

            const list =
              Array.isArray(
                result.value.data
              )
                ? result.value.data
                : [];


            const portfolio =
              portfolioList[index];


            list.forEach(
              transaction => {

                allTransactions.push({

                  ...transaction,

                  portfolio_name:
                    portfolio
                      .portfolio_name

                });

              }
            );

          }

        }
      );


      allTransactions.sort(
        (a, b) => {

          const dateA =
            new Date(
              a.created_at
              ||
              a.transaction_date
            );


          const dateB =
            new Date(
              b.created_at
              ||
              b.transaction_date
            );


          return (
            dateB - dateA
          );

        }
      );


      setRecentTransactions(

        allTransactions.slice(
          0,
          5
        )

      );

    }

    catch (error) {

      console.log(
        "DASHBOARD ERROR:",
        error.response?.data
        ||
        error
      );

    }

    finally {

      setLoading(false);

    }

  }


  // =====================================================
  // LOAD CHART DATA FOR SELECTED PORTFOLIO
  // =====================================================

  async function loadSelectedPortfolioData(
    portfolioId
  ) {

    try {

      const [
        allocationResult,
        performanceResult
      ] =
        await Promise.allSettled([

          api.get(
            `/api/portfolios/${portfolioId}/allocation`
          ),

          api.get(
            `/api/portfolios/${portfolioId}/performance`
          )

        ]);


      if (
        allocationResult.status
        ===
        "fulfilled"
      ) {

        setAllocation(
          allocationResult.value.data
        );

      }

      else {

        setAllocation(null);

      }


      if (
        performanceResult.status
        ===
        "fulfilled"
      ) {

        setPerformance(
          performanceResult.value.data
        );

      }

      else {

        setPerformance(null);

      }

    }

    catch (error) {

      console.log(error);

    }

  }


  // =====================================================
  // BASIC VALUES
  // =====================================================

  const activePortfolios =
    portfolios.filter(
      item =>
        item.status === "Active"
    );


  const activeAlerts =
    alerts.filter(
      item =>
        item.status !== "RESOLVED"
    );


  // =====================================================
  // PORTFOLIO STATUS CHART
  // =====================================================

  const statusData = [

    {
      name: "Active",
      value:
        portfolios.filter(
          item =>
            item.status === "Active"
        ).length
    },

    {
      name: "New",
      value:
        portfolios.filter(
          item =>
            item.status === "New"
        ).length
    },

    {
      name: "Closed",
      value:
        portfolios.filter(
          item =>
            item.status === "Closed"
        ).length
    }

  ].filter(
    item =>
      item.value > 0
  );


  const PIE_COLORS = [
    "#4f6df5",
    "#22c55e",
    "#f59e0b",
    "#8b5cf6",
    "#ef4444"
  ];


  // =====================================================
  // ASSET ALLOCATION PIE
  // =====================================================

  const allocationPieData =
    allocation?.allocations
      ?.map(
        item => ({

          name:
            item.asset_class_name,

          value:
            Number(
              item.current_percentage
              || 0
            )

        })
      )
      .filter(
        item =>
          item.value > 0
      )
    ||
    [];


  // =====================================================
  // TARGET VS CURRENT
  // =====================================================

  const targetCurrentData =
    allocation?.allocations
      ?.map(
        item => ({

          name:
            item.asset_class_name,

          Target:
            Number(
              item.target_percentage
              || 0
            ),

          Current:
            Number(
              item.current_percentage
              || 0
            )

        })
      )
    ||
    [];


  // =====================================================
  // RETURN COMPARISON
  // =====================================================

  const returnData =
    performance
      ? [

          {
            name:
              "Portfolio",

            Return:
              Number(
                performance
                  .portfolio_return_percentage
                || 0
              )
          },

          {
            name:
              "NIFTY 50",

            Return:
              Number(
                performance
                  .benchmark_return_percentage
                || 0
              )
          }

        ]

      : [];


  // =====================================================
  // MONEY
  // =====================================================

  function money(value) {

    return Number(
      value || 0
    ).toLocaleString(
      "en-IN",
      {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }
    );

  }


  // =====================================================
  // UI
  // =====================================================

  return (

    <div>


      {/* ===============================================
          HEADER
      =============================================== */}

      <div className="dashboard-heading-row">

        <div className="page-heading">

          <h1>
            Portfolio Dashboard
          </h1>

          <p>
            Monitor investments,
            allocation, alerts and
            benchmark performance.
          </p>

        </div>


        {
          portfolios.length > 0
          &&
          (

            <div className="dashboard-portfolio-selector">

              <label>
                Chart Portfolio
              </label>


              <select

                className="form-control"

                value={
                  selectedPortfolioId
                }

                onChange={
                  e =>
                    setSelectedPortfolioId(
                      e.target.value
                    )
                }

              >

                {
                  portfolios.map(
                    portfolio => (

                      <option

                        key={
                          portfolio.portfolio_id
                        }

                        value={
                          portfolio.portfolio_id
                        }

                      >

                        {
                          portfolio.portfolio_name
                        }

                      </option>

                    )
                  )
                }

              </select>

            </div>

          )
        }

      </div>


      {
        loading
        &&
        (

          <p className="small-muted">

            Loading dashboard...

          </p>

        )
      }


      {/* ===============================================
          SUMMARY CARDS
      =============================================== */}

      <div className="stats-grid">


        <div className="glass-card">

          <div className="card-icon icon-blue">
            ▣
          </div>

          <div className="card-label">
            Total Portfolios
          </div>

          <div className="card-value">
            {
              portfolios.length
            }
          </div>

          <div className="card-description">
            Investment portfolios created.
          </div>

        </div>


        <div className="glass-card">

          <div className="card-icon icon-green">
            ✓
          </div>

          <div className="card-label">
            Active Portfolios
          </div>

          <div className="card-value">
            {
              activePortfolios.length
            }
          </div>

          <div className="card-description">
            Portfolios currently active.
          </div>

        </div>


        <div className="glass-card">

          <div className="card-icon icon-purple">
            ₹
          </div>

          <div className="card-label">
            Portfolio Value
          </div>

          <div className="card-value">

            ₹
            {
              money(
                totalPortfolioValue
              )
            }

          </div>

          <div className="card-description">
            Combined active portfolio value.
          </div>

        </div>


        <div className="glass-card">

          <div className="card-icon icon-orange">
            ◫
          </div>

          <div className="card-label">
            Asset Classes
          </div>

          <div className="card-value">
            {
              assetClasses.length
            }
          </div>

          <div className="card-description">
            Configured asset classifications.
          </div>

        </div>


        <div className="glass-card">

          <div className="card-icon icon-red">
            !
          </div>

          <div className="card-label">
            Active Alerts
          </div>

          <div className="card-value">
            {
              activeAlerts.length
            }
          </div>

          <div className="card-description">
            Deviations requiring attention.
          </div>

        </div>


        <div className="glass-card">

          <div className="card-icon icon-purple">
            ↗
          </div>

          <div className="card-label">
            Benchmark
          </div>

          <div className="card-value dashboard-benchmark-value">
            NIFTY 50
          </div>

          <div className="card-description">
            Portfolio comparison benchmark.
          </div>

        </div>

      </div>


      {/* ===============================================
          FIRST CHART ROW
      =============================================== */}

      <div className="dashboard-chart-grid">


        {/* PORTFOLIO STATUS */}

        <div className="dashboard-chart-card">

          <div className="dashboard-chart-title">

            <h3>
              Portfolio Status
            </h3>

            <p>
              Current portfolio lifecycle.
            </p>

          </div>


          {
            statusData.length > 0
            ?

            (

              <div className="chart-container">

                <ResponsiveContainer
                  width="100%"
                  height="100%"
                >

                  <PieChart>

                    <Pie

                      data={
                        statusData
                      }

                      dataKey="value"

                      nameKey="name"

                      cx="50%"

                      cy="50%"

                      innerRadius={55}

                      outerRadius={85}

                      paddingAngle={4}

                    >

                      {
                        statusData.map(
                          (entry, index) => (

                            <Cell

                              key={
                                entry.name
                              }

                              fill={
                                PIE_COLORS[
                                  index
                                  %
                                  PIE_COLORS.length
                                ]
                              }

                            />

                          )
                        )
                      }

                    </Pie>


                    <Tooltip />

                    <Legend />

                  </PieChart>

                </ResponsiveContainer>

              </div>

            )

            :

            (

              <div className="chart-empty">

                No portfolio data

              </div>

            )
          }

        </div>


        {/* ASSET ALLOCATION */}

        <div className="dashboard-chart-card">

          <div className="dashboard-chart-title">

            <h3>
              Current Asset Allocation
            </h3>

            <p>
              Allocation of selected portfolio.
            </p>

          </div>


          {
            allocationPieData.length > 0
            ?

            (

              <div className="chart-container">

                <ResponsiveContainer
                  width="100%"
                  height="100%"
                >

                  <PieChart>

                    <Pie

                      data={
                        allocationPieData
                      }

                      dataKey="value"

                      nameKey="name"

                      cx="50%"

                      cy="50%"

                      outerRadius={90}

                      paddingAngle={3}

                    >

                      {
                        allocationPieData.map(
                          (entry, index) => (

                            <Cell

                              key={
                                entry.name
                              }

                              fill={
                                PIE_COLORS[
                                  index
                                  %
                                  PIE_COLORS.length
                                ]
                              }

                            />

                          )
                        )
                      }

                    </Pie>


                    <Tooltip
                      formatter={
                        value =>
                          `${Number(value).toFixed(2)}%`
                      }
                    />

                    <Legend />

                  </PieChart>

                </ResponsiveContainer>

              </div>

            )

            :

            (

              <div className="chart-empty">

                No allocation data

              </div>

            )
          }

        </div>

      </div>


      {/* ===============================================
          TARGET VS CURRENT
      =============================================== */}

      <div className="dashboard-chart-card dashboard-wide-chart">

        <div className="dashboard-chart-title">

          <h3>
            Target vs Current Allocation
          </h3>

          <p>
            Compare theme targets with
            current portfolio allocation.
          </p>

        </div>


        {
          targetCurrentData.length > 0
          ?

          (

            <div className="wide-chart-container">

              <ResponsiveContainer
                width="100%"
                height="100%"
              >

                <BarChart
                  data={
                    targetCurrentData
                  }
                >

                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(255,255,255,0.06)"
                  />


                  <XAxis

                    dataKey="name"

                    tick={{
                      fill: "#9ca3af",
                      fontSize: 10
                    }}

                  />


                  <YAxis

                    tick={{
                      fill: "#9ca3af",
                      fontSize: 10
                    }}

                    unit="%"

                  />


                  <Tooltip />

                  <Legend />


                  <Bar

                    dataKey="Target"

                    fill="#7c5cf5"

                    radius={[
                      5,
                      5,
                      0,
                      0
                    ]}

                  />


                  <Bar

                    dataKey="Current"

                    fill="#4f6df5"

                    radius={[
                      5,
                      5,
                      0,
                      0
                    ]}

                  />

                </BarChart>

              </ResponsiveContainer>

            </div>

          )

          :

          (

            <div className="chart-empty">

              No allocation data

            </div>

          )
        }

      </div>


      {/* ===============================================
          RETURN COMPARISON
      =============================================== */}

      <div className="dashboard-chart-card dashboard-wide-chart">

        <div className="dashboard-chart-title">

          <h3>
            Portfolio Return vs NIFTY 50
          </h3>

          <p>
            Point-in-time return comparison
            from the portfolio start date.
          </p>

        </div>


        {
          returnData.length > 0
          ?

          (

            <div className="return-chart-container">

              <ResponsiveContainer
                width="100%"
                height="100%"
              >

                <BarChart
                  data={
                    returnData
                  }
                >

                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(255,255,255,0.06)"
                  />


                  <XAxis

                    dataKey="name"

                    tick={{
                      fill: "#9ca3af",
                      fontSize: 11
                    }}

                  />


                  <YAxis

                    tick={{
                      fill: "#9ca3af",
                      fontSize: 10
                    }}

                    unit="%"

                  />


                  <Tooltip
                    formatter={
                      value =>
                        `${Number(value).toFixed(2)}%`
                    }
                  />


                  <Bar

                    dataKey="Return"

                    fill="#4f6df5"

                    radius={[
                      7,
                      7,
                      0,
                      0
                    ]}

                  />

                </BarChart>

              </ResponsiveContainer>

            </div>

          )

          :

          (

            <div className="chart-empty">

              Performance becomes available
              after portfolio activation.

            </div>

          )
        }

      </div>


      {/* ===============================================
          RECENT ACTIVITY
      =============================================== */}

      <div className="dashboard-activity-grid">


        {/* RECENT TRANSACTIONS */}

        <div className="content-card">

          <div className="dashboard-chart-title">

            <h3>
              Recent Transactions
            </h3>

            <p>
              Latest BUY and SELL activity.
            </p>

          </div>


          {
            recentTransactions.length === 0
            ?

            (

              <div className="chart-empty small-empty">

                No transactions

              </div>

            )

            :

            recentTransactions.map(
              item => (

                <div

                  className="recent-activity-row"

                  key={
                    `${item.portfolio_id}-${item.transaction_id}`
                  }

                >

                  <div>

                    <strong>

                      {
                        item.symbol
                      }

                    </strong>

                    <span>

                      {
                        item.portfolio_name
                      }

                      {" • "}

                      {
                        item.transaction_date
                      }

                    </span>

                  </div>


                  <div className="recent-activity-right">

                    <span

                      className={
                        item.transaction_type
                        === "BUY"

                          ? "transaction-buy"

                          : "transaction-sell"
                      }

                    >

                      {
                        item.transaction_type
                      }

                    </span>


                    <strong>

                      ₹
                      {
                        money(
                          item.transaction_amount
                        )
                      }

                    </strong>

                  </div>

                </div>

              )
            )
          }

        </div>


        {/* RECENT ALERTS */}

        <div className="content-card">

          <div className="dashboard-chart-title">

            <h3>
              Recent Alerts
            </h3>

            <p>
              Latest allocation deviations.
            </p>

          </div>


          {
            alerts.length === 0
            ?

            (

              <div className="chart-empty small-empty">

                No alerts

              </div>

            )

            :

            alerts
              .slice(0, 5)
              .map(
                alert => (

                  <div

                    className="recent-activity-row"

                    key={
                      alert.alert_id
                    }

                  >

                    <div>

                      <strong>

                        {
                          alert.asset_class_name
                        }

                      </strong>

                      <span>

                        {
                          alert.portfolio_name
                          ||
                          `Portfolio ${alert.portfolio_id}`
                        }

                      </span>

                    </div>


                    <div className="recent-activity-right">

                      <span

                        className={
                          alert.recommendation_action
                          === "INCREASE"

                            ? "recommend-increase"

                            : alert.recommendation_action
                            === "REDUCE"

                              ? "recommend-reduce"

                              : "recommend-hold"
                        }

                      >

                        {
                          alert.recommendation_action
                        }

                      </span>


                      <strong>

                        {
                          Number(
                            alert.deviation_percentage
                            || 0
                          ).toFixed(2)
                        }
                        %

                      </strong>

                    </div>

                  </div>

                )
              )
          }

        </div>

      </div>

    </div>

  );

}


export default Dashboard;