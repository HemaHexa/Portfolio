import {
  useEffect,
  useState
} from "react";

import {
  useNavigate
} from "react-router-dom";

import api from "../api/api";

import "../styles/common.css";


function CreatePortfolio() {

  const navigate =
    useNavigate();


  const [themes, setThemes] =
    useState([]);


  const [message, setMessage] =
    useState("");


  const [saving, setSaving] =
    useState(false);


  const [form, setForm] =
    useState({

      portfolio_name: "",

      portfolio_manager:
        "Fund Manager",

      portfolio_type:
        "Amount",

      theme_id: "",

      initial_investment: "",

      portfolio_start_date: "",

      rebalancing_frequency:
        "Monthly"

    });


  // =====================================================
  // LOAD ACTIVE THEMES
  // =====================================================

  useEffect(() => {

    loadThemes();

  }, []);


  async function loadThemes() {

    try {

      const response =
        await api.get(
          "/api/themes"
        );


      let list = [];


      if (
        Array.isArray(
          response.data
        )
      ) {

        list =
          response.data;

      }

      else if (
        Array.isArray(
          response.data?.themes
        )
      ) {

        list =
          response.data.themes;

      }

      else if (
        Array.isArray(
          response.data?.data
        )
      ) {

        list =
          response.data.data;

      }


      const activeThemes =
        list.filter(

          item =>
            item.status === "ACTIVE"

        );


      setThemes(
        activeThemes
      );

    }

    catch (error) {

      console.log(error);


      setMessage(
        "Unable to load investment themes"
      );

    }

  }


  // =====================================================
  // CHANGE
  // =====================================================

  function handleChange(e) {

    const {
      name,
      value
    } = e.target;


    setForm({

      ...form,

      [name]:
        value

    });

  }


  // =====================================================
  // SUBMIT
  // =====================================================

  async function createPortfolio(e) {

    e.preventDefault();


    if (
      !form.portfolio_name.trim()
    ) {

      setMessage(
        "Portfolio name is required"
      );

      return;

    }


    if (
      !form.theme_id
    ) {

      setMessage(
        "Please select an investment theme"
      );

      return;

    }


    if (
      !form.initial_investment
      ||
      Number(
        form.initial_investment
      ) <= 0
    ) {

      setMessage(
        "Initial investment must be greater than 0"
      );

      return;

    }


    if (
      !form.portfolio_start_date
    ) {

      setMessage(
        "Portfolio start date is required"
      );

      return;

    }


    try {

      setSaving(true);

      setMessage("");


      const payload = {

        portfolio_name:
          form.portfolio_name,

        portfolio_manager:
          form.portfolio_manager,

        portfolio_type:
          form.portfolio_type,

        theme_id:
          Number(
            form.theme_id
          ),

        initial_investment:
          Number(
            form.initial_investment
          ),

        portfolio_start_date:
          form.portfolio_start_date,

        rebalancing_frequency:
          form.rebalancing_frequency

      };


      console.log(
        "CREATE PORTFOLIO:",
        payload
      );


      const response =
        await api.post(

          "/api/portfolios",

          payload

        );


      console.log(
        "CREATE RESPONSE:",
        response.data
      );


      navigate(
        "/portfolios"
      );

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to create portfolio"

      );

    }

    finally {

      setSaving(false);

    }

  }


  // =====================================================
  // TODAY FOR MAX DATE
  // =====================================================

  const today =
    new Date()
      .toISOString()
      .split("T")[0];


  return (

    <div>


      <div className="page-heading">

        <h1>
          Create Portfolio
        </h1>

        <p>
          Configure a new investment
          portfolio and assign an
          investment theme.
        </p>

      </div>


      {
        message
        &&
        (

          <div className="asset-message">

            {message}

          </div>

        )
      }


      <div className="create-portfolio-card">

        <form
          onSubmit={
            createPortfolio
          }
        >


          <div className="create-form-grid">


            {/* NAME */}

            <div className="form-group">

              <label>
                Portfolio Name *
              </label>


              <input

                className="form-control"

                name="portfolio_name"

                value={
                  form.portfolio_name
                }

                onChange={
                  handleChange
                }

                placeholder=
                  "Example: Growth Portfolio"

              />

            </div>


            {/* MANAGER */}

            <div className="form-group">

              <label>
                Portfolio Manager *
              </label>


              <input

                className="form-control"

                name="portfolio_manager"

                value={
                  form.portfolio_manager
                }

                onChange={
                  handleChange
                }

              />

            </div>


            {/* TYPE */}

            <div className="form-group">

              <label>
                Portfolio Type *
              </label>


              <select

                className="form-control"

                name="portfolio_type"

                value={
                  form.portfolio_type
                }

                onChange={
                  handleChange
                }

              >

                <option value="Amount">
                  Amount
                </option>

                <option value="Weightage">
                  Weightage
                </option>

              </select>

            </div>


            {/* THEME */}

            <div className="form-group">

              <label>
                Investment Theme *
              </label>


              <select

                className="form-control"

                name="theme_id"

                value={
                  form.theme_id
                }

                onChange={
                  handleChange
                }

              >

                <option value="">
                  Select Theme
                </option>


                {
                  themes.map(
                    theme => (

                      <option

                        key={
                          theme.theme_id
                        }

                        value={
                          theme.theme_id
                        }

                      >

                        {
                          theme.theme_name
                        }

                      </option>

                    )
                  )
                }

              </select>

            </div>


            {/* INVESTMENT */}

            <div className="form-group">

              <label>
                Initial Investment (₹) *
              </label>


              <input

                type="number"

                min="1"

                className="form-control"

                name="initial_investment"

                value={
                  form.initial_investment
                }

                onChange={
                  handleChange
                }

                placeholder="1000000"

              />

            </div>


            {/* START DATE */}

            <div className="form-group">

              <label>
                Portfolio Start Date *
              </label>


              <input

                type="date"

                max={today}

                className="form-control"

                name="portfolio_start_date"

                value={
                  form.portfolio_start_date
                }

                onChange={
                  handleChange
                }

              />

            </div>


            {/* REBALANCING */}

            <div className="form-group">

              <label>
                Rebalancing Frequency *
              </label>


              <select

                className="form-control"

                name="rebalancing_frequency"

                value={
                  form.rebalancing_frequency
                }

                onChange={
                  handleChange
                }

              >

                <option value="Daily">
                  Daily
                </option>

                <option value="Weekly">
                  Weekly
                </option>

                <option value="Monthly">
                  Monthly
                </option>

                <option value="Quarterly">
                  Quarterly
                </option>

                <option value="Half-Yearly">
                  Half-Yearly
                </option>

                <option value="Yearly">
                  Yearly
                </option>

              </select>

            </div>


            {/* CURRENCY */}

            <div className="form-group">

              <label>
                Currency
              </label>


              <input

                className="form-control"

                value="INR"

                disabled

              />

            </div>


            {/* EXCHANGE */}

            <div className="form-group">

              <label>
                Exchange
              </label>


              <input

                className="form-control"

                value="NSE"

                disabled

              />

            </div>


            {/* BENCHMARK */}

            <div className="form-group">

              <label>
                Benchmark
              </label>


              <input

                className="form-control"

                value="NIFTY 50"

                disabled

              />

            </div>

          </div>


          {/* INFO */}

          <div className="create-info-box">

            <strong>
              Portfolio lifecycle
            </strong>

            <p>

              The portfolio will first be
              created with status
              {" "}
              <b>New</b>.
              Activate it from the portfolio
              list before buying securities.

            </p>

          </div>


          <div className="form-actions">


            <button

              type="button"

              className="secondary-button"

              onClick={
                () =>
                  navigate(
                    "/portfolios"
                  )
              }

            >

              Cancel

            </button>


            <button

              type="submit"

              className="primary-button"

              disabled={
                saving
              }

            >

              {
                saving
                  ? "Creating..."
                  : "Create Portfolio"
              }

            </button>

          </div>

        </form>

      </div>

    </div>

  );

}


export default CreatePortfolio;