import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
 
import {
  getThemes,
  getBenchmarks,
  createPortfolio
} from "../api/api";
 
 
function CreatePortfolio() {
 
  const navigate = useNavigate();
 
 
  const [themes, setThemes] = useState([]);
 
  const [benchmarks, setBenchmarks] = useState([]);
 
 
  const [portfolioName, setPortfolioName] = useState("");
 
  const [portfolioType, setPortfolioType] = useState("Amount");
 
  const [currency, setCurrency] = useState("INR");
 
  const [exchange, setExchange] = useState("NSE");
 
  const [themeId, setThemeId] = useState("");
 
  const [benchmarkId, setBenchmarkId] = useState("");
 
  const [investment, setInvestment] = useState("");
 
  const [frequency, setFrequency] = useState("Monthly");
 
  const [message, setMessage] = useState("");
 
 
  useEffect(() => {
 
    getThemes().then((data) => {
      setThemes(data);
    });
 
 
    getBenchmarks().then((data) => {
      setBenchmarks(data);
    });
 
  }, []);
 
 
  async function handleSubmit(event) {
 
    event.preventDefault();
 
 
    const portfolioData = {
 
      portfolio_name: portfolioName,
 
      portfolio_type: portfolioType,
 
      currency: currency,
 
      exchange: exchange,
 
      theme_id: Number(themeId),
 
      benchmark_id: Number(benchmarkId),
 
      initial_investment: Number(investment),
 
      rebalancing_frequency: frequency
 
    };
 
 
    try {
 
      const result =
        await createPortfolio(portfolioData);
 
      console.log(result);
 
      setMessage(
        "Portfolio created successfully"
      );
 
 
      setTimeout(() => {
 
        navigate("/portfolios");
 
      }, 1000);
 
 
    } catch (error) {
 
      setMessage(error.message);
 
    }
 
  }
 
 
  return (
    <div>
 
      <h1>Create Portfolio</h1>
 
 
      <form onSubmit={handleSubmit}>
 
 
        <label>
          Portfolio Name
        </label>
 
        <br />
 
        <input
          type="text"
          value={portfolioName}
          onChange={(event) =>
            setPortfolioName(event.target.value)
          }
          required
        />
 
 
        <br />
        <br />
 
 
        <label>
          Portfolio Type
        </label>
 
        <br />
 
        <select
          value={portfolioType}
          onChange={(event) =>
            setPortfolioType(event.target.value)
          }
        >
 
          <option value="Amount">
            Amount
          </option>
 
          <option value="Weightage">
            Weightage
          </option>
 
        </select>
 
 
        <br />
        <br />
 
 
        <label>
          Currency
        </label>
 
        <br />
 
        <select
          value={currency}
          onChange={(event) =>
            setCurrency(event.target.value)
          }
        >
 
          <option value="INR">
            INR
          </option>
 
        </select>
 
 
        <br />
        <br />
 
 
        <label>
          Exchange
        </label>
 
        <br />
 
        <select
          value={exchange}
          onChange={(event) =>
            setExchange(event.target.value)
          }
        >
 
          <option value="NSE">
            NSE
          </option>
 
          <option value="BSE">
            BSE
          </option>
 
        </select>
 
 
        <br />
        <br />
 
 
        <label>
          Investment Theme
        </label>
 
        <br />
 
        <select
          value={themeId}
          onChange={(event) =>
            setThemeId(event.target.value)
          }
          required
        >
 
          <option value="">
            Select Theme
          </option>
 
 
          {themes.map((theme) => (
 
            <option
              key={theme.theme_id}
              value={theme.theme_id}
            >
 
              {theme.theme_name}
 
            </option>
 
          ))}
 
        </select>
 
 
        <br />
        <br />
 
 
        <label>
          Benchmark
        </label>
 
        <br />
 
        <select
          value={benchmarkId}
          onChange={(event) =>
            setBenchmarkId(event.target.value)
          }
          required
        >
 
          <option value="">
            Select Benchmark
          </option>
 
 
          {benchmarks.map((benchmark) => (
 
            <option
              key={benchmark.benchmark_id}
              value={benchmark.benchmark_id}
            >
 
              {benchmark.benchmark_name}
 
            </option>
 
          ))}
 
        </select>
 
 
        <br />
        <br />
 
 
        <label>
          Initial Investment
        </label>
 
        <br />
 
        <input
          type="number"
          value={investment}
          onChange={(event) =>
            setInvestment(event.target.value)
          }
          min="1"
          required
        />
 
 
        <br />
        <br />
 
 
        <label>
          Rebalancing Frequency
        </label>
 
        <br />
 
        <select
          value={frequency}
          onChange={(event) =>
            setFrequency(event.target.value)
          }
        >
 
          <option value="Daily">
            Daily
          </option>
 
          <option value="Monthly">
            Monthly
          </option>
 
          <option value="Quarterly">
            Quarterly
          </option>
 
          <option value="Half-Yearly">
            Half-Yearly
          </option>
 
          <option value="Yearly">
            Yearly
          </option>
 
        </select>
 
 
        <br />
        <br />
 
 
        <button type="submit">
          Create Portfolio
        </button>
 
 
        <button
          type="button"
          onClick={() =>
            navigate("/portfolios")
          }
        >
          Cancel
        </button>
 
 
      </form>
 
 
      {message && (
        <p>{message}</p>
      )}
 
 
    </div>
  );
}
 
 
export default CreatePortfolio;