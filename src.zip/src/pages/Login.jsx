import {
  useState
} from "react";

import {
  useNavigate
} from "react-router-dom";

import "../styles/common.css";


function Login() {

  const navigate = useNavigate();


  const [username, setUsername] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [error, setError] =
    useState("");


  function login(e) {

    e.preventDefault();


    if (
      username === "manager"
      &&
      password === "manager123"
    ) {

      localStorage.setItem(

        "portfolio_user",

        JSON.stringify({

          username:
            "manager",

          name:
            "Fund Manager"

        })

      );


      navigate(
        "/dashboard"
      );

    }

    else {

      setError(
        "Invalid username or password"
      );

    }

  }


  return (

    <div
      className="app-background"
      style={{

        minHeight: "100vh",

        display: "flex",

        justifyContent: "center",

        alignItems: "center"

      }}
    >

      <div
        className="form-card"
        style={{

          width: "420px",

          textAlign: "center"

        }}
      >

        <div
          className="card-icon icon-blue"
          style={{

            margin:
              "0 auto 20px"

          }}
        >

          ◆

        </div>


        <h1
          style={{
            marginBottom: "8px"
          }}
        >

          Welcome Back

        </h1>


        <p
          style={{

            color: "#9ca3af",

            fontSize: "13px",

            marginBottom: "30px"

          }}
        >

          Sign in to Portfolio Management System

        </p>


        <form onSubmit={login}>


          <div
            className="form-group"
            style={{
              textAlign: "left"
            }}
          >

            <label>
              Username
            </label>

            <input

              className="form-control"

              value={username}

              onChange={
                e =>
                  setUsername(
                    e.target.value
                  )
              }

              placeholder="Enter username"

            />

          </div>


          <div
            className="form-group"
            style={{
              textAlign: "left"
            }}
          >

            <label>
              Password
            </label>

            <input

              className="form-control"

              type="password"

              value={password}

              onChange={
                e =>
                  setPassword(
                    e.target.value
                  )
              }

              placeholder="Enter password"

            />

          </div>


          {
            error &&
            (

              <p
                style={{

                  color: "#ef4444",

                  fontSize: "13px",

                  marginBottom: "16px"

                }}
              >

                {error}

              </p>

            )
          }


          <button

            className="primary-button"

            style={{
              width: "100%"
            }}

          >

            Sign In

          </button>

        </form>


        <p
          style={{

            marginTop: "20px",

            color: "#71717a",

            fontSize: "11px"

          }}
        >

          Demo: manager / manager123

        </p>

      </div>

    </div>

  );

}


export default Login;