function PlaceholderPage({
  title,
  description
}) {

  return (

    <div>

      <div className="page-heading">

        <h1>
          {title}
        </h1>

        <p>
          {description}
        </p>

      </div>


      <div className="content-card">

        <h3>
          {title}
        </h3>

        <p className="content-card-subtitle">

          This page will be connected to
          the backend in the next stage.

        </p>

      </div>

    </div>

  );

}


export default PlaceholderPage;