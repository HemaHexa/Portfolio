import { useEffect, useState } from "react";
import {
  getBenchmarks,
  getBenchmarkHistory
} from "../api/api";
 
 
function Benchmarks() {
 
  const [benchmarks, setBenchmarks] = useState([]);
 
  const [history, setHistory] = useState([]);
 
  const [selectedBenchmark, setSelectedBenchmark] = useState("");
 
 
  useEffect(() => {
 
    getBenchmarks().then((data) => {
      setBenchmarks(data);
    });
 
  }, []);
 
 
  function viewHistory(benchmarkId) {
 
    setSelectedBenchmark(benchmarkId);
 
    getBenchmarkHistory(benchmarkId).then((data) => {
      console.log("Benchmark History :", data);
      setHistory(data.history || []);
    });
 
  }
 
 
  return (
    <div>
 
      <h1>Benchmarks</h1>
 
      <h2>Benchmark Master</h2>
 
      <table border="1" cellPadding="10">
 
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Code</th>
            <th>Exchange</th>
            <th>Currency</th>
            <th>Country</th>
            <th>Status</th>
            <th>History</th>
          </tr>
        </thead>
 
        <tbody>
 
          {benchmarks.map((benchmark) => (
 
            <tr key={benchmark.benchmark_id}>
 
              <td>{benchmark.benchmark_id}</td>
 
              <td>{benchmark.benchmark_name}</td>
 
              <td>{benchmark.benchmark_code}</td>
 
              <td>{benchmark.exchange}</td>
 
              <td>{benchmark.currency}</td>
 
              <td>{benchmark.country}</td>
 
              <td>{benchmark.status}</td>
 
              <td>
 
                <button
                  onClick={() =>
                    viewHistory(benchmark.benchmark_id)
                  }
                >
                  View History
                </button>
 
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      {selectedBenchmark && (
 
        <div>
 
          <h2>Benchmark History</h2>
 
          <table border="1" cellPadding="10">
 
            <thead>
              <tr>
                <th>Date</th>
                <th>Close Value</th>
                <th>Source</th>
              </tr>
            </thead>
 
            <tbody>
 
              {history.map((item, index) => (
 
                <tr key={index}>
 
                  <td>
                    {item.price_date}
                  </td>
 
                  <td>
                    {item.close_value}
                  </td>
 
                  <td>
                    {item.source}
                  </td>
 
                </tr>
 
              ))}
 
            </tbody>
 
          </table>
 
        </div>
 
      )}
 
    </div>
  );
}
 
 
export default Benchmarks;