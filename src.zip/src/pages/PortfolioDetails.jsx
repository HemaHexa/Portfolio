import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getPortfolio, activatePortfolio, closePortfolio, searchSecurities, getHoldings, buySecurity, sellSecurity, getTransactions, getPortfolioSummary, getAllocation, getAllocationAssessment, generateAlerts, getAlerts, getRebalancing, getPerformance
} from "../api/api";
 
 
function PortfolioDetails() {
 
  const { portfolioId } = useParams();
 
  const [portfolio, setPortfolio] = useState(null);
 
  const [holdings, setHoldings] = useState([]);
 
  const [transactions, setTransactions] = useState([]);
 
  const [summary, setSummary] = useState(null);
 
  const [allocation, setAllocation] = useState([]);
 
  const [assessment, setAssessment] = useState([]);
 
  const [alerts, setAlerts] = useState([]);
 
  const [rebalancing, setRebalancing] = useState([]);
 
  const [performance, setPerformance] = useState(null);
 
 
  // Security search
 
  const [search, setSearch] = useState("");
 
  const [securities, setSecurities] = useState([]);
 
 
  // BUY
 
  const [buySecurityId, setBuySecurityId] = useState("");
 
  const [buyQuantity, setBuyQuantity] = useState("");
 
 
  // SELL
 
  const [sellSecurityId, setSellSecurityId] = useState("");
 
  const [sellQuantity, setSellQuantity] = useState("");
 
 
  const [message, setMessage] = useState("");
 
 
  // =========================
  // LOAD PORTFOLIO
  // =========================
 
  function loadPortfolio() {
 
    getPortfolio(portfolioId).then((data) => {
      setPortfolio(data);
    });
 
  }
 
 
  function loadHoldings() {
 
    getHoldings(portfolioId).then((data) => {
      setHoldings(data.holdings);
    });
 
  }
 
 
  function loadTransactions() {
 
    getTransactions(portfolioId).then((data) => {
      setTransactions(data.transactions);
    });
 
  }
 
 
  function loadSummary() {
 
    getPortfolioSummary(portfolioId).then((data) => {
      setSummary(data);
    });
 
  }
 
 
  function loadAllocation() {
 
    getAllocation(portfolioId).then((data) => {
      setAllocation(data.allocations || []);
    });
 
  }
 
 
  function loadAssessment() {
 
    getAllocationAssessment(portfolioId).then((data) => {
      setAssessment(data.assessment || []);
    });
 
  }
 
  function loadAlerts() {
 
    getAlerts(portfolioId).then((data) => {
      console.log("ALERT API RESPONSE: ", data)
      setAlerts(data.alerts || []);
    });
 
  }
 
 
  function loadRebalancing() {
 
    getRebalancing(portfolioId).then((data) => {
      console.log("Rebalancing API Reponse: ", data);
      setRebalancing(data.recommendations || []);
    });
 
  }
 
 
  function loadPerformance() {
 
    getPerformance(portfolioId).then((data) => {
      setPerformance(data);
    });
 
  }
 
 
  // =========================
  // LOAD PAGE
  // =========================
 
  useEffect(() => {
 
    loadPortfolio();
 
    loadHoldings();
 
    loadTransactions();
 
    loadSummary();
 
    loadAllocation();
 
    loadAssessment();
 
    loadAlerts();
 
    loadRebalancing();
 
    loadPerformance();
 
  }, [portfolioId]);
 
 
  // =========================
  // ACTIVATE
  // =========================
 
  async function handleActivate() {
 
    try {
 
      const data =
        await activatePortfolio(portfolioId);
 
      setMessage(
        data.message || "Portfolio activated successfully"
      );
 
      loadPortfolio();
 
    } catch (error) {
 
      setMessage(error.message);
 
    }
 
  }
 
 
  // =========================
  // CLOSE
  // =========================
 
  async function handleClose() {
 
    try {
 
      const data =
        await closePortfolio(portfolioId);
 
      setMessage(
        data.message || "Portfolio closed successfully"
      );
 
      loadPortfolio();
 
    } catch (error) {
 
      setMessage(error.message);
 
    }
 
  }
 
 
  // =========================
  // SEARCH SECURITY
  // =========================
 
  async function handleSearch() {
 
    const data =
      await searchSecurities(search);
 
    setSecurities(data);
 
  }
 
 
  // =========================
  // BUY SECURITY
  // =========================
 
  async function handleBuy(event) {
 
    event.preventDefault();
 
    try {
 
      const data = await buySecurity(
        portfolioId,
        buySecurityId,
        buyQuantity
      );
 
      setMessage(
        data.message || "Security purchased successfully"
      );
 
      setBuySecurityId("");
      setBuyQuantity("");
 
      loadPortfolio();
      loadHoldings();
      loadTransactions();
      loadSummary();
      loadAllocation();
      loadAssessment();
      loadRebalancing();
      loadPerformance();
 
    } catch (error) {
 
      setMessage(error.message);
 
    }
 
  }
 
 
  // =========================
  // SELL SECURITY
  // =========================
 
  async function handleSell(event) {
 
    event.preventDefault();
 
    try {
 
      const data = await sellSecurity(
        portfolioId,
        sellSecurityId,
        sellQuantity
      );
 
      setMessage(
        data.message || "Security sold successfully"
      );
 
      setSellSecurityId("");
      setSellQuantity("");
 
      loadPortfolio();
      loadHoldings();
      loadTransactions();
      loadSummary();
      loadAllocation();
      loadAssessment();
      loadRebalancing();
      loadPerformance();
 
    } catch (error) {
 
      setMessage(error.message);
 
    }
 
  }
 
 
  // =========================
  // GENERATE ALERTS
  // =========================
 
  async function handleGenerateAlerts() {
 
    //console.log("GENERATE BUTTON CLICKED");

    try {
 
      const data =
        await generateAlerts(portfolioId);
 
      setMessage(
        data.message || "Alerts generated successfully"
      );
 
      loadAlerts();
 
    } catch (error) {
 
      setMessage(error.message);
 
    }
 
  }
 
 
  // =========================
  // LOADING
  // =========================
 
  if (!portfolio) {
 
    return (
      <p>Loading portfolio...</p>
    );
 
  }
 
 
  return (
    <div>
 
      <h1>
        Portfolio Details
      </h1>
 
 
      {message && (
        <p>
          <b>{message}</b>
        </p>
      )}
 
 
      {/* =====================
          PORTFOLIO INFORMATION
      ====================== */}
 
      <h2>
        Portfolio Information
      </h2>
 
      <p>
        <b>ID:</b>{" "}
        {portfolio.portfolio_id}
      </p>
 
      <p>
        <b>Name:</b>{" "}
        {portfolio.portfolio_name}
      </p>
 
      <p>
        <b>Type:</b>{" "}
        {portfolio.portfolio_type}
      </p>
 
      <p>
        <b>Currency:</b>{" "}
        {portfolio.currency}
      </p>
 
      <p>
        <b>Exchange:</b>{" "}
        {portfolio.exchange}
      </p>
 
      <p>
        <b>Initial Investment:</b>{" "}
        {portfolio.initial_investment}
      </p>
 
      <p>
        <b>Available Balance:</b>{" "}
        {portfolio.available_balance}
      </p>
 
      <p>
        <b>Rebalancing Frequency:</b>{" "}
        {portfolio.rebalancing_frequency}
      </p>
 
      <p>
        <b>Status:</b>{" "}
        {portfolio.status}
      </p>
 
 
      <button onClick={handleActivate}>
        Activate Portfolio
      </button>
 
      {" "}
 
      <button onClick={handleClose}>
        Close Portfolio
      </button>
 
 
      <hr />
 
 
      {/* =====================
          SECURITY SEARCH
      ====================== */}
 
      <h2>
        Search Security
      </h2>
 
      <input
        type="text"
        placeholder="Enter TCS, INFY..."
        value={search}
        onChange={(event) =>
          setSearch(event.target.value)
        }
      />
 
      <button onClick={handleSearch}>
        Search
      </button>
 
 
      <br />
      <br />
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>ID</th>
            <th>Symbol</th>
            <th>Name</th>
            <th>Exchange</th>
            <th>Type</th>
            <th>Use for BUY</th>
          </tr>
 
        </thead>
 
        <tbody>
 
          {securities.map((security) => (
 
            <tr key={security.security_id}>
 
              <td>
                {security.security_id}
              </td>
 
              <td>
                {security.symbol}
              </td>
 
              <td>
                {security.security_name}
              </td>
 
              <td>
                {security.exchange}
              </td>
 
              <td>
                {security.security_type}
              </td>
 
              <td>
 
                <button
                  onClick={() =>
                    setBuySecurityId(
                      security.security_id
                    )
                  }
                >
                  Select
                </button>
 
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <hr />
 
 
      {/* =====================
          BUY
      ====================== */}
 
      <h2>
        Buy Security
      </h2>
 
 
      <form onSubmit={handleBuy}>
 
        <label>
          Security ID
        </label>
 
        <br />
 
        <input
          type="number"
          value={buySecurityId}
          onChange={(event) =>
            setBuySecurityId(
              event.target.value
            )
          }
          required
        />
 
 
        <br />
        <br />
 
 
        <label>
          Quantity
        </label>
 
        <br />
 
        <input
          type="number"
          value={buyQuantity}
          onChange={(event) =>
            setBuyQuantity(
              event.target.value
            )
          }
          min="1"
          required
        />
 
 
        <br />
        <br />
 
 
        <button type="submit">
          Buy Security
        </button>
 
      </form>
 
 
      <hr />
 
 
      {/* =====================
          HOLDINGS
      ====================== */}
 
      <h2>
        Holdings
      </h2>
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>Security ID</th>
            <th>Symbol</th>
            <th>Security Name</th>
            <th>Quantity</th>
            <th>Average Buy Price</th>
            <th>Latest Price</th>
            <th>Current Value</th>
            <th>Sell</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {holdings.map((holding, index) => (
 
            <tr key={index}>
 
              <td>
                {holding.security_id}
              </td>
 
              <td>
                {holding.symbol}
              </td>
 
              <td>
                {holding.security_name}
              </td>
 
              <td>
                {holding.quantity}
              </td>
 
              <td>
                {holding.average_buy_price}
              </td>
 
              <td>
                {holding.latest_price}
              </td>
 
              <td>
                {holding.current_value}
              </td>
 
              <td>
 
                <button
                  onClick={() =>
                    setSellSecurityId(
                      holding.security_id
                    )
                  }
                >
                  Select
                </button>
 
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <br />
 
 
     {/* =====================
          SELL
      ====================== */}
 
      <h2>
        Sell Security
      </h2>
 
 
      <form onSubmit={handleSell}>
 
        <label>
          Security ID
        </label>
 
        <br />
 
        <input
          type="number"
          value={sellSecurityId}
          onChange={(event) =>
            setSellSecurityId(
              event.target.value
            )
          }
          required
        />
 
 
        <br />
        <br />
 
 
        <label>
          Quantity
        </label>
 
        <br />
 
        <input
          type="number"
          value={sellQuantity}
          onChange={(event) =>
            setSellQuantity(
              event.target.value
            )
          }
          min="1"
          required
        />
 
 
        <br />
        <br />
 
 
        <button type="submit">
          Sell Security
        </button>
 
      </form>
 
 
      <hr />
 
 
      {/* =====================
          TRANSACTIONS
      ====================== */}
 
      <h2>
        Transactions
      </h2>
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>ID</th>
            <th>Security</th>
            <th>Type</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Amount</th>
            <th>Date</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {transactions.map((transaction, index) => (
 
            <tr key={index}>
 
              <td>
                {transaction.transaction_id}
              </td>
 
              <td>
                {transaction.symbol ||
                 transaction.security_id}
              </td>
 
              <td>
                {transaction.transaction_type}
              </td>
 
              <td>
                {transaction.quantity}
              </td>
 
              <td>
                {transaction.price}
              </td>
 
              <td>
                {transaction.transaction_amount}
              </td>
 
              <td>
                {transaction.transaction_date}
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <hr />
 
 
      {/* =====================
          SUMMARY
      ====================== */}
 
      <h2>
        Portfolio Summary
      </h2>
 
      <h2>Portfolio Summary</h2>
 
      {summary ? (
          <table border="1" cellPadding="8">
              <tbody>
                  <tr>
                      <th>Portfolio Name</th>
                      <td>{summary.portfolio_name}</td>
                  </tr>
      
                  <tr>
                      <th>Status</th>
                      <td>{summary.status}</td>
                  </tr>
      
                  <tr>
                      <th>Initial Investment</th>
                      <td>₹ {summary.initial_investment}</td>
                  </tr>
      
                  <tr>
                      <th>Available Balance</th>
                      <td>₹ {summary.available_balance}</td>
                  </tr>
      
                  <tr>
                      <th>Invested Value</th>
                      <td>₹ {summary.invested_value}</td>
                  </tr>
      
                  <tr>
                      <th>Holdings Current Value</th>
                      <td>₹ {summary.holdings_current_value}</td>
                  </tr>
      
                  <tr>
                      <th>Total Portfolio Value</th>
                      <td>₹ {summary.total_portfolio_value}</td>
                  </tr>
      
                  <tr>
                      <th>Overall Profit / Loss</th>
                      <td>₹ {summary.overall_profit_loss}</td>
                  </tr>
      
                  <tr>
                      <th>Return Percentage</th>
                      <td>{summary.return_percentage}%</td>
                  </tr>
              </tbody>
          </table>
      ) : (
          <p>Loading summary...</p>
      )}

      <hr />
 
 
      {/* =====================
          ALLOCATION
      ====================== */}
 
      <h2>
        Asset Allocation
      </h2>
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>Asset Class</th>
            <th>Current Value</th>
            <th>Current Percentage</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {allocation.map((item, index) => (
 
            <tr key={index}>
 
              <td>
                {item.asset_class_name}
              </td>
 
              <td>
                {item.current_value}
              </td>
 
              <td>
                {item.current_percentage}
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <hr />
 
 
      {/* =====================
          ASSESSMENT
      ====================== */}
 
      <h2>
        Allocation Assessment
      </h2>
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>Asset Class</th>
            <th>Target %</th>
            <th>Current %</th>
            <th>Deviation %</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {assessment.map((item, index) => (
 
            <tr key={index}>
 
              <td>
                {item.asset_class_name}
              </td>
 
              <td>
                {item.target_percentage}
              </td>
 
              <td>
                {item.current_percentage}
              </td>
 
              <td>
                {item.deviation_percentage}
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <hr />
 
 
      {/* =====================
          ALERTS
      ====================== */}
 
      <h2>
        Portfolio Alerts
      </h2>
 
 
      <button onClick={() => {
        alert("BUTTON WORKS");
        handleGenerateAlerts();
      }}>
        Generate Alerts
      </button>
 
 
      <br />
      <br />
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>Alert Type</th>
            <th>Message</th>
            <th>Target %</th>
            <th>Current %</th>
            <th>Deviation %</th>
            <th>Status</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {alerts.map((alert, index) => (
 
            <tr key={index}>
 
              <td>
                {alert.alert_type}
              </td>
 
              <td>
                {alert.alert_message}
              </td>
 
              <td>
                {alert.target_percentage}
              </td>
 
              <td>
                {alert.current_percentage}
              </td>
 
              <td>
                {alert.deviation_percentage}
              </td>
 
              <td>
                {alert.status}
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <hr />
 
 
      {/* =====================
          REBALANCING
      ====================== */}
 
      <h2>
        Rebalancing Suggestions
      </h2>
 
 
      <table border="1" cellPadding="8">
 
        <thead>
 
          <tr>
            <th>Asset Class</th>
            <th>Target %</th>
            <th>Current %</th>
            <th>Current Value</th>
            <th>Target Value</th>
            <th>Adjustment</th>
            <th>Action</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {rebalancing.map((item, index) => (
 
            <tr key={index}>
 
              <td>
                {item.asset_class_name}
              </td>
 
              <td>
                {item.target_percentage}
              </td>
 
              <td>
                {item.current_percentage}
              </td>
 
              <td>
                {item.current_value}
              </td>
 
              <td>
                {item.target_value}
              </td>
 
              <td>
                {item.adjustment_amount}
              </td>
 
              <td>
                {item.action}
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      <hr />
 
 
      {/* =====================
          PERFORMANCE
      ====================== */}
 
      <h2>
        Portfolio Performance
      </h2>
 
 
 
      {performance ? (
          <table border="1" cellPadding="8">
              <tbody>
                  <tr>
                      <th>Portfolio Name</th>
                      <td>{performance.portfolio_name}</td>
                  </tr>
      
                  <tr>
                      <th>Benchmark</th>
                      <td>{performance.benchmark?.benchmark_name || "-"}</td>
                  </tr>
      
                  <tr>
                      <th>Initial Investment</th>
                      <td>₹ {performance.initial_investment}</td>
                  </tr>
      
                  <tr>
                      <th>Holdings Invested Value</th>
                      <td>₹ {performance.holdings_invested_value}</td>
                  </tr>
      
                  <tr>
                      <th>Holdings Current Value</th>
                      <td>₹ {performance.holdings_current_value}</td>
                  </tr>
      
                  <tr>
                      <th>Available Balance</th>
                      <td>₹ {performance.available_balance}</td>
                  </tr>
      
                  <tr>
                      <th>Total Portfolio Value</th>
                      <td>₹ {performance.total_portfolio_value}</td>
                  </tr>
      
                  <tr>
                      <th>Profit / Loss</th>
                      <td>₹ {performance.profit_loss}</td>
                  </tr>
      
                  <tr>
                      <th>Portfolio Return</th>
                      <td>{performance.portfolio_return_percentage}%</td>
                  </tr>
              </tbody>
          </table>
      ) : (
          <p>Loading performance...</p>
      )} 

    </div>
  );
}
 
 
export default PortfolioDetails;
 