import {
  useEffect,
  useState
} from "react";

import api from "../api/api";

import "../styles/common.css";


function AssetClasses() {

  const [
    assetClasses,
    setAssetClasses
  ] = useState([]);


  const [
    loading,
    setLoading
  ] = useState(true);


  const [
    showForm,
    setShowForm
  ] = useState(false);


  const [
    editingId,
    setEditingId
  ] = useState(null);


  const [
    message,
    setMessage
  ] = useState("");


  const [
    form,
    setForm
  ] = useState({

    asset_class_name: "",

    asset_description: "",

    sub_asset_class: "",

    sub_asset_description: "",

    risk_level: "",

    investment_horizon: ""

  });


  // =====================================================
  // LOAD
  // =====================================================

  useEffect(() => {

    loadAssetClasses();

  }, []);


  async function loadAssetClasses() {

    try {

      setLoading(true);


      const response =
        await api.get(
          "/api/asset-classes"
        );


      let list = [];


      if (
        Array.isArray(
          response.data
        )
      ) {

        list =
          response.data;

      }

      else if (
        Array.isArray(
          response.data?.asset_classes
        )
      ) {

        list =
          response.data.asset_classes;

      }

      else if (
        Array.isArray(
          response.data?.data
        )
      ) {

        list =
          response.data.data;

      }


      setAssetClasses(
        list
      );

    }

    catch (error) {

      console.log(error);

      setMessage(
        "Unable to load asset classes"
      );

    }

    finally {

      setLoading(false);

    }

  }


  // =====================================================
  // INPUT
  // =====================================================

  function handleChange(e) {

    const {
      name,
      value
    } = e.target;


    setForm({

      ...form,

      [name]:
        value

    });

  }


  // =====================================================
  // RESET
  // =====================================================

  function resetForm() {

    setForm({

      asset_class_name: "",

      asset_description: "",

      sub_asset_class: "",

      sub_asset_description: "",

      risk_level: "",

      investment_horizon: ""

    });


    setEditingId(
      null
    );


    setShowForm(
      false
    );

  }


  // =====================================================
  // ADD / UPDATE
  // =====================================================

  async function saveAssetClass(e) {

    e.preventDefault();


    try {

      setMessage("");


      if (
        !form.asset_class_name.trim()
      ) {

        setMessage(
          "Asset class name is required"
        );

        return;

      }


      if (editingId) {

        await api.put(

          `/api/asset-classes/${editingId}`,

          {

            ...form,

            status: "ACTIVE"

          }

        );


        setMessage(
          "Asset class updated successfully"
        );

      }

      else {

        await api.post(

          "/api/asset-classes",

          form

        );


        setMessage(
          "Asset class created successfully"
        );

      }


      resetForm();

      loadAssetClasses();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail

        ||
        "Unable to save asset class"

      );

    }

  }


  // =====================================================
  // EDIT
  // =====================================================

  function editAssetClass(item) {

    setEditingId(
      item.asset_class_id
    );


    setForm({

      asset_class_name:
        item.asset_class_name
        || "",

      asset_description:
        item.asset_description
        || "",

      sub_asset_class:
        item.sub_asset_class
        || "",

      sub_asset_description:
        item.sub_asset_description
        || "",

      risk_level:
        item.risk_level
        || "",

      investment_horizon:
        item.investment_horizon
        || ""

    });


    setShowForm(
      true
    );


    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });

  }


  // =====================================================
  // DEACTIVATE
  // =====================================================

  async function deactivateAssetClass(
    id
  ) {

    const confirmed =
      window.confirm(
        "Deactivate this asset class?"
      );


    if (!confirmed) {

      return;

    }


    try {

      await api.delete(

        `/api/asset-classes/${id}`

      );


      setMessage(
        "Asset class deactivated successfully"
      );


      loadAssetClasses();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail

        ||
        "Unable to deactivate asset class"

      );

    }

  }

  async function activateAssetClass(
  item
) {

  const confirmed =
    window.confirm(
      "Activate this asset class?"
    );


  if (!confirmed) {
    return;
  }


  try {

    await api.put(

      `/api/asset-classes/${item.asset_class_id}`,

      {

        asset_class_name:
          item.asset_class_name,

        asset_description:
          item.asset_description,

        sub_asset_class:
          item.sub_asset_class,

        sub_asset_description:
          item.sub_asset_description,

        risk_level:
          item.risk_level,

        investment_horizon:
          item.investment_horizon,

        status:
          "ACTIVE"

      }

    );


    setMessage(
      "Asset class activated successfully"
    );


    loadAssetClasses();

  }

  catch (error) {

    console.log(error);


    setMessage(

      error.response?.data?.detail
      ||
      "Unable to activate asset class"

    );

  }

}

  return (

    <div>


      {/* ===============================================
          HEADER
      =============================================== */}

      <div className="page-heading-row">

        <div className="page-heading">

          <h1>
            Asset Classes
          </h1>

          <p>
            Manage asset classifications used
            for portfolio allocation.
          </p>

        </div>


        <button

          className="primary-button"

          onClick={
            () => {

              resetForm();

              setShowForm(
                true
              );

            }
          }

        >

          + Add Asset Class

        </button>

      </div>


      {/* ===============================================
          MESSAGE
      =============================================== */}

      {
        message
        &&
        (

          <div className="asset-message">

            {message}

          </div>

        )
      }


      {/* ===============================================
          FORM
      =============================================== */}

      {
        showForm
        &&
        (

          <div className="content-card">

            <div className="section-heading">

              <div>

                <h3>

                  {
                    editingId
                      ? "Edit Asset Class"
                      : "Create Asset Class"
                  }

                </h3>


                <p>

                  Configure the asset class
                  details.

                </p>

              </div>


              <button

                className="close-form-button"

                onClick={
                  resetForm
                }

              >

                ×

              </button>

            </div>


            <form
              onSubmit={
                saveAssetClass
              }
            >

              <div className="asset-form-grid">


                <div className="form-group">

                  <label>
                    Asset Class Name *
                  </label>


                  <input

                    className="form-control"

                    name="asset_class_name"

                    value={
                      form.asset_class_name
                    }

                    onChange={
                      handleChange
                    }

                    placeholder="Example: Equity"

                  />

                </div>


                <div className="form-group">

                  <label>
                    Sub Asset Class
                  </label>


                  <input

                    className="form-control"

                    name="sub_asset_class"

                    value={
                      form.sub_asset_class
                    }

                    onChange={
                      handleChange
                    }

                    placeholder="Example: Listed Equity"

                  />

                </div>


                <div className="form-group">

                  <label>
                    Risk Level
                  </label>


                  <select

                    className="form-control"

                    name="risk_level"

                    value={
                      form.risk_level
                    }

                    onChange={
                      handleChange
                    }

                  >

                    <option value="">
                      Select Risk
                    </option>

                    <option value="Low">
                      Low
                    </option>

                    <option value="Low to Moderate">
                      Low to Moderate
                    </option>

                    <option value="Moderate">
                      Moderate
                    </option>

                    <option value="Moderate to High">
                      Moderate to High
                    </option>

                    <option value="High">
                      High
                    </option>

                    <option value="Very High">
                      Very High
                    </option>

                  </select>

                </div>


                <div className="form-group">

                  <label>
                    Investment Horizon
                  </label>


                  <select

                    className="form-control"

                    name="investment_horizon"

                    value={
                      form.investment_horizon
                    }

                    onChange={
                      handleChange
                    }

                  >

                    <option value="">
                      Select Horizon
                    </option>

                    <option value="Short Term">
                      Short Term
                    </option>

                    <option value="Short to Medium Term">
                      Short to Medium Term
                    </option>

                    <option value="Medium Term">
                      Medium Term
                    </option>

                    <option value="Medium to Long Term">
                      Medium to Long Term
                    </option>

                    <option value="Long Term">
                      Long Term
                    </option>

                  </select>

                </div>


                <div className="form-group full-width">

                  <label>
                    Asset Description
                  </label>


                  <textarea

                    className="form-control asset-textarea"

                    name="asset_description"

                    value={
                      form.asset_description
                    }

                    onChange={
                      handleChange
                    }

                    placeholder=
                      "Describe this asset class"

                  />

                </div>


                <div className="form-group full-width">

                  <label>
                    Sub Asset Description
                  </label>


                  <textarea

                    className="form-control asset-textarea"

                    name="sub_asset_description"

                    value={
                      form.sub_asset_description
                    }

                    onChange={
                      handleChange
                    }

                    placeholder=
                      "Describe the sub asset class"

                  />

                </div>

              </div>


              <div className="form-actions">

                <button

                  type="button"

                  className="secondary-button"

                  onClick={
                    resetForm
                  }

                >

                  Cancel

                </button>


                <button

                  type="submit"

                  className="primary-button"

                >

                  {
                    editingId
                      ? "Update Asset Class"
                      : "Create Asset Class"
                  }

                </button>

              </div>

            </form>

          </div>

        )
      }


      {/* ===============================================
          CARDS
      =============================================== */}

      {
        loading
        ?

        (

          <p className="small-muted">

            Loading asset classes...

          </p>

        )

        :

        (

          <div className="asset-class-grid">

            {
              assetClasses.map(
                item => (

                  <div

                    className="asset-class-card"

                    key={
                      item.asset_class_id
                    }

                  >

                    <div className="asset-class-card-top">

                      <div
                        className="card-icon icon-blue"
                      >

                        ◫

                      </div>


                      <span
                        className={
                          item.status === "ACTIVE"
                            ? "status-badge active-status"
                            : "status-badge inactive-status"
                        }
                      >

                        {
                          item.status
                        }

                      </span>

                    </div>


                    <h3>

                      {
                        item.asset_class_name
                      }

                    </h3>


                    <p className="asset-card-description">

                      {
                        item.asset_description
                        ||
                        "No description available"
                      }

                    </p>


                    <div className="asset-card-details">

                      <div>

                        <span>
                          Sub Asset
                        </span>

                        <strong>

                          {
                            item.sub_asset_class
                            ||
                            "-"
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Risk
                        </span>

                        <strong>

                          {
                            item.risk_level
                            ||
                            "-"
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Horizon
                        </span>

                        <strong>

                          {
                            item.investment_horizon
                            ||
                            "-"
                          }

                        </strong>

                      </div>

                    </div>


                    <div className="asset-card-actions">

                      <button

                        className="small-action-button"

                        onClick={
                          () =>
                            editAssetClass(
                              item
                            )
                        }

                      >

                        Edit

                      </button>


                      {
                        item.status === "ACTIVE"
                        ?
                        (

                          <button

                            className="small-action-button danger-button"

                            onClick={
                              () =>
                                deactivateAssetClass(
                                  item.asset_class_id
                                )
                            }

                          >

                            Deactivate

                          </button>

                        ) :
                        (
                            <button
                                className="small-action-button activate-button"
                                onClick={() => activateAssetClass(item)} >Activate</button>
                        )
                      }

                    </div>

                  </div>

                )
              )
            }

          </div>

        )
      }

    </div>

  );

}


export default AssetClasses;