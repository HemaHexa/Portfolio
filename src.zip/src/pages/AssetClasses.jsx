import { useEffect, useState } from "react";
import { getAssetClasses } from "../api/api";
 
 
function AssetClasses() {
 
  const [assetClasses, setAssetClasses] = useState([]);
 
 
  useEffect(() => {
 
    getAssetClasses().then((data) => {
      setAssetClasses(data);
    });
 
  }, []);
 
 
  return (
    <div>
 
      <h1>Asset Classes</h1>
 
      <table border="1" cellPadding="10">
 
        <thead>
          <tr>
            <th>ID</th>
            <th>Asset Class</th>
            <th>Description</th>
            <th>Sub Asset Class</th>
            <th>Risk</th>
            <th>Investment Horizon</th>
            <th>Status</th>
          </tr>
        </thead>
 
        <tbody>
 
          {assetClasses.map((asset) => (
 
            <tr key={asset.asset_class_id}>
 
              <td>{asset.asset_class_id}</td>
 
              <td>{asset.asset_class_name}</td>
 
              <td>{asset.asset_description}</td>
 
              <td>{asset.sub_asset_class}</td>
 
              <td>{asset.risk_level}</td>
 
              <td>{asset.investment_horizon}</td>
 
              <td>{asset.status}</td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
    </div>
  );
}
 
 
export default AssetClasses;