import {
  useEffect,
  useState
} from "react";

import api from "../api/api";

import "../styles/common.css";


function SecurityMaster() {

  const [
    assetClasses,
    setAssetClasses
  ] = useState([]);


  const [
    selectedAssetClass,
    setSelectedAssetClass
  ] = useState("");


  const [
    searchText,
    setSearchText
  ] = useState("");


  const [
    securities,
    setSecurities
  ] = useState([]);


  const [
    selectedSecurity,
    setSelectedSecurity
  ] = useState(null);


  const [
    latestPrice,
    setLatestPrice
  ] = useState(null);


  const [
    loading,
    setLoading
  ] = useState(false);


  const [
    message,
    setMessage
  ] = useState("");


  // =====================================================
  // LOAD ASSET CLASSES
  // =====================================================

  useEffect(() => {

    loadAssetClasses();

  }, []);


  async function loadAssetClasses() {

  try {

    const response =
      await api.get(
        "/api/asset-classes"
      );


    console.log(
      "ASSET CLASS FULL RESPONSE:",
      response.data
    );


    let list = [];


    // Direct array
    if (
      Array.isArray(
        response.data
      )
    ) {

      list =
        response.data;

    }


    // { asset_classes: [...] }
    else if (
      Array.isArray(
        response.data?.asset_classes
      )
    ) {

      list =
        response.data.asset_classes;

    }


    // { data: [...] }
    else if (
      Array.isArray(
        response.data?.data
      )
    ) {

      list =
        response.data.data;

    }


    // { data: { asset_classes: [...] } }
    else if (
      Array.isArray(
        response.data?.data?.asset_classes
      )
    ) {

      list =
        response.data.data.asset_classes;

    }


    // { results: [...] }
    else if (
      Array.isArray(
        response.data?.results
      )
    ) {

      list =
        response.data.results;

    }


    console.log(
      "FINAL ASSET CLASS LIST:",
      list
    );


    // Cash has no searchable securities,
    // so don't show it in Security Master
    const searchableClasses =
      list.filter(
        item =>
          item.asset_class_name
          !==
          "Cash"
      );


    setAssetClasses(
      searchableClasses
    );

  }

  catch (error) {

    console.log(
      "ASSET CLASS ERROR:",
      error
    );


    setAssetClasses([]);


    setMessage(
      error.response?.data?.detail

      ||
      "Unable to load asset classes"
    );

  }

}

  // =====================================================
  // SEARCH SECURITIES WITH SMALL DELAY
  // =====================================================

  useEffect(() => {

    if (
      !selectedAssetClass
      ||
      searchText.trim().length < 1
    ) {

      setSecurities([]);

      return;

    }


    const timer =
      setTimeout(() => {

        searchSecurities();

      }, 350);


    return () =>
      clearTimeout(timer);


  }, [
    selectedAssetClass,
    searchText
  ]);


  async function searchSecurities() {

    try {

      setLoading(true);

      setMessage("");


      const response =
        await api.get(
          "/api/securities/search",
          {
            params: {

              asset_class_id:
                selectedAssetClass,

              query:
                searchText

            }
          }
        );


      setSecurities(
        response.data
      );


      if (
        response.data.length === 0
      ) {

        setMessage(
          "No matching securities found"
        );

      }

    }

    catch (error) {

      console.log(error);

      setSecurities([]);

      setMessage(
        error.response?.data?.detail
        ||
        "Unable to search securities"
      );

    }

    finally {

      setLoading(false);

    }

  }


  // =====================================================
  // SELECT SECURITY
  // =====================================================

  async function selectSecurity(
    security
  ) {

    try {

      setSelectedSecurity(
        security
      );


      setSearchText(
        security.symbol
      );


      setSecurities([]);


      const response =
        await api.get(
          `/api/securities/${security.security_id}/latest-price`
        );


      setLatestPrice(
        response.data
      );

    }

    catch (error) {

      console.log(error);

      setLatestPrice(null);

      setMessage(
        "Unable to load latest price"
      );

    }

  }


  // =====================================================
  // ASSET CLASS CHANGE
  // =====================================================

  function changeAssetClass(e) {

    setSelectedAssetClass(
      e.target.value
    );

    setSearchText("");

    setSecurities([]);

    setSelectedSecurity(null);

    setLatestPrice(null);

    setMessage("");

  }


  // =====================================================
  // FORMAT MONEY
  // =====================================================

  function formatMoney(value) {

    if (
      value === null
      ||
      value === undefined
    ) {

      return "-";

    }


    return Number(
      value
    ).toLocaleString(
      "en-IN",
      {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }
    );

  }


  return (

    <div>

      {/* ===============================================
          PAGE HEADING
      =============================================== */}

      <div className="page-heading">

        <h1>
          Security Master
        </h1>

        <p>
          Search securities by asset class
          and view the latest available
          market price.
        </p>

      </div>


      {/* ===============================================
          SEARCH CARD
      =============================================== */}

      <div className="content-card">

        <div className="security-search-grid">


          {/* ASSET CLASS */}

          <div className="form-group">

            <label>
              Asset Class
            </label>


            <select

              className="form-control"

              value={
                selectedAssetClass
              }

              onChange={
                changeAssetClass
              }

            >

              <option value="">
                Select Asset Class
              </option>


              {
                assetClasses.map(
                  item => (

                    <option

                      key={
                        item.asset_class_id
                      }

                      value={
                        item.asset_class_id
                      }

                    >

                      {
                        item.asset_class_name
                      }

                    </option>

                  )
                )
              }

            </select>

          </div>


          {/* SYMBOL SEARCH */}

          <div
            className="form-group"
            style={{
              position: "relative"
            }}
          >

            <label>
              Symbol / Security Name
            </label>


            <input

              className="form-control"

              value={
                searchText
              }

              disabled={
                !selectedAssetClass
              }

              placeholder={
                selectedAssetClass
                  ? "Type H, INFY, EQ..."
                  : "Choose Asset Class first"
              }

              onChange={
                e => {

                  setSearchText(
                    e.target.value
                  );

                  setSelectedSecurity(
                    null
                  );

                  setLatestPrice(
                    null
                  );

                }
              }

            />


            {/* AUTOCOMPLETE */}

            {
              securities.length > 0
              &&
              (

                <div className="security-dropdown">

                  {
                    securities.map(
                      security => (

                        <button

                          type="button"

                          className="security-dropdown-item"

                          key={
                            security.security_id
                          }

                          onClick={
                            () =>
                              selectSecurity(
                                security
                              )
                          }

                        >

                          <div>

                            <strong>
                              {
                                security.symbol
                              }
                            </strong>

                            <span>
                              {
                                security.security_name
                              }
                            </span>

                          </div>


                          <span className="security-source">

                            {
                              security.data_source
                            }

                          </span>

                        </button>

                      )
                    )
                  }

                </div>

              )
            }

          </div>

        </div>


        {
          loading
          &&
          (

            <p className="small-muted">
              Searching...
            </p>

          )
        }


        {
          message
          &&
          (

            <p className="small-muted">
              {message}
            </p>

          )
        }

      </div>


      {/* ===============================================
          SELECTED SECURITY
      =============================================== */}

      {
        selectedSecurity
        &&
        (

          <div className="security-detail-grid">


            {/* SECURITY INFO */}

            <div className="glass-card">

              <div className="card-icon icon-blue">
                ◆
              </div>


              <div className="security-detail-title">

                {
                  selectedSecurity.symbol
                }

              </div>


              <div className="security-detail-name">

                {
                  selectedSecurity.security_name
                }

              </div>


              <div className="security-info-list">


                <div>

                  <span>
                    Asset Class
                  </span>

                  <strong>
                    {
                      selectedSecurity.asset_class_name
                    }
                  </strong>

                </div>


                <div>

                  <span>
                    Exchange
                  </span>

                  <strong>
                    {
                      selectedSecurity.exchange
                    }
                  </strong>

                </div>


                <div>

                  <span>
                    Instrument Type
                  </span>

                  <strong>
                    {
                      selectedSecurity.instrument_type
                      ||
                      "-"
                    }
                  </strong>

                </div>


                <div>

                  <span>
                    Source
                  </span>

                  <strong>
                    {
                      selectedSecurity.data_source
                    }
                  </strong>

                </div>


                <div>

                  <span>
                    ISIN
                  </span>

                  <strong>
                    {
                      selectedSecurity.isin
                      ||
                      "-"
                    }
                  </strong>

                </div>

              </div>

            </div>


            {/* PRICE */}

            <div className="glass-card">

              <div className="card-icon icon-green">
                ₹
              </div>


              <div className="card-label">

                Latest Available Price

              </div>


              <div className="security-price">

                ₹
                {
                  formatMoney(
                    latestPrice?.price
                  )
                }

              </div>


              <div className="security-price-info">

                <div>

                  <span>
                    Price Date
                  </span>

                  <strong>
                    {
                      latestPrice?.price_date
                      ||
                      "-"
                    }
                  </strong>

                </div>


                <div>

                  <span>
                    Price Type
                  </span>

                  <strong>
                    {
                      latestPrice?.price_type
                      ||
                      "-"
                    }
                  </strong>

                </div>


                <div>

                  <span>
                    Data Source
                  </span>

                  <strong>
                    {
                      latestPrice?.source
                      ||
                      "-"
                    }
                  </strong>

                </div>

              </div>

            </div>

          </div>

        )
      }

    </div>

  );

}


export default SecurityMaster;