import { useState } from "react";
 
import {
  searchSecurities,
  getSecurity
} from "../api/api";
 
 
function Securities() {
 
  const [search, setSearch] = useState("");
 
  const [securities, setSecurities] = useState([]);
 
  const [selectedSecurity, setSelectedSecurity] = useState(null);
 
 
  function searchSecurity() {
 
    searchSecurities(search).then((data) => {
 
      setSecurities(data);
 
      setSelectedSecurity(null);
 
    });
 
  }
 
 
  function viewSecurity(securityId) {
 
    getSecurity(securityId).then((data) => {
 
      setSelectedSecurity(data);
 
    });
 
  }
 
 
  return (
    <div>
 
      <h1>Security Master</h1>
 
 
      <input
        type="text"
        placeholder="Enter symbol or security name"
        value={search}
        onChange={(event) =>
          setSearch(event.target.value)
        }
      />
 
      <button onClick={searchSecurity}>
        Search
      </button>
 
 
      <br />
      <br />
 
 
      <table border="1" cellPadding="10">
 
        <thead>
 
          <tr>
            <th>ID</th>
            <th>Exchange</th>
            <th>Symbol</th>
            <th>Security Name</th>
            <th>ISIN</th>
            <th>Type</th>
            <th>Country</th>
            <th>Currency</th>
            <th>Action</th>
          </tr>
 
        </thead>
 
 
        <tbody>
 
          {securities.map((security) => (
 
            <tr key={security.security_id}>
 
              <td>
                {security.security_id}
              </td>
 
              <td>
                {security.exchange}
              </td>
 
              <td>
                {security.symbol}
              </td>
 
              <td>
                {security.security_name}
              </td>
 
              <td>
                {security.isin}
              </td>
 
              <td>
                {security.security_type}
              </td>
 
              <td>
                {security.country}
              </td>
 
              <td>
                {security.currency}
              </td>
 
              <td>
 
                <button
                  onClick={() =>
                    viewSecurity(security.security_id)
                  }
                >
                  View
                </button>
 
              </td>
 
            </tr>
 
          ))}
 
        </tbody>
 
      </table>
 
 
      {selectedSecurity && (
 
        <div>
 
          <h2>Security Details</h2>
 
          <p>
            <b>ID:</b>{" "}
            {selectedSecurity.security_id}
          </p>
 
          <p>
            <b>Symbol:</b>{" "}
            {selectedSecurity.symbol}
          </p>
 
          <p>
            <b>Name:</b>{" "}
            {selectedSecurity.security_name}
          </p>
 
          <p>
            <b>Exchange:</b>{" "}
            {selectedSecurity.exchange}
          </p>
 
          <p>
            <b>ISIN:</b>{" "}
            {selectedSecurity.isin}
          </p>
 
          <p>
            <b>Series:</b>{" "}
            {selectedSecurity.series}
          </p>
 
          <p>
            <b>Security Type:</b>{" "}
            {selectedSecurity.security_type}
          </p>
 
          <p>
            <b>Country:</b>{" "}
            {selectedSecurity.country}
          </p>
 
          <p>
            <b>Currency:</b>{" "}
            {selectedSecurity.currency}
          </p>
 
          <p>
            <b>Sector:</b>{" "}
            {selectedSecurity.sector || "-"}
          </p>
 
          <p>
            <b>Industry:</b>{" "}
            {selectedSecurity.industry || "-"}
          </p>
 
          <p>
            <b>Status:</b>{" "}
            {selectedSecurity.status}
          </p>
 
        </div>
 
      )}
 
    </div>
  );
}
 
 
export default Securities;