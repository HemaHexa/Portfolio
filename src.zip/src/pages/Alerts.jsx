import {
  useEffect,
  useState
} from "react";

import {
  useNavigate
} from "react-router-dom";

import api from "../api/api";

import "../styles/common.css";


function Alerts() {

  const navigate =
    useNavigate();


  const [alerts, setAlerts] =
    useState([]);


  const [loading, setLoading] =
    useState(true);


  const [message, setMessage] =
    useState("");


  const [filter, setFilter] =
    useState("ACTIVE");


  // =====================================================
  // LOAD ALERTS
  // =====================================================

  useEffect(() => {

    loadAlerts();

  }, []);


  async function loadAlerts() {

    try {

      setLoading(true);

      setMessage("");


      const response =
        await api.get(
          "/api/alerts"
        );


      console.log(
        "GLOBAL ALERT RESPONSE:",
        response.data
      );


      let list = [];


      if (
        Array.isArray(
          response.data
        )
      ) {

        list =
          response.data;

      }

      else if (
        Array.isArray(
          response.data?.alerts
        )
      ) {

        list =
          response.data.alerts;

      }

      else if (
        Array.isArray(
          response.data?.data
        )
      ) {

        list =
          response.data.data;

      }


      setAlerts(
        list
      );

    }

    catch (error) {

      console.log(
        "ALERT LOAD ERROR:",
        error
      );


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to load alerts"

      );

    }

    finally {

      setLoading(false);

    }

  }


  // =====================================================
  // ACCEPT / MARK READ
  // =====================================================

  async function acceptAlert(
    alertId
  ) {

    try {

      await api.put(

        `/api/alerts/${alertId}/read`

      );


      setMessage(
        "Alert acknowledged successfully"
      );


      await loadAlerts();

    }

    catch (error) {

      console.log(error);


      setMessage(

        error.response?.data?.detail
        ||
        "Unable to acknowledge alert"

      );

    }

  }


  // =====================================================
  // CHANGE / REBALANCE
  // =====================================================

  function changeAllocation(
    alert
  ) {

    navigate(

      `/portfolios/${alert.portfolio_id}`,

      {

        state: {

          openTab:
            "rebalancing",

          assetClassId:
            alert.asset_class_id

        }

      }

    );

  }


  // =====================================================
  // MONEY
  // =====================================================

  function money(value) {

    return Number(
      value || 0
    ).toLocaleString(
      "en-IN",
      {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }
    );

  }


  // =====================================================
  // FILTER
  // =====================================================

  const filteredAlerts =
    alerts.filter(
      alert => {

        if (
          filter === "ALL"
        ) {

          return true;

        }


        if (
          filter === "ACTIVE"
        ) {

          return (
            alert.status !==
            "RESOLVED"
          );

        }


        if (
          filter === "NEW"
        ) {

          return (
            alert.status ===
            "NEW"
          );

        }


        if (
          filter === "READ"
        ) {

          return (
            alert.status ===
            "READ"
          );

        }


        if (
          filter === "RESOLVED"
        ) {

          return (
            alert.status ===
            "RESOLVED"
          );

        }


        return true;

      }
    );


  // =====================================================
  // COUNTS
  // =====================================================

  const activeCount =
    alerts.filter(
      alert =>
        alert.status !==
        "RESOLVED"
    ).length;


  const newCount =
    alerts.filter(
      alert =>
        alert.status ===
        "NEW"
    ).length;


  const resolvedCount =
    alerts.filter(
      alert =>
        alert.status ===
        "RESOLVED"
    ).length;


  // =====================================================
  // UI
  // =====================================================

  return (

    <div>


      {/* ===============================================
          HEADER
      =============================================== */}

      <div className="page-heading-row">

        <div className="page-heading">

          <h1>
            Portfolio Alerts
          </h1>

          <p>
            Review allocation deviations
            across all portfolios and take
            rebalancing action.
          </p>

        </div>


        <button

          className="secondary-button"

          onClick={
            loadAlerts
          }

        >

          Refresh

        </button>

      </div>


      {/* ===============================================
          MESSAGE
      =============================================== */}

      {
        message
        &&
        (

          <div className="asset-message">

            {message}

          </div>

        )
      }


      {/* ===============================================
          SUMMARY
      =============================================== */}

      <div className="alert-summary-grid">


        <div className="glass-card alert-summary-card">

          <div className="card-icon icon-red">
            !
          </div>

          <div className="card-label">
            Active Alerts
          </div>

          <div className="card-value">
            {activeCount}
          </div>

        </div>


        <div className="glass-card alert-summary-card">

          <div className="card-icon icon-orange">
            ◉
          </div>

          <div className="card-label">
            New Alerts
          </div>

          <div className="card-value">
            {newCount}
          </div>

        </div>


        <div className="glass-card alert-summary-card">

          <div className="card-icon icon-green">
            ✓
          </div>

          <div className="card-label">
            Resolved Alerts
          </div>

          <div className="card-value">
            {resolvedCount}
          </div>

        </div>

      </div>


      {/* ===============================================
          FILTER
      =============================================== */}

      <div className="alert-filter-bar">

        {
          [
            "ACTIVE",
            "NEW",
            "READ",
            "RESOLVED",
            "ALL"
          ].map(
            item => (

              <button

                key={item}

                className={
                  filter === item
                    ? "alert-filter-button active-alert-filter"
                    : "alert-filter-button"
                }

                onClick={
                  () =>
                    setFilter(
                      item
                    )
                }

              >

                {item}

              </button>

            )
          )
        }

      </div>


      {/* ===============================================
          ALERT LIST
      =============================================== */}

      {
        loading
        ?

        (

          <p className="small-muted">
            Loading alerts...
          </p>

        )

        :

        filteredAlerts.length === 0
        ?

        (

          <div className="content-card">

            <h3>
              No Alerts
            </h3>

            <p className="content-card-subtitle">

              No alerts are available for
              the selected filter.

            </p>

          </div>

        )

        :

        (

          <div className="global-alert-grid">

            {
              filteredAlerts.map(
                alert => (

                  <div

                    className="global-alert-card"

                    key={
                      alert.alert_id
                    }

                  >


                    {/* TOP */}

                    <div className="global-alert-top">

                      <div>

                        <span className="alert-portfolio-name">

                          {
                            alert.portfolio_name
                            ||
                            `Portfolio ${alert.portfolio_id}`
                          }

                        </span>


                        <h3>

                          {
                            alert.asset_class_name
                          }

                        </h3>

                      </div>


                      <div className="global-alert-status-area">

                        <span

                          className={
                            alert.status === "RESOLVED"

                              ? "status-badge active-status"

                              : alert.status === "READ"

                                ? "status-badge read-status"

                                : "status-badge new-status"
                          }

                        >

                          {
                            alert.status
                          }

                        </span>

                      </div>

                    </div>


                    {/* MESSAGE */}

                    <p className="global-alert-message">

                      {
                        alert.alert_message
                      }

                    </p>


                    {/* VALUES */}

                    <div className="global-alert-values">


                      <div>

                        <span>
                          Target
                        </span>

                        <strong>

                          {
                            Number(
                              alert.target_percentage
                              || 0
                            ).toFixed(2)
                          }
                          %

                        </strong>

                      </div>


                      <div>

                        <span>
                          Current
                        </span>

                        <strong>

                          {
                            Number(
                              alert.current_percentage
                              || 0
                            ).toFixed(2)
                          }
                          %

                        </strong>

                      </div>


                      <div>

                        <span>
                          Deviation
                        </span>

                        <strong

                          className={
                            Math.abs(
                              Number(
                                alert.deviation_percentage
                                || 0
                              )
                            ) > 5

                              ? "loss-text"

                              : "profit-text"
                          }

                        >

                          {
                            Number(
                              alert.deviation_percentage
                              || 0
                            ).toFixed(2)
                          }
                          %

                        </strong>

                      </div>

                    </div>


                    {/* RECOMMENDATION */}

                    <div className="global-recommendation">

                      <div>

                        <span>
                          Recommendation
                        </span>


                        <strong

                          className={
                            alert.recommendation_action
                            === "INCREASE"

                              ? "recommend-increase"

                              : alert.recommendation_action
                              === "REDUCE"

                                ? "recommend-reduce"

                                : "recommend-hold"
                          }

                        >

                          {
                            alert.recommendation_action
                          }

                        </strong>

                      </div>


                      <div>

                        <span>
                          Amount
                        </span>

                        <strong>

                          ₹
                          {
                            money(
                              alert
                                .recommendation_amount
                            )
                          }

                        </strong>

                      </div>

                    </div>


                    {/* ACTIONS */}

                    <div className="global-alert-actions">


                      {
                        alert.status === "NEW"
                        &&
                        (

                          <button

                            className="small-action-button"

                            onClick={
                              () =>
                                acceptAlert(
                                  alert.alert_id
                                )
                            }

                          >

                            Accept

                          </button>

                        )
                      }


                      {
                        alert.status !== "RESOLVED"
                        &&
                        (

                          <button

                            className="small-action-button activate-button"

                            onClick={
                              () =>
                                changeAllocation(
                                  alert
                                )
                            }

                          >

                            Change / Rebalance

                          </button>

                        )
                      }


                      <button

                        className="small-action-button"

                        onClick={
                          () =>
                            navigate(

                              `/portfolios/${alert.portfolio_id}`

                            )
                        }

                      >

                        View Portfolio

                      </button>

                    </div>

                  </div>

                )
              )
            }

          </div>

        )
      }

    </div>

  );

}


export default Alerts;