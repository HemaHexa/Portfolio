const BASE_URL = "http://127.0.0.1:8000";
 
 
// ==============================
// ASSET CLASSES
// ==============================
 
export async function getAssetClasses() {
 
  const response = await fetch(
    `${BASE_URL}/api/asset-classes`
  );
 
  return await response.json();
}
 
 
export async function getAssetClass(assetClassId) {
 
  const response = await fetch(
    `${BASE_URL}/api/asset-classes/${assetClassId}`
  );
 
  return await response.json();
}
 
 
// ==============================
// INVESTMENT THEMES
// ==============================
 
export async function getThemes() {
 
  const response = await fetch(
    `${BASE_URL}/api/themes`
  );
 
  return await response.json();
}
 
 
export async function getTheme(themeId) {
 
  const response = await fetch(
    `${BASE_URL}/api/themes/${themeId}`
  );
 
  return await response.json();
}
 
 
export async function createTheme(themeData) {
 
  const response = await fetch(
    `${BASE_URL}/api/themes`,
    {
      method: "POST",
 
      headers: {
        "Content-Type": "application/json"
      },
 
      body: JSON.stringify(themeData)
    }
  );
 
  return await response.json();
}
 
 
// ==============================
// BENCHMARKS
// ==============================
 
export async function getBenchmarks() {
 
  const response = await fetch(
    `${BASE_URL}/api/benchmarks`
  );
 
  return await response.json();
}
 
 
export async function getBenchmark(benchmarkId) {
 
  const response = await fetch(
    `${BASE_URL}/api/benchmarks/${benchmarkId}`
  );
 
  return await response.json();
}
 
 
export async function getBenchmarkHistory(benchmarkId) {
 
  const response = await fetch(
    `${BASE_URL}/api/benchmarks/${benchmarkId}/history`
  );
 
  return await response.json();
}
 
 
// ==============================
// SECURITY MASTER
// ==============================
 
export async function searchSecurities(search) {
 
  const response = await fetch(
    `${BASE_URL}/api/securities?search=${encodeURIComponent(search)}&limit=50`
  );
 
  return await response.json();
}
 
 
export async function getSecurity(securityId) {
 
  const response = await fetch(
    `${BASE_URL}/api/securities/${securityId}`
  );
 
  return await response.json();
}
 
 
// ==============================
// PORTFOLIOS
// ==============================
 
export async function getPortfolios() {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios`
  );
 
  return await response.json();
}
 
 
export async function getPortfolio(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}`
  );
 
  return await response.json();
}
 
 
export async function createPortfolio(portfolioData) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios`,
    {
      method: "POST",
 
      headers: {
        "Content-Type": "application/json"
      },
 
      body: JSON.stringify(portfolioData)
    }
  );
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.detail || "Unable to create portfolio");
  }
 
  return data;
}
 
 
export async function activatePortfolio(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/activate`,
    {
      method: "PUT"
    }
  );
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.detail || "Unable to activate portfolio");
  }
 
  return data;
}
 
 
export async function closePortfolio(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/close`,
    {
      method: "PUT"
    }
  );
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.detail || "Unable to close portfolio");
  }
 
  return data;
}
 
 
// ==============================
// HOLDINGS - BUY / SELL
// ==============================
 
export async function getHoldings(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/holdings`
  );
 
  return await response.json();
}
 
 
export async function buySecurity(portfolioId, securityId, quantity) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/holdings`,
    {
      method: "POST",
 
      headers: {
        "Content-Type": "application/json"
      },
 
      body: JSON.stringify({
        security_id: Number(securityId),
        quantity: Number(quantity)
      })
    }
  );
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.detail || "Unable to buy security");
  }
 
  return data;
}
 
 
export async function sellSecurity(portfolioId, securityId, quantity) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/holdings/sell`,
    {
      method: "POST",
 
      headers: {
        "Content-Type": "application/json"
      },
 
      body: JSON.stringify({
        security_id: Number(securityId),
        quantity: Number(quantity)
      })
    }
  );
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.detail || "Unable to sell security");
  }
 
  return data;
}
 
 
// ==============================
// TRANSACTIONS
// ==============================
 
export async function getTransactions(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/transactions`
  );
 
  return await response.json();
}
 
 
// ==============================
// PORTFOLIO SUMMARY
// ==============================
 
export async function getPortfolioSummary(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/summary`
  );
 
  return await response.json();
}
 
 
// ==============================
// ASSET ALLOCATION
// ==============================
 
export async function getAllocation(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/allocation`
  );
 
  return await response.json();
}
 
 
export async function getAllocationAssessment(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/allocation-assessment`
  );
 
  return await response.json();
}
 
 
// ==============================
// ALERTS
// ==============================
 
export async function generateAlerts(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/alerts/generate`,
    {
      method: "POST"
    }
  );
 
  const data = await response.json();
 
  if (!response.ok) {
    throw new Error(data.detail || "Unable to generate alerts");
  }
 
  return data;
}
 
 
export async function getAlerts(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/alerts`
  );
 
  return await response.json();
}
 
 
// ==============================
// REBALANCING
// ==============================
 
export async function getRebalancing(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/rebalancing`
  );
 
  return await response.json();
}
 
 
// ==============================
// PERFORMANCE
// ==============================
 
export async function getPerformance(portfolioId) {
 
  const response = await fetch(
    `${BASE_URL}/api/portfolios/${portfolioId}/performance`
  );
 
  return await response.json();
}