import {
  Navigate,
  Route,
  Routes,
  useLocation
} from "react-router-dom";
import PortfolioDetails from "./pages/PortfolioDetails";
import SecurityMaster from "./pages/SecurityMaster";
import Portfolios from "./pages/Portfolios";
import CreatePortfolio from "./pages/CreatePortfolio";
import Sidebar
from "./components/Sidebar";
import AssetClasses from "./pages/AssetClasses";
import Header
from "./components/Header";
import Themes from "./pages/Themes";
import Login
from "./pages/Login";
import Alerts from "./pages/Alerts";

import Dashboard
from "./pages/Dashboard";

import PlaceholderPage
from "./pages/PlaceholderPage";


import "./styles/common.css";


function App() {

  const location =
    useLocation();


  const isLogin = (
    location.pathname
    ===
    "/login"
  );


  const loggedIn = (
    localStorage.getItem(
      "portfolio_user"
    )
  );


  if (
    !loggedIn
    &&
    !isLogin
  ) {

    return (
      <Navigate
        to="/login"
        replace
      />
    );

  }


  if (isLogin) {

    return (
      <Routes>

        <Route
          path="/login"
          element={<Login />}
        />

      </Routes>
    );

  }


  return (

    <div className="app-background">

      <div className="app-layout">

        <Sidebar />


        <main className="app-main">

          <Header />


          <div className="page-content">

            <Routes>


              <Route

                path="/"

                element={
                  <Navigate
                    to="/dashboard"
                    replace
                  />
                }

              />


              <Route
                path="/dashboard"
                element={
                  <Dashboard />
                }
              />


              <Route
                path="/securities"
                element={
                  <SecurityMaster />
                }
              />


              <Route
                path="/asset-classes"
                element={
                  <AssetClasses />
                }
              />


              <Route
                path="/themes"
                element={
                  <Themes />
                }
              />


              <Route
                path="/portfolios"
                element={
                  <Portfolios />
                }
              />

              <Route
                path="/portfolios/new"
                element={
                  <CreatePortfolio />
                }
              />

              <Route
                path="/portfolios/:portfolioId"
                element={
                  <PortfolioDetails />
                }
              />

              <Route
                path="/alerts"
                element={
                  <Alerts />
                }
              />


            </Routes>

          </div>

        </main>

      </div>

    </div>

  );

}


export default App;