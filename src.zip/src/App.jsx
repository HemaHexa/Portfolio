import { Routes, Route } from "react-router-dom";
 
import MainLayout from "./layouts/MainLayout";
 
import Dashboard from "./pages/Dashboard";
import Portfolios from "./pages/Portfolios";
import CreatePortfolio from "./pages/CreatePortfolio";
import PortfolioDetails from "./pages/PortfolioDetails";
import Securities from "./pages/Securities";
import AssetClasses from "./pages/AssetClasses";
import Themes from "./pages/Themes";
import Benchmarks from "./pages/Benchmarks";
 
 
function App() {
 
  return (
 
    <Routes>
 
      <Route element={<MainLayout />}>
 
        <Route
          path="/"
          element={<Dashboard />}
        />
 
        <Route
          path="/portfolios"
          element={<Portfolios />}
        />
 
        <Route
          path="/portfolios/create"
          element={<CreatePortfolio />}
        />
 
        <Route
          path="/portfolios/:portfolioId"
          element={<PortfolioDetails />}
        />
 
        <Route
          path="/securities"
          element={<Securities />}
        />
 
        <Route
          path="/asset-classes"
          element={<AssetClasses />}
        />
 
        <Route
          path="/themes"
          element={<Themes />}
        />
 
        <Route
          path="/benchmarks"
          element={<Benchmarks />}
        />
 
      </Route>
 
    </Routes>
 
  );
}
 
 
export default App;
 