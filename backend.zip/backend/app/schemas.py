from pydantic import BaseModel, Field
from typing import Optional
 
class ThemeCreate(BaseModel):
    theme_name: str
    description: Optional[str] = None
    risk_level: str
    investment_horizon: str
 
class ThemeAllocationCreate(BaseModel):
    asset_class_id: int
    target_percentage: float
    minimum_percentage: float
    maximum_percentage: float
 
class ThemeWithAllocationCreate(BaseModel):
    theme_name: str
    description: Optional[str] = None
    risk_level: str
    investment_horizon: str
    allocations: list[ThemeAllocationCreate]

class PortfolioCreate(BaseModel):
    portfolio_name: str
    portfolio_type: str
    currency: str = "INR"
    exchange: str = "NSE"
    theme_id: int
    benchmark_id: int
    initial_investment: float = Field(gt=0)
    rebalancing_frequency: str

class SellHoldingRequest(BaseModel):
    security_id: int
    quantity: float

 
class BuyHoldingRequest(BaseModel):
    security_id: int
    quantity: float