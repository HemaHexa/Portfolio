from fastapi import FastAPI
from app.database.connection import con_db
from app.routers import import_router
from app.routers import themes
from app.routers import asset_classes
from app.routers import securities
from app.routers import benchmarks
from app.routers import portfolios
from app.routers import holding_router
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Portfolio Management System",
    version="1.0.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins = ["http://localhost:5173"],
    allow_credentials = True,
    allow_headers=["*"],
    allow_methods=["*"]
)
app.include_router(import_router.router)
app.include_router(themes.router)
app.include_router(asset_classes.router)
app.include_router(securities.router)
app.include_router(benchmarks.router)
app.include_router(portfolios.router)
app.include_router(holding_router.router)
@app.get("/")
def home():
    return {
        "message": "Portfolio Management System API is running"
    }
@app.get("/db-test")
def test_database():
    conn = None
    try:
        conn = con_db.get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT current_database();")
        database_name = cursor.fetchone()[0]
        cursor.close()
        return {
            "message": "Database connected successfully",
            "database": database_name
        }
    finally:
        if conn is not None:
            conn.close()
 