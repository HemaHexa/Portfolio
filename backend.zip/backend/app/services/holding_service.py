from app.database.connection import con_db
from app.repositories.holding_repository import holding_repository
 
 
class HoldingService:
 
    def buy_security(
        self,
        portfolio_id: int,
        security_id: int,
        quantity: float
    ):
 
        if quantity <= 0:
            raise ValueError("Quantity must be greater than 0")
 
        conn = con_db.get_db_connection()
 
        try:
            with conn.cursor() as cursor:
 
                # -------------------------------
                # Check portfolio
                # -------------------------------
                cursor.execute(
                    """
                    SELECT portfolio_id, status
                    FROM portfolio
                    WHERE portfolio_id = %s
                    """,
                    (portfolio_id,)
                )
 
                portfolio = cursor.fetchone()
 
                if portfolio is None:
                    raise ValueError("Portfolio not found")
 
                if portfolio[1] == "Closed":
                    raise ValueError(
                        "Cannot buy securities for a closed portfolio"
                    )
 
                # -------------------------------
                # Check security
                # -------------------------------
                cursor.execute(
                    """
                    SELECT security_id
                    FROM security_master
                    WHERE security_id = %s
                      AND status = 'ACTIVE'
                    """,
                    (security_id,)
                )
 
                security = cursor.fetchone()
 
                if security is None:
                    raise ValueError(
                        "Security not found or inactive"
                    )
 
                # -------------------------------
                # Get latest imported price
                # -------------------------------
                cursor.execute(
                    """
                    SELECT price
                    FROM latest_market_price
                    WHERE security_id = %s
                    """,
                    (security_id,)
                )
 
                latest_price = cursor.fetchone()
 
                if latest_price is None:
                    raise ValueError(
                        "Latest market price is not available for this security"
                    )
 
                price = float(latest_price[0])

                # ---------------------------------
                # THEME ALLOCATION GUARDRAIL CHECK
                # ---------------------------------
                
                cursor.execute(
                    """
                    SELECT
                        sm.asset_class_id,
                        ac.asset_class_name
                    FROM security_master sm
                    JOIN asset_class ac
                        ON sm.asset_class_id = ac.asset_class_id
                    WHERE sm.security_id = %s
                    """,
                    (security_id,)
                )
                
                asset = cursor.fetchone()
                
                if asset is None:
                    raise ValueError(
                        "Asset class not found for this security"
                    )
                
                asset_class_id = asset[0]
                asset_class_name = asset[1]
                
                
                # Get portfolio theme
                cursor.execute(
                    """
                    SELECT theme_id
                    FROM portfolio
                    WHERE portfolio_id = %s
                    """,
                    (portfolio_id,)
                )
                
                theme_row = cursor.fetchone()
                
                theme_id = theme_row[0]
                
                
                # Get maximum allowed percentage
                cursor.execute(
                    """
                    SELECT maximum_percentage
                    FROM theme_allocation
                    WHERE theme_id = %s
                    AND asset_class_id = %s
                    """,
                    (
                        theme_id,
                        asset_class_id
                    )
                )
                
                limit_row = cursor.fetchone()
                
                if limit_row is None:
                    raise ValueError(
                        f"{asset_class_name} is not allowed "
                        "in this portfolio theme"
                    )
                
                maximum_percentage = float(
                    limit_row[0]
                )
                
                
                # Current total portfolio value
                cursor.execute(
                    """
                    SELECT total_portfolio_value
                    FROM vw_portfolio_summary
                    WHERE portfolio_id = %s
                    """,
                    (portfolio_id,)
                )
                
                summary_row = cursor.fetchone()
                
                total_portfolio_value = float(
                    summary_row[0]
                )
                
                
                # Current value of THIS asset class
                cursor.execute(
                    """
                    SELECT current_value
                    FROM vw_portfolio_asset_allocation
                    WHERE portfolio_id = %s
                    AND asset_class_id = %s
                    """,
                    (
                        portfolio_id,
                        asset_class_id
                    )
                )
                
                allocation_row = cursor.fetchone()
                
                if allocation_row:
                    current_asset_value = float(
                        allocation_row[0]
                    )
                else:
                    current_asset_value = 0
                
                
                # Calculate allocation AFTER this BUY
                purchase_amount = (
                    float(quantity) * float(price)
                )
                
                new_asset_value = (
                    current_asset_value
                    + purchase_amount
                )
                
                if total_portfolio_value > 0:
                
                    new_percentage = (
                        new_asset_value
                        / total_portfolio_value
                    ) * 100
                
                else:
                    new_percentage = 0
                
                
                # Reject if maximum is exceeded
                if new_percentage > maximum_percentage:
                
                    raise ValueError(
                        f"Purchase would increase "
                        f"{asset_class_name} allocation to "
                        f"{new_percentage:.2f}%, which exceeds "
                        f"the maximum allowed "
                        f"{maximum_percentage:.2f}%"
                    )
        finally:
            conn.close()

        # Repository performs the actual BUY transaction
        return holding_repository.buy_security(
            portfolio_id=portfolio_id,
            security_id=security_id,
            quantity=quantity,
            price=price
        )

    def sell_security(
        self,
        portfolio_id: int,
        security_id: int,
        quantity: float
    ):
    
        if quantity <= 0:
            raise ValueError("Quantity must be greater than 0")
    
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                # Check portfolio
                cursor.execute(
                    """
                    SELECT status
                    FROM portfolio
                    WHERE portfolio_id = %s
                    """,
                    (portfolio_id,)
                )
    
                portfolio = cursor.fetchone()
    
                if portfolio is None:
                    raise ValueError("Portfolio not found")
    
                if portfolio[0] == "Closed":
                    raise ValueError(
                        "Cannot sell securities from a closed portfolio"
                    )
    
                # Check whether portfolio owns this security
                cursor.execute(
                    """
                    SELECT quantity
                    FROM portfolio_holding
                    WHERE portfolio_id = %s
                    AND security_id = %s
                    """,
                    (portfolio_id, security_id)
                )
    
                holding = cursor.fetchone()
    
                if holding is None:
                    raise ValueError(
                        "Security is not present in this portfolio"
                    )
    
                if quantity > float(holding[0]):
                    raise ValueError(
                        "Sell quantity cannot be greater than holding quantity"
                    )
    
                # Get latest imported market price
                cursor.execute(
                    """
                    SELECT price
                    FROM latest_market_price
                    WHERE security_id = %s
                    """,
                    (security_id,)
                )
    
                latest_price = cursor.fetchone()
    
                if latest_price is None:
                    raise ValueError(
                        "Latest market price is not available for this security"
                    )
    
                price = float(latest_price[0])
    
        finally:
            conn.close()
    
        return holding_repository.sell_security(
            portfolio_id=portfolio_id,
            security_id=security_id,
            quantity=quantity,
            price=price
        )
    def get_portfolio_holdings(self, portfolio_id: int):
 
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT portfolio_id
                    FROM portfolio
                    WHERE portfolio_id = %s
                    """,
                    (portfolio_id,)
                )
    
                portfolio = cursor.fetchone()
    
                if portfolio is None:
                    raise ValueError("Portfolio not found")
    
        finally:
            conn.close()
    
        rows = holding_repository.get_portfolio_holdings(
            portfolio_id
        )
    
        holdings = []
    
        total_invested_value = 0
        total_current_value = 0
    
        for row in rows:
    
            quantity = float(row[6])
            average_buy_price = float(row[7])
    
            latest_price = (
                float(row[8])
                if row[8] is not None
                else None
            )
    
            invested_value = (
                quantity * average_buy_price
            )
    
            current_value = (
                quantity * latest_price
                if latest_price is not None
                else None
            )
    
            profit_loss = (
                current_value - invested_value
                if current_value is not None
                else None
            )
    
            total_invested_value += invested_value
    
            if current_value is not None:
                total_current_value += current_value
    
            holdings.append(
                {
                    "holding_id": row[0],
                    "security_id": row[1],
                    "symbol": row[2],
                    "security_name": row[3],
                    "asset_class_name": row[4],
                    "sub_asset_class": row[5],
                    "quantity": quantity,
                    "average_buy_price": average_buy_price,
                    "latest_price": latest_price,
                    "price_date": row[9],
                    "invested_value": invested_value,
                    "current_value": current_value,
                    "profit_loss": profit_loss
                }
            )
    
        return {
            "portfolio_id": portfolio_id,
            "total_holdings": len(holdings),
            "total_invested_value": total_invested_value,
            "total_current_value": total_current_value,
            "total_profit_loss": (
                total_current_value
                - total_invested_value
            ),
            "holdings": holdings
        }
    def get_transaction_history(self, portfolio_id: int):
 
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                # Check whether portfolio exists
                cursor.execute(
                    """
                    SELECT portfolio_id
                    FROM portfolio
                    WHERE portfolio_id = %s
                    """,
                    (portfolio_id,)
                )
    
                portfolio = cursor.fetchone()
    
                if portfolio is None:
                    raise ValueError("Portfolio not found")
    
        finally:
            conn.close()
    
        rows = holding_repository.get_transaction_history(
            portfolio_id
        )
    
        transactions = []
    
        for row in rows:
    
            transactions.append(
                {
                    "transaction_id": row[0],
                    "security_id": row[1],
                    "symbol": row[2],
                    "security_name": row[3],
                    "transaction_type": row[4],
                    "quantity": float(row[5]),
                    "price": float(row[6]),
                    "transaction_amount": float(row[7]),
                    "transaction_date": row[8]
                }
            )
    
        return {
            "portfolio_id": portfolio_id,
            "total_transactions": len(transactions),
            "transactions": transactions
        }

    def get_portfolio_summary(self, portfolio_id: int):
 
        row = holding_repository.get_portfolio_summary(
            portfolio_id
        )
    
        if row is None:
            raise ValueError("Portfolio not found")
    
        initial_investment = float(row[2])
        available_balance = float(row[3])
        invested_value = float(row[5])
        holdings_current_value = float(row[6])
    
        total_portfolio_value = (
            available_balance
            + holdings_current_value
        )
    
        overall_profit_loss = (
            total_portfolio_value
            - initial_investment
        )
    
        if initial_investment > 0:
            return_percentage = (
                overall_profit_loss
                / initial_investment
            ) * 100
        else:
            return_percentage = 0
    
        return {
            "portfolio_id": row[0],
            "portfolio_name": row[1],
            "status": row[4],
            "initial_investment": initial_investment,
            "available_balance": available_balance,
            "invested_value": invested_value,
            "holdings_current_value": holdings_current_value,
            "total_portfolio_value": total_portfolio_value,
            "overall_profit_loss": overall_profit_loss,
            "return_percentage": return_percentage
        }

    def get_asset_allocation(self, portfolio_id: int):
 
        summary = holding_repository.get_portfolio_summary(
            portfolio_id
        )
    
        if summary is None:
            raise ValueError("Portfolio not found")
    
        rows = holding_repository.get_asset_allocation(
            portfolio_id
        )
    
        allocations = []
    
        total_holdings_value = 0
    
        for row in rows:
            total_holdings_value += float(row[2])
    
        for row in rows:
    
            current_value = float(row[2])
    
            if total_holdings_value > 0:
                current_percentage = (
                    current_value
                    / total_holdings_value
                ) * 100
            else:
                current_percentage = 0
    
            allocations.append(
                {
                    "asset_class_id": row[0],
                    "asset_class_name": row[1],
                    "current_value": current_value,
                    "current_percentage": round(
                        current_percentage,
                        2
                    )
                }
            )
    
        return {
            "portfolio_id": portfolio_id,
            "total_holdings_value": total_holdings_value,
            "allocations": allocations
        }

    def get_allocation_assessment(self, portfolio_id: int):
    
        # ---------------------------------
        # Get portfolio summary
        # ---------------------------------
    
        summary = holding_repository.get_portfolio_summary(
            portfolio_id
        )
    
        if summary is None:
            raise ValueError("Portfolio not found")
    
        # From get_portfolio_summary query:
        # row[3] = available_balance
        available_balance = float(summary[3])
    
        # ---------------------------------
        # Get holdings + theme allocation
        # ---------------------------------
    
        current_rows = holding_repository.get_asset_allocation(
            portfolio_id
        )
    
        theme_rows = holding_repository.get_theme_allocation(
            portfolio_id
        )
    
        if not theme_rows:
            raise ValueError(
                "Theme allocation is not available for this portfolio"
            )
    
        # ---------------------------------
        # Calculate holdings value
        # ---------------------------------
    
        total_holdings_value = sum(
            float(row[2])
            for row in current_rows
        )
    
        # Whole portfolio = cash + holdings
        total_portfolio_value = (
            available_balance
            + total_holdings_value
        )
    
        # ---------------------------------
        # Store holding values by asset class
        # ---------------------------------
    
        current_values = {}
    
        for row in current_rows:
    
            asset_class_id = row[0]
            asset_class_name = row[1]
            current_value = float(row[2])
    
            current_values[asset_class_id] = {
                "asset_class_name": asset_class_name,
                "current_value": current_value
            }
    
        # ---------------------------------
        # Add available balance as Cash
        # ---------------------------------
    
        for row in theme_rows:
    
            asset_class_id = row[2]
            asset_class_name = row[3]
    
            if asset_class_name.lower() == "cash":
    
                current_values[asset_class_id] = {
                    "asset_class_name": asset_class_name,
                    "current_value": available_balance
                }
    
                break
    
        # ---------------------------------
        # Compare current vs theme target
        # ---------------------------------
    
        assessment = []
    
        for row in theme_rows:
    
            asset_class_id = row[2]
            asset_class_name = row[3]
    
            target_percentage = float(row[4])
    
            minimum_percentage = (
                float(row[5])
                if row[5] is not None
                else None
            )
    
            maximum_percentage = (
                float(row[6])
                if row[6] is not None
                else None
            )
    
            current = current_values.get(
                asset_class_id,
                {
                    "current_value": 0
                }
            )
    
            current_value = current["current_value"]
    
            if total_portfolio_value > 0:
    
                current_percentage = (
                    current_value
                    / total_portfolio_value
                ) * 100
    
            else:
                current_percentage = 0
    
            deviation_percentage = (
                current_percentage
                - target_percentage
            )
    
            assessment.append(
                {
                    "asset_class_id": asset_class_id,
                    "asset_class_name": asset_class_name,
    
                    "target_percentage":
                        target_percentage,
    
                    "minimum_percentage":
                        minimum_percentage,
    
                    "maximum_percentage":
                        maximum_percentage,
    
                    "current_value":
                        round(current_value, 2),
    
                    "current_percentage":
                        round(current_percentage, 2),
    
                    "deviation_percentage":
                        round(deviation_percentage, 2)
                }
            )
    
        return {
            "portfolio_id": portfolio_id,
            "theme_id": theme_rows[0][0],
            "theme_name": theme_rows[0][1],
    
            "available_balance":
                available_balance,
    
            "total_holdings_value":
                total_holdings_value,
    
            "total_portfolio_value":
                total_portfolio_value,
    
            "assessment":
                assessment
        }

    def generate_allocation_alerts(self, portfolio_id: int):
 
        assessment_result = self.get_allocation_assessment(
            portfolio_id
        )
    
        alerts = []
    
        for item in assessment_result["assessment"]:
    
            deviation = float(
                item["deviation_percentage"]
            )
    
            # Requirement:
            # alert only when deviation is MORE THAN 5%
            if abs(deviation) > 5:
    
                if deviation > 0:
                    direction = "above"
                else:
                    direction = "below"
    
                message = (
                    f'{item["asset_class_name"]} allocation '
                    f'is {abs(deviation):.2f}% {direction} '
                    f'the target allocation.'
                )
    
                alerts.append(
                    {
                        "asset_class_id":
                            item["asset_class_id"],
    
                        "asset_class_name":
                            item["asset_class_name"],
    
                        "target_percentage":
                            item["target_percentage"],
    
                        "current_percentage":
                            item["current_percentage"],
    
                        "deviation_percentage":
                            item["deviation_percentage"],
    
                        "alert_message":
                            message
                    }
                )
    
        holding_repository.refresh_allocation_alerts(
            portfolio_id,
            alerts
        )
    
        return {
            "portfolio_id": portfolio_id,
            "alert_threshold": 5,
            "total_alerts": len(alerts),
            "alerts": alerts
        }
    
    
    def get_active_alerts(self, portfolio_id: int):
    
        # Confirm portfolio exists
        summary = holding_repository.get_portfolio_summary(
            portfolio_id
        )
    
        if summary is None:
            raise ValueError("Portfolio not found")
    
        rows = holding_repository.get_active_alerts(
            portfolio_id
        )
    
        alerts = []
    
        for row in rows:
    
            alerts.append(
                {
                    "alert_id": row[0],
                    "asset_class_id": row[1],
                    "asset_class_name": row[2],
                    "alert_type": row[3],
                    "alert_message": row[4],
                    "target_percentage": float(row[5]),
                    "current_percentage": float(row[6]),
                    "deviation_percentage": float(row[7]),
                    "status": row[8],
                    "generated_at": row[9]
                }
            )
    
        return {
            "portfolio_id": portfolio_id,
            "total_active_alerts": len(alerts),
            "alerts": alerts
        }

    def get_rebalancing_recommendation(self, portfolio_id: int):
 
        # Reuse our existing allocation assessment
        result = self.get_allocation_assessment(
            portfolio_id
        )
    
        total_portfolio_value = float(
            result["total_portfolio_value"]
        )
    
        recommendations = []
    
        for item in result["assessment"]:
    
            target_percentage = float(
                item["target_percentage"]
            )
    
            current_percentage = float(
                item["current_percentage"]
            )
    
            current_value = float(
                item["current_value"]
            )
    
            # Value that SHOULD be present
            target_value = (
                total_portfolio_value
                * target_percentage
                / 100
            )
    
            # How much needs to change
            adjustment_amount = (
                target_value - current_value
            )
    
            # Decide recommendation
            if adjustment_amount > 0:
                action = "INCREASE"
    
            elif adjustment_amount < 0:
                action = "REDUCE"
    
            else:
                action = "NO ACTION"
    
            recommendations.append(
                {
                    "asset_class_id":
                        item["asset_class_id"],
    
                    "asset_class_name":
                        item["asset_class_name"],
    
                    "target_percentage":
                        target_percentage,
    
                    "current_percentage":
                        current_percentage,
    
                    "current_value":
                        round(current_value, 2),
    
                    "target_value":
                        round(target_value, 2),
    
                    "adjustment_amount":
                        round(abs(adjustment_amount), 2),
    
                    "action":
                        action
                }
            )
    
        return {
            "portfolio_id":
                portfolio_id,
    
            "theme_id":
                result["theme_id"],
    
            "theme_name":
                result["theme_name"],
    
            "total_portfolio_value":
                total_portfolio_value,
    
            "recommendations":
                recommendations
        }

holding_service = HoldingService()