from app.repositories.asset_class_repository import (
    asset_class_repository
)
 
 
class AssetClassService:
 
    def get_all_asset_classes(self):
 
        rows = (
            asset_class_repository
            .get_all_asset_classes()
        )
 
        return [
            {
                "asset_class_id": row[0],
                "asset_class_name": row[1],
                "asset_description": row[2],
                "sub_asset_class": row[3],
                "sub_asset_description": row[4],
                "risk_level": row[5],
                "investment_horizon": row[6],
                "status": row[7]
            }
            for row in rows
        ]
 
 
    def get_asset_class(self, asset_class_id):
 
        row = (
            asset_class_repository
            .get_asset_class_by_id(asset_class_id)
        )
 
        if row is None:
            raise ValueError(
                "Asset class not found"
            )
 
        return {
            "asset_class_id": row[0],
            "asset_class_name": row[1],
            "asset_description": row[2],
            "sub_asset_class": row[3],
            "sub_asset_description": row[4],
            "risk_level": row[5],
            "investment_horizon": row[6],
            "status": row[7]
        }
 
 
asset_class_service = AssetClassService()