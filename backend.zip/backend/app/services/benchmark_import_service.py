import os
import pandas as pd
 
from app.repositories.benchmark_repository import (
    benchmark_repository
)
 
 
class BenchmarkImportService:
 
    def __init__(self):
 
        self.file_path = os.path.join(
            "..",
            "data",
            "raw",
            "benchmark",
            "nifty50_historical.csv"
        )
 
 
    def import_nifty50(self):
 
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(
                f"Benchmark file not found: {self.file_path}"
            )
 
        # Read downloaded NSE Indices CSV
        df = pd.read_csv(self.file_path)
 
        # Remove accidental spaces from column names
        df.columns = df.columns.str.strip()
 
        required_columns = [
            "Date",
            "Close"
        ]
 
        for column in required_columns:
            if column not in df.columns:
                raise ValueError(
                    f"Required column '{column}' not found. "
                    f"Available columns: {list(df.columns)}"
                )
 
        # ------------------------------------------------
        # 1. Create / update NIFTY 50 benchmark master
        # ------------------------------------------------
 
        benchmark_id = (
            benchmark_repository.upsert_benchmark(
                benchmark_name="NIFTY 50",
                benchmark_code="NIFTY50",
                exchange="NSE",
                currency="INR",
                country="India",
                description="NIFTY 50 benchmark index",
                source="NSE Indices"
            )
        )
 
        # ------------------------------------------------
        # 2. Prepare historical prices
        # ------------------------------------------------
 
        prices = []
        failed_rows = []
 
        for index, row in df.iterrows():
 
            try:
                price_date = pd.to_datetime(
                    row["Date"],
                    dayfirst=True
                ).date()
 
                close_value = float(
                    str(row["Close"])
                    .replace(",", "")
                    .strip()
                )
 
                prices.append(
                    (
                        benchmark_id,
                        price_date,
                        close_value,
                        "NSE Indices"
                    )
                )
 
            except Exception as error:
 
                failed_rows.append(
                    {
                        "row": int(index) + 2,
                        "error": str(error)
                    }
                )
 
        # ------------------------------------------------
        # 3. Insert history
        # ------------------------------------------------
 
        processed = 0
 
        if prices:
            processed = (
                benchmark_repository
                .bulk_upsert_prices(prices)
            )
 
        return {
            "message": "NIFTY 50 benchmark import completed",
            "benchmark_id": benchmark_id,
            "total_file_rows": len(df),
            "processed": processed,
            "failed": len(failed_rows),
            "failed_rows": failed_rows
        }
 
 
benchmark_import_service = BenchmarkImportService()