from app.repositories.theme_repository import (
    theme_repository
)
 
 
class ThemeService:
 
    def create_theme(self, data):
 
        if not data.allocations:
            raise ValueError(
                "At least one asset allocation is required"
            )
 
        total = sum(
            allocation.target_percentage
            for allocation in data.allocations
        )
 
        if abs(total - 100) > 0.01:
            raise ValueError(
                "Total target allocation must be 100%"
            )
 
        asset_ids = [
            allocation.asset_class_id
            for allocation in data.allocations
        ]
 
        if len(asset_ids) != len(set(asset_ids)):
            raise ValueError(
                "Duplicate asset class is not allowed"
            )
 
        for allocation in data.allocations:
 
            if not (
                0 <= allocation.minimum_percentage <= 100
                and
                0 <= allocation.target_percentage <= 100
                and
                0 <= allocation.maximum_percentage <= 100
            ):
                raise ValueError(
                    "Allocation percentages must be "
                    "between 0 and 100"
                )
 
            if not (
                allocation.minimum_percentage
                <= allocation.target_percentage
                <= allocation.maximum_percentage
            ):
                raise ValueError(
                    "Allocation must satisfy "
                    "minimum <= target <= maximum"
                )
 
        theme_id = theme_repository.create_theme(
            data.theme_name,
            data.description,
            data.risk_level,
            data.investment_horizon
        )
 
        allocations = [
            allocation.model_dump()
            for allocation in data.allocations
        ]
 
        theme_repository.create_allocations(
            theme_id,
            allocations
        )
 
        return {
            "message": "Investment theme created",
            "theme_id": theme_id
        }
 
 
    def get_all_themes(self):
 
        rows = theme_repository.get_all_themes()
 
        return [
            {
                "theme_id": row[0],
                "theme_name": row[1],
                "description": row[2],
                "risk_level": row[3],
                "investment_horizon": row[4],
                "status": row[5]
            }
            for row in rows
        ]
 
 
    def get_theme(self, theme_id):
 
        theme = theme_repository.get_theme_by_id(
            theme_id
        )
 
        if theme is None:
            raise ValueError(
                "Investment theme not found"
            )
 
        allocations = (
            theme_repository
            .get_theme_allocations(theme_id)
        )
 
        return {
            "theme_id": theme[0],
            "theme_name": theme[1],
            "description": theme[2],
            "risk_level": theme[3],
            "investment_horizon": theme[4],
            "status": theme[5],
 
            "allocations": [
                {
                    "theme_allocation_id": row[0],
                    "asset_class_id": row[2],
                    "asset_class_name": row[3],
                    "sub_asset_class": row[4],
                    "target_percentage": float(row[5]),
                    "minimum_percentage": float(row[6]),
                    "maximum_percentage": float(row[7])
                }
                for row in allocations
            ]
        }
 
 
theme_service = ThemeService()