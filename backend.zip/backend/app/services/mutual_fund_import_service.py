import pandas as pd
from app.repositories.security_repository import security_repository
from app.repositories.mutual_fund_repository import mutual_fund_repository
 
class MutualFundImportService:
    def clean_text(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value in ("", "-", "--"):
            return None
        return value
 
    def clean_number(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value in (
            "",
            "-",
            "--",
            "N.A.",
            "NA"
        ):
            return None
        value = value.replace(",", "")
        return float(value)
 
    def import_nav_file(self, file_path):
        df = pd.read_csv(
            file_path,
            sep=";",
            dtype=str
        )
        df.columns = df.columns.str.strip()
        required_columns = [
            "Scheme Code",
            "Scheme Name",
            "Net Asset Value",
            "Date"
        ]
        missing_columns = [
            column
            for column in required_columns
            if column not in df.columns
        ]
        if missing_columns:
            raise ValueError(
                f"Missing Mutual Fund columns: {missing_columns}"
            )
        mf_asset_class_id = (
            security_repository.get_asset_class_id(
                "Mutual Fund"
            )
        )
        if mf_asset_class_id is None:
            raise ValueError(
                "Mutual Fund asset class is not available"
            ) 
        schemes = {}
        failed_rows = []
        for index, row in df.iterrows():
            try:
                scheme_code = self.clean_text(row.get("Scheme Code"))
                if (scheme_code is None or not scheme_code.isdigit()):
                    continue
                scheme_name = self.clean_text(row.get("Scheme Name")) 
                if (
                    scheme_code is None
                    or scheme_name is None
                ):
                    continue
                isin = self.clean_text(
                    row.get(
                        "ISIN Div Payout/ ISIN Growth"
                    )
                )
                if isin is None:
                    isin = self.clean_text(
                        row.get(
                            "ISIN Div Reinvestment"
                        )
                    )
                schemes[scheme_code] = (
                    "AMFI",                   
                    scheme_code,              
                    scheme_name,
                    isin,
                    "Mutual Fund Scheme",
                    mf_asset_class_id,
                    "India",
                    "INR",
                    scheme_code,
                    "ACTIVE",
                    "AMFI"
                )
 
 
            except Exception as error:
 
                failed_rows.append({
                    "row": index + 2,
                    "error": str(error)
                })
        scheme_records = list(
            schemes.values()
        )
        master_processed = (
            security_repository
            .bulk_upsert_mutual_funds(
                scheme_records
            )
        )
        security_map = (
            security_repository
            .get_mutual_fund_security_map()
        )
        nav_rows = []
        for index, row in df.iterrows():
            try:
                scheme_code = self.clean_text(row.get("Scheme Code"))
                if (scheme_code is None or not scheme_code.isdigit()):
                    continue
                security_id = security_map.get(scheme_code)
                if security_id is None:
                    raise ValueError(
                        f"Security not found for scheme "
                        f"{scheme_code}"
                    )
                nav = self.clean_number(row.get("Net Asset Value"))
                if nav is None:
                    continue
                nav_date = pd.to_datetime(
                    row.get("Date"),
                    errors="coerce",
                    dayfirst=True
                )
                if pd.isna(nav_date):
                    raise ValueError("Invalid NAV date")
                nav_date = nav_date.date()
                plan = self.clean_text(row.get("Plan"))
                option_type = self.clean_text(row.get("Option"))
                nav_rows.append(
                    (
                        security_id,
                        nav_date,
                        nav,
                        plan,
                        option_type,
                        "AMFI"
                    )
                )
            except Exception as error:
                failed_rows.append({
                    "row": index + 2,
                    "error": str(error)
                })
        nav_processed = (
            mutual_fund_repository
            .bulk_upsert_nav(
                nav_rows
            )
        )
        return {
            "total_file_rows":len(df),
            "unique_schemes":len(schemes),
            "master_processed":master_processed,
            "nav_processed":nav_processed,
            "failed":len(failed_rows),
            "failed_rows":failed_rows[:20]
        }
 
mutual_fund_import_service = MutualFundImportService()
 