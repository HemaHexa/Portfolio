from app.repositories.benchmark_repository import (
    benchmark_repository
)
 
 
class BenchmarkService:
 
    def get_all_benchmarks(self):
 
        rows = benchmark_repository.get_all_benchmarks()
 
        return [
            {
                "benchmark_id": row[0],
                "benchmark_name": row[1],
                "benchmark_code": row[2],
                "exchange": row[3],
                "currency": row[4],
                "country": row[5],
                "description": row[6],
                "status": row[7],
                "source": row[8]
            }
            for row in rows
        ]
 
 
    def get_benchmark(self, benchmark_id):
 
        row = benchmark_repository.get_benchmark_by_id(
            benchmark_id
        )
 
        if row is None:
            raise ValueError("Benchmark not found")
 
        return {
            "benchmark_id": row[0],
            "benchmark_name": row[1],
            "benchmark_code": row[2],
            "exchange": row[3],
            "currency": row[4],
            "country": row[5],
            "description": row[6],
            "status": row[7],
            "source": row[8]
        }
 
 
    def get_benchmark_history(self, benchmark_id):
 
        benchmark = (
            benchmark_repository
            .get_benchmark_by_id(benchmark_id)
        )
 
        if benchmark is None:
            raise ValueError("Benchmark not found")
 
        rows = (
            benchmark_repository
            .get_benchmark_history(benchmark_id)
        )
 
        return {
            "benchmark_id": benchmark_id,
            "benchmark_name": benchmark[1],
            "benchmark_code": benchmark[2],
 
            "history": [
                {
                    "benchmark_price_id": row[0],
                    "price_date": row[1],
                    "close_value": float(row[2]),
                    "source": row[3]
                }
                for row in rows
            ]
        }
 
 
benchmark_service = BenchmarkService()