import pandas as pd
from app.repositories.price_repository import price_repository
 
class PriceImportService:
    def clean_text(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value in ("", "-", "--"):
            return None
        return value
 
    def clean_number(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value in ("", "-", "--"):
            return None
        value = value.replace(",", "")
        value = value.replace("₹", "")
        return float(value)
 
    def clean_integer(self, value):
        value = self.clean_number(value)
        if value is None:
            return None
        return int(value)
 
    def find_column(self, df, possible_names):
        for name in possible_names:
            if name in df.columns:
                return name
        return None
 
    def import_equity_file(self, file_path):
        df = pd.read_csv(file_path)
        df.columns = df.columns.str.strip()
        required_columns = [
            "Symbol",
            "Date",
            "Open Price",
            "High Price",
            "Low Price",
            "Close Price"
        ]
        missing_columns = [
            column
            for column in required_columns
            if column not in df.columns
        ]

        if missing_columns:
            raise ValueError(
                f"Missing required columns: {missing_columns}"
            )
        security_map = price_repository.get_security_map()
        turnover_column = self.find_column(
            df,
            [
                "Turnover ₹",
                "Turnover",
                "Turnover (₹)"
            ]
        )
        trades_column = self.find_column(
            df,
            [
                "No. of Trades",
                "No. Of Trades"
            ]
        )
        delivery_column = self.find_column(
            df,
            [
                "Deliverable Qty",
                "Deliverable Quantity"
            ]
        )
        delivery_percentage_column = self.find_column(
            df,
            [
                "% Dly Qt to Traded Qty",
                "% Deliverable Qty to Traded Qty"
            ]
        )
        prices = []
        failed_rows = []
        for index, row in df.iterrows():
            try:
                symbol = self.clean_text( row["Symbol"])
                if not symbol:
                    raise ValueError("Symbol is missing")
                symbol = symbol.upper()
                security_id = security_map.get(symbol)
                if security_id is None:
                    raise ValueError(
                        f"{symbol} is not available in security_master"
                    )
                trade_date = pd.to_datetime(
                    row["Date"],
                    errors="coerce",
                    dayfirst=True
                )
                if pd.isna(trade_date):
                    raise ValueError("Invalid trade date")
                trade_date = trade_date.date()
                previous_close = self.clean_number(row.get("Prev Close"))
                open_price = self.clean_number(row.get("Open Price"))
                high_price = self.clean_number(row.get("High Price"))
                low_price = self.clean_number(row.get("Low Price"))
                last_price = self.clean_number(row.get("Last Price"))
                close_price = self.clean_number(row.get("Close Price"))
                average_price = self.clean_number(row.get("Average Price"))
                volume = self.clean_integer(row.get("Total Traded Quantity"))
                turnover = (
                    self.clean_number(
                        row.get(turnover_column)
                    )
                    if turnover_column
                    else None
                )
                number_of_trades = (
                    self.clean_integer(
                        row.get(trades_column)
                    )
                    if trades_column
                    else None
                )
                deliverable_quantity = (
                    self.clean_integer(
                        row.get(delivery_column)
                    )
                    if delivery_column
                    else None
                )
                delivery_percentage = (
                    self.clean_number(
                        row.get(delivery_percentage_column)
                    )
                    if delivery_percentage_column
                    else None
                )
                price = (
                    security_id,
                    trade_date,
                    previous_close,
                    open_price,
                    high_price,
                    low_price,
                    last_price,
                    close_price,
                    average_price,
                    volume,
                    turnover,
                    number_of_trades,
                    deliverable_quantity,
                    delivery_percentage,
                    "NSE"
                )
                prices.append(price)
            except Exception as error:
                failed_rows.append({
                    "row": index + 2,
                    "error": str(error)
                })
        processed = price_repository.bulk_upsert_prices(
            prices
        )
        price_repository.refresh_latest_prices()
        return {
            "file": str(file_path),
            "total_rows": len(df),
            "processed": processed,
            "failed": len(failed_rows),
            "failed_rows": failed_rows[:20]
        }
 
price_import_service = PriceImportService()
 