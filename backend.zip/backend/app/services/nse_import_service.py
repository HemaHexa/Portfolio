import pandas as pd
from app.repositories.security_repository import security_repository
 
class NSEImportService:
    def clean_text(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value == "":
            return None
        return value
 
    def clean_number(self, value):
        if pd.isna(value):
            return None
        value = str(value).replace(",", "").strip()
        if value in ("", "-", "--"):
            return None
        return float(value)
 
    def clean_integer(self, value):
        value = self.clean_number(value)
        if value is None:
            return None
        return int(value)
 
    def import_equity_master(self, file_path):
        df = pd.read_csv(file_path)
        # NSE column names sometimes contain spaces.
        df.columns = df.columns.str.strip()
        required_columns = [
            "SYMBOL",
            "NAME OF COMPANY",
            "SERIES",
            "DATE OF LISTING",
            "PAID UP VALUE",
            "MARKET LOT",
            "ISIN NUMBER",
            "FACE VALUE"
        ]
        missing_columns = [
            column
            for column in required_columns
            if column not in df.columns
        ]
        if missing_columns:
            raise ValueError(
                f"Missing CSV columns: {missing_columns}"
            )
        # Find our Equity master ID.
        equity_asset_class_id = (
            security_repository.get_asset_class_id("Equity")
        )
        if equity_asset_class_id is None:
            raise ValueError(
                "Equity asset class is not available in asset_class table"
            )
        securities = []
        failed_rows = []
        for index, row in df.iterrows():
            try:
                symbol = self.clean_text(row["SYMBOL"])
                security_name = self.clean_text(row["NAME OF COMPANY"])
                isin = self.clean_text(row["ISIN NUMBER"])
                series = self.clean_text(row["SERIES"])
                if not symbol or not security_name:
                    raise ValueError(
                        "Symbol or company name is missing"
                    )
                listing_date = pd.to_datetime(
                    row["DATE OF LISTING"],
                    errors="coerce",
                    dayfirst=True
                )
                if pd.isna(listing_date):
                    listing_date = None
                else:
                    listing_date = listing_date.date()
                paid_up_value = self.clean_number(row["PAID UP VALUE"])
                market_lot = self.clean_integer(row["MARKET LOT"])
                face_value = self.clean_number(row["FACE VALUE"])
                security = (
                    "NSE",                    
                    symbol,
                    security_name,
                    isin,
                    series,
                    None,                     
                    "Equity Share",           
                    equity_asset_class_id,
                    "India",
                    "INR",
                    None,                     
                    None,                     
                    listing_date,
                    paid_up_value,
                    market_lot,
                    face_value,
                    None,                     
                    None,                     
                    "ACTIVE",
                    "NSE"
                )
                securities.append(security)
            except Exception as error:
                failed_rows.append({
                    "row": index + 2,
                    "error": str(error)
                })
        processed = 0
        if securities:
            processed = security_repository.bulk_upsert_securities(
                securities
            )
        return {
            "total_rows": len(df),
            "processed": processed,
            "failed": len(failed_rows),
            "failed_rows": failed_rows[:20]
        }
 
nse_import_service = NSEImportService()