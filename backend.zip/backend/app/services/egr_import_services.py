import pandas as pd
from app.repositories.security_repository import security_repository
from app.repositories.price_repository import price_repository
  
class EGRImportService:
    def clean_text(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value in ("", "-", "--"):
            return None
        return value
 
    def clean_number(self, value):
        if pd.isna(value):
            return None
        value = str(value).strip()
        if value in ("", "-", "--"):
            return None
        value = value.replace(",", "")
        value = value.replace("₹", "")
        return float(value)
 
    def clean_integer(self, value):
        value = self.clean_number(value)
        if value is None:
            return None
        return int(value)
 
    def import_egr_file(self, file_path):
        df = pd.read_csv(file_path)
        df.columns = df.columns.str.strip()
        required_columns = [
            "Symbol",
            "Series",
            "Date",
            "Open Price",
            "High Price",
            "Low Price",
            "Close Price"
        ]
        missing_columns = [
            column
            for column in required_columns
            if column not in df.columns
        ]
        if missing_columns:
            raise ValueError(
                f"Missing EGR columns: {missing_columns}"
            )
        symbol = self.clean_text(df.iloc[0]["Symbol"])
        series = self.clean_text(df.iloc[0]["Series"])
        if not symbol:
            raise ValueError("EGR symbol is missing")
        commodity_asset_class_id = (
            security_repository.get_asset_class_id(
                "Commodity"
            )
        )
        if commodity_asset_class_id is None:
            raise ValueError(
                "Commodity asset class is not available"
            )
        security_id = (
            security_repository.upsert_egr_security(
                symbol=symbol,
                security_name=symbol,
                series=series,
                asset_class_id=commodity_asset_class_id
            )
        )
        prices = []
        failed_rows = []
        for index, row in df.iterrows():
            try:
                row_symbol = self.clean_text(row["Symbol"])
                if row_symbol != symbol:
                    raise ValueError(
                        f"Unexpected EGR symbol: {row_symbol}"
                    )
                trade_date = pd.to_datetime(
                    row["Date"],
                    errors="coerce",
                    dayfirst=True
                )
                if pd.isna(trade_date):
                    raise ValueError(
                        "Invalid trade date"
                    )
                trade_date = trade_date.date()
                previous_close = self.clean_number(row.get("Prev Close"))
                open_price = self.clean_number(row.get("Open Price"))
                high_price = self.clean_number(row.get("High Price"))
                low_price = self.clean_number(row.get("Low Price"))
                last_price = self.clean_number(row.get("Last Price"))
                close_price = self.clean_number(row.get("Close Price"))
                volume = self.clean_integer(row.get("Total Traded Quantity"))
                turnover = self.clean_number(row.get("Value"))
                number_of_trades = self.clean_integer(row.get("No. Of Trades"))
                price = (
                    security_id,
                    trade_date,
                    previous_close,
                    open_price,
                    high_price,
                    low_price,
                    last_price,
                    close_price,
                    None,               
                    volume,
                    turnover,
                    number_of_trades,
                    None,               
                    None,               
                    "NSE"
                )
                prices.append(price)
            except Exception as error:
                failed_rows.append({
                    "row": index + 2,
                    "error": str(error)
                }) 
        processed = (
            price_repository.bulk_upsert_prices(
                prices
            )
        )
        price_repository.refresh_latest_prices()
        return {
            "symbol": symbol,
            "security_id": security_id,
            "total_rows": len(df),
            "processed": processed,
            "failed": len(failed_rows),
            "failed_rows": failed_rows[:20]
        }
 
egr_import_service = EGRImportService()