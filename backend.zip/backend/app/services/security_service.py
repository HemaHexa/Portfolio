from app.repositories.security_repository import (
    security_repository
)
 
 
class SecurityService:
 
    def search_securities(
        self,
        search=None,
        sector=None,
        industry=None,
        limit=50
    ):
 
        if limit < 1 or limit > 100:
            raise ValueError(
                "Limit must be between 1 and 100"
            )
 
        rows = security_repository.search_securities(
            search,
            sector,
            industry,
            limit
        )
 
        return [
            {
                "security_id": row[0],
                "exchange": row[1],
                "symbol": row[2],
                "security_name": row[3],
                "isin": row[4],
                "series": row[5],
                "security_code": row[6],
                "security_type": row[7],
                "country": row[8],
                "currency": row[9],
                "sector": row[10],
                "industry": row[11],
                "status": row[12],
                "asset_class_name": row[13],
                "sub_asset_class": row[14],
                "latest_price": (
                    float(row[15])
                    if row[15] is not None
                    else None
                ),
                "price_date": row[16]
            }
            for row in rows
        ]
 
 
    def get_security(self, security_id):
 
        row = security_repository.get_security_by_id(
            security_id
        )
 
        if row is None:
            raise ValueError(
                "Security not found"
            )
 
        return {
            "security_id": row[0],
            "exchange": row[1],
            "symbol": row[2],
            "security_name": row[3],
            "isin": row[4],
            "series": row[5],
            "security_code": row[6],
            "security_type": row[7],
            "country": row[8],
            "currency": row[9],
            "sector": row[10],
            "industry": row[11],
            "listing_date": row[12],
            "paid_up_value": (
                float(row[13])
                if row[13] is not None
                else None
            ),
            "market_lot": row[14],
            "face_value": (
                float(row[15])
                if row[15] is not None
                else None
            ),
            "market_cap": (
                float(row[16])
                if row[16] is not None
                else None
            ),
            "scheme_code": row[17],
            "status": row[18],
            "source": row[19],
            "last_updated": row[20],
            "asset_class_name": row[21],
            "sub_asset_class": row[22],
            "latest_price": (
                float(row[23])
                if row[23] is not None
                else None
            ),
            "price_date": row[24]
        }
 
 
security_service = SecurityService()