from fastapi import APIRouter, HTTPException
 
from app.schemas import PortfolioCreate
from app.services.portfolio_service import portfolio_service
 
 
router = APIRouter(
    prefix="/api/portfolios",
    tags=["Portfolio Management"]
)
 
 
@router.post("")
def create_portfolio(data: PortfolioCreate):
    try:
        return portfolio_service.create_portfolio(data)
 
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
 
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
 
 
@router.get("")
def get_all_portfolios():
    try:
        return portfolio_service.get_all_portfolios()
 
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
 
 
@router.get("/{portfolio_id}")
def get_portfolio(portfolio_id):
    try:
        return portfolio_service.get_portfolio_by_id(
            portfolio_id
        )
 
    except ValueError as e:
        raise HTTPException(
            status_code=404,
            detail=str(e)
        )
 
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

@router.put("/{portfolio_id}/activate")
def activate_portfolio(portfolio_id: int):
 
    try:
        return portfolio_service.activate_portfolio(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except Exception as error:
        print("ACTIVATE PORTFOLIO ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )
 
 
@router.put("/{portfolio_id}/close")
def close_portfolio(portfolio_id: int):
 
    try:
        return portfolio_service.close_portfolio(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except Exception as error:
        print("CLOSE PORTFOLIO ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.get("/{portfolio_id}/performance")
def get_portfolio_performance(portfolio_id: int):
 
    try:
        return portfolio_service.get_portfolio_performance(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print(
            "PORTFOLIO PERFORMANCE ERROR:",
            error
        )
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )
 