from fastapi import APIRouter, HTTPException
 
from app.schemas import ThemeWithAllocationCreate
from app.services.theme_service import theme_service
 
 
router = APIRouter(
    prefix="/api/themes",
    tags=["Investment Themes"]
)
 
 
@router.post("")
def create_theme(
    data: ThemeWithAllocationCreate
):
    try:
        return theme_service.create_theme(data)
 
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )
 
 
@router.get("")
def get_all_themes():
 
    return theme_service.get_all_themes()
 
 
@router.get("/{theme_id}")
def get_theme(theme_id: int):
 
    try:
        return theme_service.get_theme(theme_id)
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )