from fastapi import APIRouter, HTTPException
 
from app.services.asset_class_service import (
    asset_class_service
)
 
 
router = APIRouter(
    prefix="/api/asset-classes",
    tags=["Asset Classes"]
)
 
 
@router.get("")
def get_all_asset_classes():
 
    return asset_class_service.get_all_asset_classes()
 
 
@router.get("/{asset_class_id}")
def get_asset_class(asset_class_id: int):
 
    try:
        return asset_class_service.get_asset_class(
            asset_class_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )