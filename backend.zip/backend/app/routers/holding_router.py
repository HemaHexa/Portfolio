from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
 
from app.services.holding_service import holding_service
 
 
router = APIRouter(
    prefix="/api/portfolios",
    tags=["Portfolio Holdings"]
)

 
class BuyHoldingRequest(BaseModel):
    security_id: int
    quantity: float

class SellHoldingRequest(BaseModel):
    security_id: int
    quantity: float

@router.post("/{portfolio_id}/holdings")
def buy_security(
    portfolio_id: int,
    data: BuyHoldingRequest
):
    try:
 
        result = holding_service.buy_security(
            portfolio_id=portfolio_id,
            security_id=data.security_id,
            quantity=data.quantity
        )
 
        return {
            "message": "Security purchased successfully",
            "data": result
        }
 
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except Exception as error:
        print("BUY HOLDING ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.post("/{portfolio_id}/holdings/sell")
def sell_security(
    portfolio_id: int,
    data: SellHoldingRequest
):
    try:
 
        result = holding_service.sell_security(
            portfolio_id=portfolio_id,
            security_id=data.security_id,
            quantity=data.quantity
        )
 
        return {
            "message": "Security sold successfully",
            "data": result
        }
 
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except Exception as error:
        print("SELL HOLDING ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.get("/{portfolio_id}/holdings")
def get_portfolio_holdings(portfolio_id: int):
 
    try:
        return holding_service.get_portfolio_holdings(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print("GET HOLDINGS ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )
@router.get("/{portfolio_id}/transactions")
def get_transaction_history(portfolio_id: int):
 
    try:
        return holding_service.get_transaction_history(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print("TRANSACTION HISTORY ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.get("/{portfolio_id}/summary")
def get_portfolio_summary(portfolio_id: int):
 
    try:
        return holding_service.get_portfolio_summary(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print("PORTFOLIO SUMMARY ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.get("/{portfolio_id}/allocation")
def get_asset_allocation(portfolio_id: int):
 
    try:
        return holding_service.get_asset_allocation(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print("ASSET ALLOCATION ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.get("/{portfolio_id}/allocation-assessment")
def get_allocation_assessment(portfolio_id: int):
 
    try:
        return holding_service.get_allocation_assessment(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print(
            "ALLOCATION ASSESSMENT ERROR:",
            error
        )
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.post("/{portfolio_id}/alerts/generate")
def generate_allocation_alerts(portfolio_id: int):
 
    try:
        return holding_service.generate_allocation_alerts(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print("GENERATE ALERT ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )
 
 
@router.get("/{portfolio_id}/alerts")
def get_active_alerts(portfolio_id: int):
 
    try:
        return holding_service.get_active_alerts(
            portfolio_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print("GET ALERT ERROR:", error)
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )

@router.get("/{portfolio_id}/rebalancing")
def get_rebalancing_recommendation(
    portfolio_id: int
):
 
    try:
        return (
            holding_service
            .get_rebalancing_recommendation(
                portfolio_id
            )
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except Exception as error:
        print(
            "REBALANCING ERROR:",
            error
        )
 
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )
 