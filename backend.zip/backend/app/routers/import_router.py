from pathlib import Path
from fastapi import APIRouter, HTTPException
from app.services.nse_import_service import nse_import_service
from app.services.price_import_service import price_import_service
from app.services.egr_import_services import egr_import_service
from app.services.mutual_fund_import_service import mutual_fund_import_service
from app.services.benchmark_import_service import benchmark_import_service

router = APIRouter(
    prefix="/api/import",
    tags=["Data Import"]
)

@router.post("/nse-equity")
def import_nse_equity():
    file_path = (
        Path(__file__).resolve().parents[3]
        / "data"
        / "raw"
        / "equity"
        / "EQUITY_L.csv"
    )
    if not file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"NSE Equity file not found: {file_path}"
        )
    try:
        result = nse_import_service.import_equity_master(str(file_path))
        return {
            "message": "NSE Equity Master import completed",
            "result": result
        }
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"NSE import failed: {str(error)}"
        )

@router.post("/nse-equity-history")
def import_nse_equity_history():
 
    folder_path = (
        Path(__file__).resolve().parents[3]
        / "data"
        / "raw"
        / "equity"
        / "historical"
    )
 
    if not folder_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"Historical data folder not found: {folder_path}"
        )
 
    csv_files = list(folder_path.glob("*.csv"))
 
    if not csv_files:
        raise HTTPException(
            status_code=404,
            detail="No historical equity CSV files found"
        )
 
    results = []
 
    total_processed = 0
    total_failed = 0
 
    for file_path in csv_files:
 
        try:
            result = price_import_service.import_equity_file(
                str(file_path)
            )
 
            results.append(result)
 
            total_processed += result["processed"]
            total_failed += result["failed"]
 
        except Exception as error:
 
            results.append({
                "file": file_path.name,
                "processed": 0,
                "failed": 0,
                "file_error": str(error)
            })
 
    return {
        "message": "NSE historical equity import completed",
        "files_found": len(csv_files),
        "total_processed": total_processed,
        "total_failed": total_failed,
        "files": results
    }

@router.post("/nse-egr-history")
def import_nse_egr_history():
    folder_path = (
        Path(__file__).resolve().parents[3]
        / "data"
        / "raw"
        / "egr"
    )
    if not folder_path.exists():
        raise HTTPException(
            status_code=404,
            detail="EGR folder not found"
        )
    csv_files = list(folder_path.glob("*.csv"))
    if not csv_files:
        raise HTTPException(
            status_code=404,
            detail="No EGR CSV file found"
        )
    results = []
    for file_path in csv_files:
        try:
            result = egr_import_service.import_egr_file(str(file_path))
            results.append(result)
        except Exception as error:
            results.append({
                "file": file_path.name,
                "error": str(error)
            })
    return {
        "message": "NSE EGR import completed",
        "files_found": len(csv_files),
        "results": results
    }

@router.post("/mutual-fund-nav")
def import_mutual_fund_nav():
    file_path = (
        Path(__file__).resolve().parents[3]
        / "data"
        / "raw"
        / "mutual_fund"
        / "NAVAll.txt"
    )
    if not file_path.exists():
        raise HTTPException(
            status_code=404,
            detail=f"NAVAll.txt not found: {file_path}"
        )
    try:
        result = (
            mutual_fund_import_service.import_nav_file(
                str(file_path)
            )
        )
        return {
            "message":
                "Mutual Fund NAV import completed",
            "result": result
        }
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Mutual Fund import failed: {error}"
        )

@router.post("/benchmark-nifty50")
def import_nifty50():
 
    try:
        return benchmark_import_service.import_nifty50()
 
    except FileNotFoundError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=400,
            detail=str(error)
        )
 
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=str(error)
        )
 