from fastapi import (
    APIRouter,
    HTTPException,
    Query
)
 
from app.services.security_service import (
    security_service
)
 
 
router = APIRouter(
    prefix="/api/securities",
    tags=["Security Master"]
)
 
 
@router.get("")
def search_securities(
    search: str | None = None,
    sector: str | None = None,
    industry: str | None = None,
    limit: int = Query(default=50, ge=1, le=100)
):
    return security_service.search_securities(
        search,
        sector,
        industry,
        limit
    )
 
 
@router.get("/{security_id}")
def get_security(security_id: int):
 
    try:
        return security_service.get_security(
            security_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )