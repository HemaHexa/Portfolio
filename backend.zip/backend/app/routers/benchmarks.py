from fastapi import APIRouter, HTTPException
 
from app.services.benchmark_service import (
    benchmark_service
)
 
 
router = APIRouter(
    prefix="/api/benchmarks",
    tags=["Benchmarks"]
)
 
 
@router.get("")
def get_all_benchmarks():
 
    return benchmark_service.get_all_benchmarks()
 
 
@router.get("/{benchmark_id}")
def get_benchmark(benchmark_id: int):
 
    try:
        return benchmark_service.get_benchmark(
            benchmark_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 
 
@router.get("/{benchmark_id}/history")
def get_benchmark_history(benchmark_id: int):
 
    try:
        return benchmark_service.get_benchmark_history(
            benchmark_id
        )
 
    except ValueError as error:
        raise HTTPException(
            status_code=404,
            detail=str(error)
        )
 