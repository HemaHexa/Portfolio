from app.database.connection import con_db 
 
class ThemeRepository:
 
    def create_theme(
        self,
        theme_name,
        description,
        risk_level,
        investment_horizon
    ):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            cursor.execute(
                """
                INSERT INTO investment_theme (
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status
                )
                VALUES (%s, %s, %s, %s, %s)
                RETURNING theme_id;
                """,
                (
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    "ACTIVE"
                )
            )
 
            theme_id = cursor.fetchone()[0]
 
            conn.commit()
 
            return theme_id
 
        except Exception:
            conn.rollback()
            raise
 
        finally:
            conn.close()
 
 
    def get_all_themes(self):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            cursor.execute(
                """
                SELECT
                    theme_id,
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status
                FROM investment_theme
                ORDER BY theme_id;
                """
            )
 
            rows = cursor.fetchall()
 
            return rows
 
        finally:
            conn.close()
 
 
    def get_theme_by_id(self, theme_id):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            cursor.execute(
                """
                SELECT
                    theme_id,
                    theme_name,
                    description,
                    risk_level,
                    investment_horizon,
                    status
                FROM investment_theme
                WHERE theme_id = %s;
                """,
                (theme_id,)
            )
 
            return cursor.fetchone()
 
        finally:
            conn.close()
 
 
    def create_allocations(
        self,
        theme_id,
        allocations
    ):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            query = """
                INSERT INTO theme_allocation (
                    theme_id,
                    asset_class_id,
                    target_percentage,
                    minimum_percentage,
                    maximum_percentage
                )
                VALUES (%s, %s, %s, %s, %s);
            """
 
            rows = []
 
            for allocation in allocations:
                rows.append(
                    (
                        theme_id,
                        allocation["asset_class_id"],
                        allocation["target_percentage"],
                        allocation["minimum_percentage"],
                        allocation["maximum_percentage"]
                    )
                )
 
            cursor.executemany(
                query,
                rows
            )
 
            conn.commit()
 
            return len(rows)
 
        except Exception:
            conn.rollback()
            raise
 
        finally:
            conn.close()
 
 
    def get_theme_allocations(self, theme_id):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            cursor.execute(
                """
                SELECT
                    ta.theme_allocation_id,
                    ta.theme_id,
                    ta.asset_class_id,
                    ac.asset_class_name,
                    ac.sub_asset_class,
                    ta.target_percentage,
                    ta.minimum_percentage,
                    ta.maximum_percentage
                FROM theme_allocation ta
 
                JOIN asset_class ac
                    ON ta.asset_class_id =
                       ac.asset_class_id
 
                WHERE ta.theme_id = %s
 
                ORDER BY ac.asset_class_name;
                """,
                (theme_id,)
            )
 
            return cursor.fetchall()
 
        finally:
            conn.close()
 
 
theme_repository = ThemeRepository()