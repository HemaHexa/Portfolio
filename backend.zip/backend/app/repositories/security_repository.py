from app.database.connection import con_db
 
class SecurityRepository:
    def get_asset_class_id(self, asset_class_name):
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT asset_class_id
                FROM asset_class
                WHERE asset_class_name = %s
                LIMIT 1
                """,
                (asset_class_name,)
            )
            row = cursor.fetchone()
            return row[0] if row else None
        finally:
            conn.close()
 
    def bulk_upsert_securities(self, securities):
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            query = """
                INSERT INTO security_master (
                    exchange,
                    symbol,
                    security_name,
                    isin,
                    series,
                    security_code,
                    security_type,
                    asset_class_id,
                    country,
                    currency,
                    sector,
                    industry,
                    listing_date,
                    paid_up_value,
                    market_lot,
                    face_value,
                    market_cap,
                    scheme_code,
                    status,
                    source
                )
                VALUES (
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s
                )
                ON CONFLICT (exchange, symbol)
                DO UPDATE SET
                    security_name = EXCLUDED.security_name,
                    isin = EXCLUDED.isin,
                    series = EXCLUDED.series,
                    security_type = EXCLUDED.security_type,
                    asset_class_id = EXCLUDED.asset_class_id,
                    country = EXCLUDED.country,
                    currency = EXCLUDED.currency,
                    listing_date = EXCLUDED.listing_date,
                    paid_up_value = EXCLUDED.paid_up_value,
                    market_lot = EXCLUDED.market_lot,
                    face_value = EXCLUDED.face_value,
                    status = EXCLUDED.status,
                    source = EXCLUDED.source,
                    last_updated = CURRENT_TIMESTAMP;
            """
            cursor.executemany(query, securities)
            conn.commit()
            return len(securities)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def upsert_egr_security(self, symbol, security_name, series, asset_class_id ):
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            query = """
                INSERT INTO security_master (
                    exchange,
                    symbol,
                    security_name,
                    series,
                    security_type,
                    asset_class_id,
                    country,
                    currency,
                    status,
                    source
                )
                VALUES (
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s
                )
                ON CONFLICT (exchange, symbol)
                DO UPDATE SET
                    security_name = EXCLUDED.security_name,
                    series = EXCLUDED.series,
                    security_type = EXCLUDED.security_type,
                    asset_class_id = EXCLUDED.asset_class_id,
                    status = EXCLUDED.status,
                    source = EXCLUDED.source,
                    last_updated = CURRENT_TIMESTAMP
    
                RETURNING security_id;
            """
            cursor.execute(
                query,
                (
                    "NSE",
                    symbol,
                    security_name,
                    series,
                    "EGR",
                    asset_class_id,
                    "India",
                    "INR",
                    "ACTIVE",
                    "NSE"
                )
            )
            security_id = cursor.fetchone()[0]
            conn.commit()
            return security_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def bulk_upsert_mutual_funds(self, securities):
        if not securities:
            return 0
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            query = """
                INSERT INTO security_master (
                    exchange,
                    symbol,
                    security_name,
                    isin,
                    security_type,
                    asset_class_id,
                    country,
                    currency,
                    scheme_code,
                    status,
                    source
                )
                VALUES (
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s, %s
                )
                ON CONFLICT (exchange, symbol)
                DO UPDATE SET
                    security_name = EXCLUDED.security_name,
                    isin = EXCLUDED.isin,
                    security_type = EXCLUDED.security_type,
                    asset_class_id = EXCLUDED.asset_class_id,
                    scheme_code = EXCLUDED.scheme_code,
                    status = EXCLUDED.status,
                    source = EXCLUDED.source,
                    last_updated = CURRENT_TIMESTAMP;
            """
            cursor.executemany(query, securities )
            conn.commit()
            return len(securities)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def get_mutual_fund_security_map(self):
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT scheme_code, security_id
                FROM security_master
                WHERE source = 'AMFI'
                AND scheme_code IS NOT NULL
            """)
            rows = cursor.fetchall()
            return {
                str(row[0]).strip(): row[1]
                for row in rows
            }
        finally:
            conn.close()

    def search_securities(
    self,
    search=None,
    sector=None,
    industry=None,
    limit=50
):
        conn = con_db.get_db_connection()
    
        try:
            cursor = conn.cursor()
    
            query = """
                SELECT
                    s.security_id,
                    s.exchange,
                    s.symbol,
                    s.security_name,
                    s.isin,
                    s.series,
                    s.security_code,
                    s.security_type,
                    s.country,
                    s.currency,
                    s.sector,
                    s.industry,
                    s.status,
                    ac.asset_class_name,
                    ac.sub_asset_class,
                    lmp.price,
                    lmp.price_date
                FROM security_master s
    
                LEFT JOIN asset_class ac
                    ON s.asset_class_id =
                    ac.asset_class_id
    
                LEFT JOIN latest_market_price lmp
                    ON s.security_id =
                    lmp.security_id
    
                WHERE 1 = 1
            """
    
            params = []
    
            if search:
                query += """
                    AND (
                        s.symbol ILIKE %s
                        OR s.security_name ILIKE %s
                        OR s.isin ILIKE %s
                        OR s.security_code ILIKE %s
                    )
                """
    
                search_value = f"%{search}%"
    
                params.extend([
                    search_value,
                    search_value,
                    search_value,
                    search_value
                ])
    
            if sector:
                query += """
                    AND s.sector ILIKE %s
                """
                params.append(f"%{sector}%")
    
            if industry:
                query += """
                    AND s.industry ILIKE %s
                """
                params.append(f"%{industry}%")
    
            query += """
                ORDER BY s.symbol
                LIMIT %s;
            """
    
            params.append(limit)
    
            cursor.execute(
                query,
                tuple(params)
            )
    
            return cursor.fetchall()
    
        finally:
            conn.close()
    
    
    def get_security_by_id(self, security_id):
        conn = con_db.get_db_connection()
    
        try:
            cursor = conn.cursor()
    
            cursor.execute(
                """
                SELECT
                    s.security_id,
                    s.exchange,
                    s.symbol,
                    s.security_name,
                    s.isin,
                    s.series,
                    s.security_code,
                    s.security_type,
                    s.country,
                    s.currency,
                    s.sector,
                    s.industry,
                    s.listing_date,
                    s.paid_up_value,
                    s.market_lot,
                    s.face_value,
                    s.market_cap,
                    s.scheme_code,
                    s.status,
                    s.source,
                    s.last_updated,
                    ac.asset_class_name,
                    ac.sub_asset_class,
                    lmp.price,
                    lmp.price_date
    
                FROM security_master s
    
                LEFT JOIN asset_class ac
                    ON s.asset_class_id =
                    ac.asset_class_id
    
                LEFT JOIN latest_market_price lmp
                    ON s.security_id =
                    lmp.security_id
    
                WHERE s.security_id = %s;
                """,
                (security_id,)
            )
    
            return cursor.fetchone()
    
        finally:
            conn.close()
 
security_repository = SecurityRepository()