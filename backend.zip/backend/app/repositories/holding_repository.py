from app.database.connection import con_db 
 
class HoldingRepository:
 
    def buy_security(
        self,
        portfolio_id: int,
        security_id: int,
        quantity: float,
        price: float
    ):
        conn = con_db.get_db_connection()
 
        try:
            with conn.cursor() as cursor:
 
                # ---------------------------------
                # 1. Lock and get portfolio balance
                # ---------------------------------
                cursor.execute(
                    """
                    SELECT available_balance
                    FROM portfolio
                    WHERE portfolio_id = %s
                    FOR UPDATE
                    """,
                    (portfolio_id,)
                )
 
                portfolio = cursor.fetchone()
 
                if portfolio is None:
                    raise ValueError("Portfolio not found")
 
                available_balance = float(portfolio[0])
 
                transaction_amount = quantity * price
 
                if transaction_amount > available_balance:
                    raise ValueError("Insufficient available balance")
 
                # ---------------------------------
                # 2. Check existing holding
                # ---------------------------------
                cursor.execute(
                    """
                    SELECT quantity, average_buy_price
                    FROM portfolio_holding
                    WHERE portfolio_id = %s
                      AND security_id = %s
                    """,
                    (portfolio_id, security_id)
                )
 
                holding = cursor.fetchone()
 
                if holding:
 
                    old_quantity = float(holding[0])
                    old_average_price = float(holding[1])
 
                    new_quantity = old_quantity + quantity
 
                    new_average_price = (
                        (old_quantity * old_average_price)
                        + (quantity * price)
                    ) / new_quantity
 
                    cursor.execute(
                        """
                        UPDATE portfolio_holding
                        SET quantity = %s,
                            average_buy_price = %s,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE portfolio_id = %s
                          AND security_id = %s
                        """,
                        (
                            new_quantity,
                            new_average_price,
                            portfolio_id,
                            security_id
                        )
                    )
 
                else:
 
                    cursor.execute(
                        """
                        INSERT INTO portfolio_holding
                        (
                            portfolio_id,
                            security_id,
                            quantity,
                            average_buy_price
                        )
                        VALUES (%s, %s, %s, %s)
                        """,
                        (
                            portfolio_id,
                            security_id,
                            quantity,
                            price
                        )
                    )
 
                # ---------------------------------
                # 3. Record BUY transaction
                # ---------------------------------
                cursor.execute(
                    """
                    INSERT INTO portfolio_transaction
                    (
                        portfolio_id,
                        security_id,
                        transaction_type,
                        quantity,
                        price,
                        transaction_amount,
                        transaction_date
                    )
                    VALUES
                    (
                        %s,
                        %s,
                        'BUY',
                        %s,
                        %s,
                        %s,
                        CURRENT_TIMESTAMP
                    )
                    """,
                    (
                        portfolio_id,
                        security_id,
                        quantity,
                        price,
                        transaction_amount
                    )
                )
 
                # ---------------------------------
                # 4. Reduce available balance
                # ---------------------------------
                new_balance = available_balance - transaction_amount
 
                cursor.execute(
                    """
                    UPDATE portfolio
                    SET available_balance = %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE portfolio_id = %s
                    """,
                    (
                        new_balance,
                        portfolio_id
                    )
                )
 
            conn.commit()
 
            return {
                "portfolio_id": portfolio_id,
                "security_id": security_id,
                "quantity_bought": quantity,
                "price": price,
                "transaction_amount": transaction_amount,
                "available_balance": new_balance
            }
 
        except Exception:
            conn.rollback()
            raise
 
        finally:
            conn.close()
    def sell_security(
        self,
        portfolio_id: int,
        security_id: int,
        quantity: float,
        price: float
    ):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                # 1. Lock portfolio and get current balance
                cursor.execute(
                    """
                    SELECT available_balance
                    FROM portfolio
                    WHERE portfolio_id = %s
                    FOR UPDATE
                    """,
                    (portfolio_id,)
                )
    
                portfolio = cursor.fetchone()
    
                if portfolio is None:
                    raise ValueError("Portfolio not found")
    
                available_balance = float(portfolio[0])
    
                # 2. Get and lock existing holding
                cursor.execute(
                    """
                    SELECT quantity
                    FROM portfolio_holding
                    WHERE portfolio_id = %s
                    AND security_id = %s
                    FOR UPDATE
                    """,
                    (portfolio_id, security_id)
                )
    
                holding = cursor.fetchone()
    
                if holding is None:
                    raise ValueError(
                        "Security is not present in this portfolio"
                    )
    
                current_quantity = float(holding[0])
    
                if quantity > current_quantity:
                    raise ValueError(
                        "Sell quantity cannot be greater than holding quantity"
                    )
    
                remaining_quantity = current_quantity - quantity
                transaction_amount = quantity * price
    
                # 3. Update/delete holding
                if remaining_quantity == 0:
    
                    cursor.execute(
                        """
                        DELETE FROM portfolio_holding
                        WHERE portfolio_id = %s
                        AND security_id = %s
                        """,
                        (portfolio_id, security_id)
                    )
    
                else:
    
                    cursor.execute(
                        """
                        UPDATE portfolio_holding
                        SET quantity = %s,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE portfolio_id = %s
                        AND security_id = %s
                        """,
                        (
                            remaining_quantity,
                            portfolio_id,
                            security_id
                        )
                    )
    
                # 4. Record SELL transaction
                cursor.execute(
                    """
                    INSERT INTO portfolio_transaction
                    (
                        portfolio_id,
                        security_id,
                        transaction_type,
                        quantity,
                        price,
                        transaction_amount,
                        transaction_date
                    )
                    VALUES
                    (
                        %s,
                        %s,
                        'SELL',
                        %s,
                        %s,
                        %s,
                        CURRENT_TIMESTAMP
                    )
                    """,
                    (
                        portfolio_id,
                        security_id,
                        quantity,
                        price,
                        transaction_amount
                    )
                )
    
                # 5. Add sale amount back to available balance
                new_balance = available_balance + transaction_amount
    
                cursor.execute(
                    """
                    UPDATE portfolio
                    SET available_balance = %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE portfolio_id = %s
                    """,
                    (
                        new_balance,
                        portfolio_id
                    )
                )
    
            conn.commit()
    
            return {
                "portfolio_id": portfolio_id,
                "security_id": security_id,
                "quantity_sold": quantity,
                "price": price,
                "transaction_amount": transaction_amount,
                "remaining_quantity": remaining_quantity,
                "available_balance": new_balance
            }
    
        except Exception:
            conn.rollback()
            raise
    
        finally:
            conn.close()

    def get_portfolio_holdings(self, portfolio_id: int):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT
                        ph.holding_id,
                        ph.security_id,
                        sm.symbol,
                        sm.security_name,
                        ac.asset_class_name,
                        ac.sub_asset_class,
                        ph.quantity,
                        ph.average_buy_price,
                        lmp.price,
                        lmp.price_date
    
                    FROM portfolio_holding ph
    
                    JOIN security_master sm
                        ON ph.security_id = sm.security_id
    
                    LEFT JOIN asset_class ac
                        ON sm.asset_class_id = ac.asset_class_id
    
                    LEFT JOIN latest_market_price lmp
                        ON ph.security_id = lmp.security_id
    
                    WHERE ph.portfolio_id = %s
    
                    ORDER BY sm.symbol;
                    """,
                    (portfolio_id,)
                )
    
                return cursor.fetchall()
    
        finally:
            conn.close()

    def get_transaction_history(self, portfolio_id: int):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT
                        pt.transaction_id,
                        pt.security_id,
                        sm.symbol,
                        sm.security_name,
                        pt.transaction_type,
                        pt.quantity,
                        pt.price,
                        pt.transaction_amount,
                        pt.transaction_date
    
                    FROM portfolio_transaction pt
    
                    JOIN security_master sm
                        ON pt.security_id = sm.security_id
    
                    WHERE pt.portfolio_id = %s
    
                    ORDER BY pt.transaction_date DESC,
                            pt.transaction_id DESC
                    """,
                    (portfolio_id,)
                )
    
                return cursor.fetchall()
    
        finally:
            conn.close()

    def get_portfolio_summary(self, portfolio_id: int):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT
                        p.portfolio_id,
                        p.portfolio_name,
                        p.initial_investment,
                        p.available_balance,
                        p.status,
                        COALESCE(
                            SUM(
                                ph.quantity * ph.average_buy_price
                            ),
                            0
                        ) AS invested_value,
                        COALESCE(
                            SUM(
                                ph.quantity * lmp.price
                            ),
                            0
                        ) AS holdings_current_value
    
                    FROM portfolio p
    
                    LEFT JOIN portfolio_holding ph
                        ON p.portfolio_id = ph.portfolio_id
    
                    LEFT JOIN latest_market_price lmp
                        ON ph.security_id = lmp.security_id
    
                    WHERE p.portfolio_id = %s
    
                    GROUP BY
                        p.portfolio_id,
                        p.portfolio_name,
                        p.initial_investment,
                        p.available_balance,
                        p.status
                    """,
                    (portfolio_id,)
                )
    
                return cursor.fetchone()
    
        finally:
            conn.close()

    def get_asset_allocation(self, portfolio_id: int):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT
                        ac.asset_class_id,
                        ac.asset_class_name,
                        COALESCE(
                            SUM(ph.quantity * lmp.price),
                            0
                        ) AS current_value
    
                    FROM portfolio_holding ph
    
                    JOIN security_master sm
                        ON ph.security_id = sm.security_id
    
                    JOIN asset_class ac
                        ON sm.asset_class_id = ac.asset_class_id
    
                    LEFT JOIN latest_market_price lmp
                        ON ph.security_id = lmp.security_id
    
                    WHERE ph.portfolio_id = %s
    
                    GROUP BY
                        ac.asset_class_id,
                        ac.asset_class_name
    
                    ORDER BY ac.asset_class_name
                    """,
                    (portfolio_id,)
                )
    
                return cursor.fetchall()
    
        finally:
            conn.close()

    def get_theme_allocation(self, portfolio_id: int):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT
                        p.theme_id,
                        it.theme_name,
                        ta.asset_class_id,
                        ac.asset_class_name,
                        ta.target_percentage,
                        ta.minimum_percentage,
                        ta.maximum_percentage
    
                    FROM portfolio p
    
                    JOIN investment_theme it
                        ON p.theme_id = it.theme_id
    
                    JOIN theme_allocation ta
                        ON p.theme_id = ta.theme_id
    
                    JOIN asset_class ac
                        ON ta.asset_class_id = ac.asset_class_id
    
                    WHERE p.portfolio_id = %s
    
                    ORDER BY ac.asset_class_name
                    """,
                    (portfolio_id,)
                )
    
                return cursor.fetchall()
    
        finally:
            conn.close()

    def refresh_allocation_alerts(
    self,
    portfolio_id: int,
    alerts: list
):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                # Resolve previous allocation alerts
                cursor.execute(
                    """
                    UPDATE portfolio_alert
                    SET status = 'RESOLVED',
                        resolved_at = CURRENT_TIMESTAMP
                    WHERE portfolio_id = %s
                    AND alert_type = 'ALLOCATION_DEVIATION'
                    AND status IN ('NEW','READ')
                    """,
                    (portfolio_id,)
                )
    
                # Create fresh active alerts
                for alert in alerts:
    
                    cursor.execute(
                        """
                        INSERT INTO portfolio_alert
                        (
                            portfolio_id,
                            asset_class_id,
                            alert_type,
                            alert_message,
                            target_percentage,
                            current_percentage,
                            deviation_percentage,
                            status,
                            generated_at
                        )
                        VALUES
                        (
                            %s,
                            %s,
                            'ALLOCATION_DEVIATION',
                            %s,
                            %s,
                            %s,
                            %s,
                            'NEW',
                            CURRENT_TIMESTAMP
                        )
                        """,
                        (
                            portfolio_id,
                            alert["asset_class_id"],
                            alert["alert_message"],
                            alert["target_percentage"],
                            alert["current_percentage"],
                            alert["deviation_percentage"]
                        )
                    )
    
            conn.commit()
    
        except Exception:
            conn.rollback()
            raise
    
        finally:
            conn.close()
 
 
    def get_active_alerts(self, portfolio_id: int):
        conn = con_db.get_db_connection()
    
        try:
            with conn.cursor() as cursor:
    
                cursor.execute(
                    """
                    SELECT
                        pa.alert_id,
                        pa.asset_class_id,
                        ac.asset_class_name,
                        pa.alert_type,
                        pa.alert_message,
                        pa.target_percentage,
                        pa.current_percentage,
                        pa.deviation_percentage,
                        pa.status,
                        pa.generated_at
    
                    FROM portfolio_alert pa
    
                    JOIN asset_class ac
                        ON pa.asset_class_id = ac.asset_class_id
    
                    WHERE pa.portfolio_id = %s
                    AND pa.status IN('NEW', 'READ')
    
                    ORDER BY pa.generated_at DESC,
                            pa.alert_id DESC
                    """,
                    (portfolio_id,)
                )
    
                return cursor.fetchall()
    
        finally:
            conn.close()

holding_repository = HoldingRepository()