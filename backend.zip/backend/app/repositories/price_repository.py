from app.database.connection import con_db
 
class PriceRepository:
    def get_security_map(self):
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT symbol, security_id
                FROM security_master
                WHERE exchange = 'NSE'
            """)
            rows = cursor.fetchall()
            return {
                row[0].strip().upper(): row[1]
                for row in rows
            }
        finally:
            conn.close()
 
    def bulk_upsert_prices(self, prices):
        if not prices:
            return 0
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            query = """
                INSERT INTO market_price_history (
                    security_id,
                    trade_date,
                    previous_close,
                    open_price,
                    high_price,
                    low_price,
                    last_price,
                    close_price,
                    average_price,
                    volume,
                    turnover,
                    number_of_trades,
                    deliverable_quantity,
                    delivery_percentage,
                    source
                )
                VALUES (
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s
                )
                ON CONFLICT (security_id, trade_date)
                DO UPDATE SET
                    previous_close = EXCLUDED.previous_close,
                    open_price = EXCLUDED.open_price,
                    high_price = EXCLUDED.high_price,
                    low_price = EXCLUDED.low_price,
                    last_price = EXCLUDED.last_price,
                    close_price = EXCLUDED.close_price,
                    average_price = EXCLUDED.average_price,
                    volume = EXCLUDED.volume,
                    turnover = EXCLUDED.turnover,
                    number_of_trades = EXCLUDED.number_of_trades,
                    deliverable_quantity =
                        EXCLUDED.deliverable_quantity,
                    delivery_percentage =
                        EXCLUDED.delivery_percentage,
                    source = EXCLUDED.source;
            """
            cursor.executemany(query, prices)
            conn.commit()
            return len(prices)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
 
    def refresh_latest_prices(self):
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            query = """
                INSERT INTO latest_market_price (
                    security_id,
                    price,
                    price_date,
                    source
                )
                SELECT DISTINCT ON (security_id)
                    security_id,
                    close_price,
                    trade_date,
                    source
                FROM market_price_history
                WHERE close_price IS NOT NULL
                ORDER BY
                    security_id,
                    trade_date DESC
                ON CONFLICT (security_id)
                DO UPDATE SET
                    price = EXCLUDED.price,
                    price_date = EXCLUDED.price_date,
                    source = EXCLUDED.source,
                    updated_at = CURRENT_TIMESTAMP;
            """
            cursor.execute(query)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
 
price_repository = PriceRepository()