from app.database.connection import con_db
 
class MutualFundRepository:
    def bulk_upsert_nav(self, nav_rows):
        if not nav_rows:
            return 0
        conn = con_db.get_db_connection()
        try:
            cursor = conn.cursor()
            query = """
                INSERT INTO mutual_fund_nav_history (
                    security_id,
                    nav_date,
                    nav,
                    plan,
                    option_type,
                    source
                )
                VALUES (
                    %s, %s, %s, %s, %s, %s
                )
                ON CONFLICT (security_id, nav_date)
                DO UPDATE SET
                    nav = EXCLUDED.nav,
                    plan = EXCLUDED.plan,
                    option_type = EXCLUDED.option_type,
                    source = EXCLUDED.source;
            """
            cursor.executemany( query, nav_rows)
            conn.commit()
            return len(nav_rows)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
 
mutual_fund_repository = MutualFundRepository()