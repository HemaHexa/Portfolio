from app.database.connection import con_db 
 
class BenchmarkRepository:
 
    def upsert_benchmark(
        self,
        benchmark_name,
        benchmark_code,
        exchange,
        currency,
        country,
        description,
        source
    ):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            # First check whether benchmark already exists
            cursor.execute(
                """
                SELECT benchmark_id
                FROM benchmark_master
                WHERE benchmark_code = %s;
                """,
                (benchmark_code,)
            )
 
            row = cursor.fetchone()
 
            if row:
                benchmark_id = row[0]
 
                cursor.execute(
                    """
                    UPDATE benchmark_master
                    SET
                        benchmark_name = %s,
                        exchange = %s,
                        currency = %s,
                        country = %s,
                        description = %s,
                        status = %s,
                        source = %s,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE benchmark_id = %s;
                    """,
                    (
                        benchmark_name,
                        exchange,
                        currency,
                        country,
                        description,
                        "ACTIVE",
                        source,
                        benchmark_id
                    )
                )
 
            else:
                cursor.execute(
                    """
                    INSERT INTO benchmark_master (
                        benchmark_name,
                        benchmark_code,
                        exchange,
                        currency,
                        country,
                        description,
                        status,
                        source
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING benchmark_id;
                    """,
                    (
                        benchmark_name,
                        benchmark_code,
                        exchange,
                        currency,
                        country,
                        description,
                        "ACTIVE",
                        source
                    )
                )
 
                benchmark_id = cursor.fetchone()[0]
 
            conn.commit()
 
            return benchmark_id
 
        except Exception:
            conn.rollback()
            raise
 
        finally:
            conn.close()
 
 
    def bulk_upsert_prices(self, prices):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            query = """
                INSERT INTO benchmark_price_history (
                    benchmark_id,
                    price_date,
                    close_value,
                    source
                )
                VALUES (%s, %s, %s, %s)
 
                ON CONFLICT (benchmark_id, price_date)
                DO UPDATE SET
                    close_value = EXCLUDED.close_value,
                    source = EXCLUDED.source;
            """
 
            cursor.executemany(
                query,
                prices
            )
 
            conn.commit()
 
            return len(prices)
 
        except Exception:
            conn.rollback()
            raise
 
        finally:
            conn.close()

    def get_all_benchmarks(self):
        conn = con_db.get_db_connection()
    
        try:
            cursor = conn.cursor()
    
            cursor.execute(
                """
                SELECT
                    benchmark_id,
                    benchmark_name,
                    benchmark_code,
                    exchange,
                    currency,
                    country,
                    description,
                    status,
                    source
                FROM benchmark_master
                ORDER BY benchmark_name;
                """
            )
    
            return cursor.fetchall()
    
        finally:
            conn.close()
    
    
    def get_benchmark_by_id(self, benchmark_id):
        conn = con_db.get_db_connection()
    
        try:
            cursor = conn.cursor()
    
            cursor.execute(
                """
                SELECT
                    benchmark_id,
                    benchmark_name,
                    benchmark_code,
                    exchange,
                    currency,
                    country,
                    description,
                    status,
                    source
                FROM benchmark_master
                WHERE benchmark_id = %s;
                """,
                (benchmark_id,)
            )
    
            return cursor.fetchone()
    
        finally:
            conn.close()
    
    
    def get_benchmark_history(self, benchmark_id):
        conn = con_db.get_db_connection()
    
        try:
            cursor = conn.cursor()
    
            cursor.execute(
                """
                SELECT
                    benchmark_price_id,
                    price_date,
                    close_value,
                    source
                FROM benchmark_price_history
                WHERE benchmark_id = %s
                ORDER BY price_date DESC;
                """,
                (benchmark_id,)
            )
    
            return cursor.fetchall()
    
        finally:
            conn.close()
 
 
benchmark_repository = BenchmarkRepository()