from app.database.connection import con_db 
 
class AssetClassRepository:
 
    def get_all_asset_classes(self):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            cursor.execute(
                """
                SELECT
                    asset_class_id,
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon,
                    status
                FROM asset_class
                ORDER BY asset_class_id;
                """
            )
 
            return cursor.fetchall()
 
        finally:
            conn.close()
 
 
    def get_asset_class_by_id(self, asset_class_id):
        conn = con_db.get_db_connection()
 
        try:
            cursor = conn.cursor()
 
            cursor.execute(
                """
                SELECT
                    asset_class_id,
                    asset_class_name,
                    asset_description,
                    sub_asset_class,
                    sub_asset_description,
                    risk_level,
                    investment_horizon,
                    status
                FROM asset_class
                WHERE asset_class_id = %s;
                """,
                (asset_class_id,)
            )
 
            return cursor.fetchone()
 
        finally:
            conn.close()
 
 
asset_class_repository = AssetClassRepository()