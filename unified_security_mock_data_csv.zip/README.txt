UNIFIED SECURITY MASTER - MOCK DATASET
======================================

IMPORTANT: ALL VALUES IN THIS PACKAGE ARE SYNTHETIC / MOCK DATA.

Contents:
- 1,000 securities in unified_security_master.csv
- 2,000 market-price rows in market_price_2days.csv
  (exactly 2 rows per security: 2026-10-01 and 2026-10-02)
- 8 asset classes covering Equity, Mutual Fund, ETF, Government Security,
  Corporate Bond, REIT, InvIT and Money Market / Commercial Paper
- 11 simplified GICS classifications
- 3 investment themes and 24 theme-allocation rows
- 1 simplified NIFTY 50 benchmark row

Relationship keys follow the final ER diagram:
asset_class_id, gics_id, security_id, theme_id, benchmark_id.
